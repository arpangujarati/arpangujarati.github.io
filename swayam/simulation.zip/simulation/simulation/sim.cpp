#include "sim.h"

string EventTypeStr(EventType t)
{
    switch(t)
    {
        case EventType::WG2CL_query:
            return "WG2CL_query";
        case EventType::CL2BR_query:
            return "CL2BR_query";
        case EventType::BR2FE_query:
            return "BR2FE_query";
        case EventType::BR2CL_result:
            return "BR2CL_result";
        case EventType::FE2BE_query:
            return "FE2BE_query";
        case EventType::FE2BR_result:
            return "FE2BR_result";
        case EventType::BE2FE_result:
            return "BE2FE_result";
        case EventType::BE2FE_busy:
            return "BE2FE_busy";
        case EventType::BE2FE_end_setup:
            return "BE2FE_end_setup";
        case EventType::BE2FE_idle_be:
            return "BE2FE_idle_be";
        case EventType::BE2BE_end_setup:
            return "BE2BE_end_setup";
        case EventType::BE2BE_end_exe:
            return "BE2BE_end_exe";
        default:
            return "INVALID_EVENT_TYPE";
    }
}
