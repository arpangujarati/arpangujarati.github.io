#ifndef SIM_B1_FE_H
#define SIM_B1_FE_H

#include <map>
#include <mutex>

#include "sim.h"
#include "../utils/basics.h"
#include "../utils/load_balancer.h"
#include "../gen-cpp/azml_types.h"

class SimB1FE : public SimNode
{
  private:
    FELoadBalancer *lb;
    LBPolicyType lb_type;

  public:
    SimB1FE( Category *logger, Simulator* sim, string my_add,
             vector<string>& cl_adds, vector<string>& br_adds,
             vector<string>& fe_adds, vector<string>& be_adds,
             string lb_type )
             : SimNode(logger, sim, my_add, cl_adds, br_adds, fe_adds, be_adds)
    {
        this->lb_type = get_policy_type_enum(lb_type);
        lb = new FELoadBalancer(logger, this->lb_type, my_add, fe_adds, be_adds);
    }

    void interrupt(const SimEvent& recv_event, TimeUs now_us)
    {
        INFO << "[" << now_us << " " << recv_event.sender << " "
             << EventTypeStr(recv_event.type) << " RID:" << recv_event.rid
             << " " << my_add << "]";

        if (recv_event.type == EventType::BR2FE_query)
        {
            if (lb_type == LBPolicyType::LB_RAND)
            {
                sim->register_event( recv_event, EventType::FE2BE_query, my_add,
                                     lb->get_random_be(),
                                     now_us + FE2BE_DELAY_US );
            }
            else if (lb_type == LBPolicyType::LB_RR)
            {
                sim->register_event( recv_event, EventType::FE2BE_query, my_add,
                                     lb->get_rr_be(),
                                     now_us + FE2BE_DELAY_US );
            }
            else if (lb_type == LBPolicyType::LB_QBE)
            {
                sim->register_event( recv_event, EventType::FE2BE_query, my_add,
                                     lb->get_be_with_min_load(),
                                     now_us + FE2BE_DELAY_US );
            }
            else if ( lb_type == LBPolicyType::LB_QFE ||
                      lb_type == LBPolicyType::LB_QFEP )
            {
                if (lb->is_be_idle())
                {
                    sim->register_event( recv_event, EventType::FE2BE_query,
                                         my_add, lb->get_idle_be(),
                                         now_us + FE2BE_DELAY_US );
                }
                else
                {
                    lb->add_pending_event(recv_event);
                }
            }
            else if (lb_type == LBPolicyType::LB_JIQ)
            {
                if (lb->is_be_idle())
                {
                    sim->register_event( recv_event, EventType::FE2BE_query, my_add,
                                         lb->get_idle_be(),
                                         now_us + FE2BE_DELAY_US );
                }
                else
                {
                    sim->register_event( recv_event, EventType::FE2BE_query, my_add,
                                         lb->get_random_be(),
                                         now_us + FE2BE_DELAY_US);
                }
            }
            else if (lb_type == LBPolicyType::LB_POD)
            {
                vector<string> random_bes = lb->get_d_random_bes(recv_event);

                for(unsigned int i = 0; i < random_bes.size(); i++)
                {
                    sim->register_event( recv_event, EventType::FE2BE_query,
                                         my_add, random_bes[i],
                                         now_us + FE2BE_DELAY_US );
                }
            }
        }

        else if (recv_event.type == EventType::BE2FE_result)
        {
            if (lb_type == LBPolicyType::LB_POD)
            {
                if (!lb->is_result_redundant(recv_event))
                {
                    sim->register_event( recv_event, EventType::FE2BR_result,
                                         my_add, br_adds[0], now_us );
                }
            }
            else
            {
                sim->register_event( recv_event, EventType::FE2BR_result,
                                     my_add, br_adds[0], now_us );
            }

            if (lb_type == LBPolicyType::LB_QBE)
            {
                lb->dec_be_load(recv_event.sender);
            }
            else if ( lb_type == LBPolicyType::LB_QFE ||
                      lb_type == LBPolicyType::LB_QFEP )
            {
                if (lb->is_event_pending())
                {
                    sim->register_event( lb->get_pending_event(),
                                         EventType::FE2BE_query, my_add,
                                         recv_event.sender,
                                         now_us + FE2BE_DELAY_US );
                }
                else
                {
                    lb->add_idle_be(recv_event.sender);
                }
            }
        }

        else if (recv_event.type == EventType::BE2FE_busy)
        {
            if (lb_type == LBPolicyType::LB_RAND)
            {
                sim->register_event( recv_event, EventType::FE2BE_query, my_add,
                                     lb->get_random_be(),
                                     now_us + RETRY_DELAY_US + FE2BE_DELAY_US );
            }
            else if (lb_type == LBPolicyType::LB_RR)
            {
                sim->register_event( recv_event, EventType::FE2BE_query, my_add,
                                     lb->get_rr_be(),
                                     now_us + RETRY_DELAY_US + FE2BE_DELAY_US);
            }
            else if (lb_type == LBPolicyType::LB_POD)
            {
                if (lb->is_retry_required(recv_event))
                {
                    vector<string> random_bes = lb->get_d_random_bes(recv_event);

                    for(unsigned int i = 0; i < random_bes.size(); i++)
                    {
                        sim->register_event( recv_event, EventType::FE2BE_query,
                                             my_add, random_bes[i],
                                             now_us + RETRY_DELAY_US + FE2BE_DELAY_US );
                    }
                }
            }
            else
            {
                assert (false);
            }
        }

        else if (recv_event.type == EventType::BE2FE_idle_be)
        {
            if (lb_type == LBPolicyType::LB_JIQ)
            {
                lb->add_idle_be(recv_event.sender);
            }
            else
            {
                assert (false);
            }
        }

        else
        {
            sig_handler(SIGTERM);
        }
    }
};

#endif
