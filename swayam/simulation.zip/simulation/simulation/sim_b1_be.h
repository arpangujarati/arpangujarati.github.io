#ifndef SIM_B1_BE_H
#define SIM_B1_BE_H

#include <map>
#include <mutex>

#include "sim.h"
#include "../utils/basics.h"
#include "../utils/backend_states.h"
#include "../utils/load_balancer.h"

class SimB1BE : public SimNode
{
  private:
    LBPolicyType lb_type;
    BELoadBalancer *lb;
    StateType state;

  public:
    SimB1BE ( Category* logger, Simulator* sim, string my_add,
              vector<string>& cl_adds, vector<string>& br_adds,
              vector<string>& fe_adds, vector<string>& be_adds,
              string lb_type )
              : SimNode(logger, sim, my_add, cl_adds, br_adds, fe_adds, be_adds)
    {
        this->lb_type = get_policy_type_enum(lb_type);
        lb = new BELoadBalancer(logger, this->lb_type, fe_adds);
        state = StateType::WARM;
    }

    void execute_event(const SimEvent& recv_event, TimeUs now_us)

    {
        INFO << "Executing rid:" << recv_event.rid;
        SimEvent new_event(recv_event);
        new_event.start_time_us = now_us;
        new_event.fe = recv_event.sender;
        sim->register_event( new_event, EventType::BE2BE_end_exe, my_add,
                             my_add, now_us + recv_event.exe_time_us );
    }

    void interrupt(const SimEvent& recv_event, TimeUs now_us)
    {
        INFO << "[" << now_us << " " << recv_event.sender << " "
             << EventTypeStr(recv_event.type) << " RID:" << recv_event.rid
             << " " << my_add << "]";

        if (recv_event.type == EventType::FE2BE_query)
        {
            if ( lb_type == LBPolicyType::LB_RAND ||
                 lb_type == LBPolicyType::LB_RR ||
                 lb_type == LBPolicyType::LB_QFE ||
                 lb_type == LBPolicyType::LB_QFEP ||
                 lb_type == LBPolicyType::LB_POD )
            {
                if (state == StateType::BUSY)
                {
                    assert ( lb_type == LBPolicyType::LB_RAND ||
                             lb_type == LBPolicyType::LB_RR ||
                             lb_type == LBPolicyType::LB_POD );
                    sim->register_event( recv_event, EventType::BE2FE_busy,
                                         my_add, recv_event.sender,
                                         now_us + BE2FE_DELAY_US );
                }
                else
                {
                    assert (state == StateType::WARM);
                    state = StateType::BUSY;
                    execute_event(recv_event, now_us);
                }
            }
            else if ( lb_type == LBPolicyType::LB_QBE ||
                      lb_type == LBPolicyType::LB_JIQ )
            {
                lb->add_pending_event(recv_event);
            }
            else
            {
                assert (false);
            }
        }
        else if (recv_event.type == EventType::BE2BE_end_exe)
        {
            assert (state == StateType::BUSY);

            if ( lb_type == LBPolicyType::LB_RAND ||
                 lb_type == LBPolicyType::LB_RR ||
                 lb_type == LBPolicyType::LB_POD )
            {
                sim->register_event( recv_event, EventType::BE2FE_result, my_add,
                                     recv_event.fe, now_us + BE2FE_DELAY_US );
            }
            else
            {
                sim->register_event( recv_event, EventType::BE2FE_result, my_add,
                                     recv_event.fe, now_us + BE2FE_DELAY_US );
            }
            state = StateType::WARM;
        }
        else
        {
            sig_handler(SIGTERM);
        }

        if ( lb_type == LBPolicyType::LB_QBE ||
             lb_type == LBPolicyType::LB_JIQ )
        {
            if (state == StateType::WARM)
            {
                if (lb->is_event_pending())
                {
                    state = StateType::BUSY;
                    execute_event(lb->get_pending_event(), now_us);
                }
                else if (lb_type == LBPolicyType::LB_JIQ)
                {
                    string iq_add = lb->get_random_fe();
                    sim->register_event( recv_event, EventType::BE2FE_idle_be,
                                         my_add, iq_add,
                                         now_us + BE2FE_DELAY_US );
                }
            }
        }
    }
};

#endif
