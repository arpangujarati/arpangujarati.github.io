#ifndef SIM_H
#define SIM_H

#include "../utils/basics.h"
#include "../utils/logging.h"

#include <string> // to_string
#include <queue>
#include <map>

typedef string NodeIDType;

enum EventType
{
    WG2CL_query,        // 0. ML query from WG to CL
    CL2BR_query,        // 1. ML query from CL to BR
    BR2FE_query,        // 2. ML query from BR to FE
    BR2CL_result,       // 3. Query result from BR to CL
    FE2BE_query,        // 4. ML query from FE to BE
    FE2BR_result,       // 5. result from FE to BR
    BE2FE_result,       // 6. Query result from BE to FE
    BE2FE_busy,         // 7. Busy response from BE to FE
    BE2FE_end_setup,    // 8. Notification to end the setup in progress
    BE2FE_idle_be,      // 9. Notification to signal that the BE is idle
    BE2BE_end_setup,    // 10. Notification to end the setup in progress
    BE2BE_end_exe,      // 11. Notification to end the execution in progress
    DUMMY_type          // 12. Dummy type
};

string EventTypeStr(EventType t);

class SimEvent
{
  public:
    EventType type;
    TimeUs activation_time;
    NodeIDType sender;
    NodeIDType receiver;
    NodeIDType fe;

    int sid = -1;
    int rid = -1;
    TimeUs exe_time_us = 0;
    TimeUs entry_time_us = 0;
    TimeUs start_time_us = 0;
    TimeUs exit_time_us = 0;

    SimEvent( EventType type, TimeUs activation_time, NodeIDType sender,
              NodeIDType receiver, int sid, int rid, TimeUs exe_time_us )
              : type(type), activation_time(activation_time), sender(sender),
                receiver(receiver), sid(sid), rid(rid), exe_time_us(exe_time_us)
                {}

    SimEvent() : type(EventType::DUMMY_type), activation_time(0), sender(""),
                 receiver(""), sid(0), rid(0), exe_time_us(0) {}

    bool operator<(const SimEvent other) const
    {
        if (activation_time == other.activation_time)
            return type > other.type;

        return activation_time > other.activation_time;
    }

    string str() const
    {
        return "(type=" + EventTypeStr(type) +
               ", fe=" + fe +
               ", activation_time=" + to_string(activation_time) +
               ", sender=" + sender +
               ", receiver=" + receiver +
               ", sid.rid=" + to_string(sid) + "." + to_string(rid) +
               ", exe_time_us=" + to_string(exe_time_us) + ")";
    }
};

class Simulator;

class SimNode
{
  public:
    Category *logger = NULL;
    NodeIDType id;
    Simulator* sim;

    string my_add;
    vector<string> cl_adds;
    vector<string> br_adds;
    vector<string> fe_adds;
    vector<string> be_adds;

    SimNode( Category *logger, Simulator* sim, string my_add,
             vector<string>& cl_adds, vector<string>& br_adds,
             vector<string>& fe_adds, vector<string>& be_adds )
             : logger(logger), id(my_add), sim(sim), my_add(my_add),
               cl_adds(cl_adds), br_adds(br_adds), fe_adds(fe_adds),
               be_adds(be_adds) {}

    virtual void interrupt(const SimEvent& event, TimeUs now) = 0;

    string str() { return "(id=" + id + ")"; }
};

class Simulator
{
  public:
    Category *logger = NULL;
    priority_queue <SimEvent>  pendingq;
    map<NodeIDType, SimNode*> nodes;
    TimeUs time = 0;
    
    Simulator(Category *logger) : logger(logger) {}

    void register_event( const SimEvent& old_event,
                         EventType type,
                         NodeIDType sender,
                         NodeIDType receiver )
    {
        register_event(old_event, type, sender, receiver, time + 1);
    }

    void register_event( const SimEvent& old_event,
                         EventType type,
                         NodeIDType sender,
                         NodeIDType receiver,
                         TimeUs activation_time )
    {
        SimEvent event( type, activation_time, sender, receiver, old_event.sid,
                        old_event.rid, old_event.exe_time_us );
        event.fe = old_event.fe;
        event.entry_time_us = old_event.entry_time_us;
        event.start_time_us = old_event.start_time_us;
        event.exit_time_us = old_event.exit_time_us;
        register_event(event);
    }

    void register_event(const SimEvent& event)
    {
        pendingq.push(event);
    }

    void register_node(SimNode* node)
    {
        node->sim = this;
        nodes[node->id] = node;
    }

    void schedule(const SimEvent& event)
    {
        nodes[event.receiver]->interrupt(event, time);
    }

    void run()
    {
        while (!pendingq.empty())
        {
            // DO NOT change SimEvent to reference!
            const SimEvent event = pendingq.top();
            pendingq.pop();

            if (event.activation_time > time)
            {
                time = event.activation_time;
            }

            schedule(event);
        }
    }
};

#endif
