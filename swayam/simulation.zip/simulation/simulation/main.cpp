#include "sim.h"
#include "sim_b1_cl.h"
#include "sim_b1_br.h"
#include "sim_b1_fe.h"
#include "sim_b1_be.h"

#include "../utils/basics.h"
#include "../utils/file_io_sim.h"
#include "../utils/trace_gen_sim.h"

Category *logger;

// all relevant server addresses
vector<string> cl_adds;
vector<string> br_adds;
vector<string> fe_adds;
vector<string> be_adds;

// info about all services
ServicesInfoMap services;

int main(int argc, char **argv)
{
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);

    if ( argc != 6)
    {
        cerr << "Error: Illegal number of parameters " << argc << "\n";
        cerr << "Usage: " << argv[0] << " config-dir debug-priority-level "
             << "log-file sim-version lb-type\n";
        cerr << flush;
        sig_handler(SIGTERM);
    }

    string config_dir = argv[1];
    int logger_prio = atoi(argv[2]);
    string log_file = argv[3];
    string sim_version = argv[4];
    string lb_type = argv[5];

    get_all_add_strs_from_file(config_dir, cl_adds, br_adds, fe_adds, be_adds);
    get_services_from_file(config_dir, services);
    get_new_logger(cl_adds[0], log_file, logger_prio, &logger);

    string trace_file = config_dir + "trace.txt";
    TraceType trace = get_trace(logger, trace_file);
    INFO << "Simulating trace with " << trace.size() << " requests";

    assert (cl_adds.size() == 1);
    assert(br_adds.size() == 1);

    if (!trace.empty())
    {
        INFO << "Initiating simulator";
        Simulator sim(logger);

        SimNode* node;

        INFO << "Initiating CL";
        node = new SimClientB1( logger, &sim, cl_adds[0], cl_adds, br_adds,
                                fe_adds, be_adds );
        sim.register_node(node);

        INFO << "Initiating BR";
        node = new SimBrokerB1( logger, &sim, br_adds[0], cl_adds, br_adds,
                                fe_adds, be_adds );
        sim.register_node(node);

        INFO << "Initiating " << fe_adds.size() << " " << lb_type << " FEs";
        for (unsigned int i = 0; i < fe_adds.size(); i++)
        {
            if (sim_version.compare("b1") == 0)
            {
                node = new SimB1FE( logger, &sim, fe_adds[i], cl_adds, br_adds,
                                    fe_adds, be_adds, lb_type );
            }
            else
            {
                assert(false);
            }

            sim.register_node(node);
        }

        INFO << "Initiating " << be_adds.size() << " " << lb_type << " BEs";
        for (unsigned int i = 0; i < be_adds.size(); i++)
        {
            if (sim_version.compare("b1") == 0)
            {
                node = new SimB1BE( logger, &sim, be_adds[i], cl_adds, br_adds,
                                    fe_adds, be_adds, lb_type );
            }
            else
            {
                assert(false);
            }

            sim.register_node(node);
        }

        for (TraceType::iterator it = trace.begin(); it != trace.end(); ++it)
        {
            TraceEntryType& te = (*it);
            SimEvent e( EventType::WG2CL_query, te.arrival_us, "WG", cl_adds[0],
                        te.sid, te.uid, te.exe_time_us );
            sim.register_event(e);
        }

        sim.run();
    }

    return 0;
}
