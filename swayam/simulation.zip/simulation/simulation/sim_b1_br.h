#ifndef SIM_B1_BR_H
#define SIM_B1_BR_H

#include <map>
#include <mutex>

#include "sim.h"

class SimBrokerB1 : public SimNode
{
  private:
    unsigned int fe_index = 0;         
    mutex mtx_fe_index;

  public:
    SimBrokerB1( Category *logger, Simulator* sim, string my_add,
                 vector<string>& cl_adds, vector<string>& br_adds,
                 vector<string>& fe_adds, vector<string>& be_adds )
                 : SimNode( logger, sim, my_add, cl_adds, br_adds, fe_adds,
                            be_adds ) {}

    void interrupt(const SimEvent& recv_event, TimeUs now_us)
    {
        INFO << "[" << now_us << " " << recv_event.sender << " "
             << EventTypeStr(recv_event.type) << " RID:" << recv_event.rid
             << " " << my_add << "]";

        if (recv_event.type == EventType::FE2BR_result)
        {
            SimEvent new_event(recv_event);     
            new_event.exit_time_us = now_us;
            sim->register_event( new_event, EventType::BR2CL_result,
                                 my_add, cl_adds[0], now_us );
        }

        else if (recv_event.type == EventType::CL2BR_query)
        {
            INFO << "STATS_BR_NEW_REQ " << now_us;

            mtx_fe_index.lock();
            string fe_add = fe_adds[fe_index];
            fe_index = (fe_index + 1) % fe_adds.size();
            mtx_fe_index.unlock();

            SimEvent new_event(recv_event); 
            new_event.entry_time_us = now_us;
            sim->register_event( new_event, EventType::BR2FE_query,
                                 my_add, fe_add, now_us );
        }

        else
        {
            ERROR << "Received unknown msg " << recv_event.rid
                  << " of type " << recv_event.type;
            sig_handler(SIGTERM);
        }
    }
};

#endif
