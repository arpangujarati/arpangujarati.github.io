#ifndef SIM_B1_CL_H
#define SIM_B1_CL_H

#include <map>

#include "sim.h"

class SimClientB1 : public SimNode
{
  public:
    SimClientB1( Category *logger, Simulator* sim, string my_add,
                 vector<string>& cl_adds, vector<string>& br_adds,
                 vector<string>& fe_adds, vector<string>& be_adds )
                 : SimNode( logger, sim, my_add, cl_adds, br_adds, fe_adds,
                            be_adds ) {}

    void interrupt(const SimEvent& recv_event, TimeUs now_us)
    {
        INFO << "[" << now_us << " " << recv_event.sender << " "
             << EventTypeStr(recv_event.type) << " RID:" << recv_event.rid
             << " " << my_add << "]";

        if (recv_event.type == EventType::WG2CL_query)
        {
            INFO << "STATS_NEW_REQUEST " << now_us;
            //INFO << "STATS_WG_TRACE_DATA " << now_us << " " << recv_event.sid
            //     << " " << recv_event.rid << " " << recv_event.exe_time_us;
            sim->register_event( recv_event, EventType::CL2BR_query,
                                 my_add, br_adds[0], now_us );
        }

        else if (recv_event.type == EventType::BR2CL_result)
        {
            //INFO << "BR2CL_result Received msg " << recv_event.rid << " from "
            //     << recv_event.sender;
            INFO << "STATS_WAITING_TIME " << recv_event.entry_time_us << " "
                 << recv_event.start_time_us - recv_event.entry_time_us;
            INFO << "STATS_RESPONSE_TIME " << recv_event.entry_time_us << " "
                 << recv_event.exit_time_us - recv_event.entry_time_us;
        }

        else
        {
            ERROR << "Received unknown msg " << recv_event.rid
                  << " of type " << recv_event.type;
            sig_handler(SIGTERM);
        }
    }
};

#endif
