#include "qt_analysis.h"

#include "../utils/basics.h"
#include "../utils/logging.h"
#include "../utils/queuing_theory.h"

#include <limits>

Category *logger;

int min_bes_satisfying_sla( double scv, int max, double sla_pc,
                            double reqs_per_us, TimeUs avg_exe_time_us,
                            TimeUs sla_rt_us )
{
    int min = 1;
    TimeUs max_wait_time_us = sla_rt_us - avg_exe_time_us;

    while(max > min)
    {
        int mid = (min + max) / 2;

        if (avg_exe_time_us * reqs_per_us >= mid)
        {
            min = mid + 1;
            continue;
        }

        TimeUs wait_time_us;

        wait_time_us = percentile_wait_time_mmn( mid, reqs_per_us, 
                                                 avg_exe_time_us, sla_pc );
        wait_time_us *= scv;

        if (wait_time_us == std::numeric_limits<double>::infinity())
        {
            min = mid + 1;
            continue;
        }

        if (wait_time_us <= max_wait_time_us)
        {
            max = mid;
            continue;
        }

        min = mid + 1;
    }

    return max;
}

int main(int argc, char **argv)
{
    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);

    string optype = argv[1];
    double scv = stod(argv[2]);
    int num_bes = stoi(argv[3]);
    double sla_pc = stod(argv[4]);
    double reqs_per_us = stod(argv[5]);
    TimeUs avg_exe_time_us = stoull(argv[6]);

    // Compute min. #BEs satisfying SLA
    if (optype.compare("min-bes") == 0)
    {
        TimeUs sla_rt_us = stoull(argv[7]);

        int result = min_bes_satisfying_sla( scv, num_bes, sla_pc, 
                                             reqs_per_us, avg_exe_time_us,
                                             sla_rt_us );
        cout << result;
    }

    // Compute percentile waiting time
    else if (optype.compare("wt") == 0)
    {
        TimeUs result;

        if ((num_bes - 1) < (reqs_per_us * avg_exe_time_us))
        {
            cout << "inf";
        }

        else
        {
            result = percentile_wait_time_mmn( num_bes, reqs_per_us, 
                                               avg_exe_time_us, sla_pc );
            result *= scv;
            cout << result;
        }
    }

    else
    {
        cerr << "Error: Invalid operation " << optype << "\n";
        cerr << "Available types are \"min-bes\" and \"wt\"\n";
        cerr << flush;
        sig_handler(SIGTERM);
    }
    
    return 0;
}
