//enum MessageType
//{
//  CL2BRa = 1,   // Request from Client to Broker
//  BR2FEa = 2,   // Request from Broker to Frontend
//  FE2BEa = 3,   // Request from Frontend to Backend
//  BE2FEa = 4,   // "Score" response from Backend to Frontend
//  BE2FEb = 5,   // "Busy" response from Backend to Frontend
//  FE2BRa = 6,   // "Score" response from Frontend to Broker
//  BR2CLa = 7    // "Score" response from Broker to Client
//}


enum MessageType
{
    WG2CL_query     = 1, // ML query from WG to BR
    CL2BR_query     = 2, // ML query from CL to BR
    BR2FE_query     = 3, // ML query from BR to FE
    BR2CL_result    = 4, // Query result from BR to CL
    FE2BE_query     = 5, // ML query from FE to BE
    FE2BR_result    = 6, // result from FE to BR
    BE2FE_result    = 7, // Query result from BE to FE
    BE2FE_busy      = 8, // Busy response from BE to FE
    DUMMY_type      = 9  // Dummy type
}

struct AddType
{
    1: i32 port,    // Listening port along with...
    2: string host  // hostname of the sender
}

struct StatsType
{
    1: string entry_time_us,     // When request arrived at the broker
    2: string start_time_us,     // When request starts execution
    3: string exit_time_us       // When response arrives at the broker
}

struct LocalInfoType
{
    1:  list<i32> request_counts, // #Requests received by the BE and ...
    2:  list<double> timestamps   // ... the corresponding timestamps
}

struct Message
{
    1: i32 rid,                  // Unique request ID
    2: i32 sid,                  // Unique service ID
    3: MessageType mtype,        // Message type
    4: AddType sender,           // Sender address
    6: i32 exe_time_us,          // Execution time
    7: i32 retry_attempts,       // #Retries
    8: LocalInfoType be_history, // Request history of the BE
    9: StatsType stats           // Response-time statistics
}

service broker
{
    oneway void execute(1: Message msg),
    oneway void terminate()
}

service frontend
{
    oneway void execute(1: Message msg),
    oneway void terminate()
}

service backend
{
    oneway void init_gc(),
    oneway void warmup(1: i32 sid),
    oneway void execute(1: Message msg),
    oneway void terminate()
}

service client
{
    oneway void execute(1: Message msg),
    oneway void terminate()
}
