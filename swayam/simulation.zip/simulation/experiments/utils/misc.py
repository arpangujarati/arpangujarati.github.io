import math
import subprocess
import numpy
import scipy

class color:
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    DARKCYAN = '\033[36m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

def scv_coeff(mean, variance):
    return (1 + (variance / (mean * mean))) / 2.0

def print_bold(string):
    print color.BOLD + string + color.END

def isclose(a, b, rel_tol=1e-09, abs_tol=0.0):
    return abs(a-b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)

def ms2us(val):
    return val * 1000

def ms2sec(val):
    return val / 1000.0

def us2ms(val):
    return val / 1000.0

def us2sec(val):
    return val / 1000000.0

def sec2us(val):
    return val * 1000000.0

def psec2pus(val):
    return val / 1000000.0

def pus2psec(val):
    return val * 1000000.0

def pms2psec(val):
    return val * 1000.0

def get_active_bes_from_updates(status_updates):
    active_bes_over_time = [[0, set([])]]
    for update in status_updates:

        update_time = us2sec(float(update[0]))
        be_name = update[1]
        be_state = update[2]

        active_bes = active_bes_over_time[-1][1].copy()
        active_bes_over_time[-1][1] = len(active_bes_over_time[-1][1])

        if (be_name in active_bes) and (be_state == "COLD"):
            active_bes.remove(be_name)

        elif (be_name not in active_bes) and \
             (be_state == "WARM" or be_state == "BUSY"):
            active_bes.add(be_name)

        active_bes_over_time.append([update_time, active_bes])
    
    active_bes_over_time[-1][1] = len(active_bes_over_time[-1][1])
    return active_bes_over_time

def make_non_decreasing(data):
    for i in range(1, len(data)):
        if (data[i][1] < data[i - 1][1]):
            data[i][1] = data[i - 1][1]
    return data

def non_decreasing_area_under_curve(data, start_x, end_x):
    prev_x, prev_y = start_x, 0
    area = 0.0

    for [x, y] in data:

        y = max(y, prev_y)
        area += (x - prev_x) * (y + prev_y) * 0.5
        prev_x, prev_y = x, y

    if (end_x > prev_x):
        area += (end_x - prev_x) * prev_y

    return area

def area_under_curve(data, start_x, end_x):
    prev_x, prev_y = start_x, 0
    area = 0.0

    for [x, y] in data:

        area += (x - prev_x) * (y + prev_y) * 0.5
        prev_x, prev_y = x, y

    if (end_x > prev_x):
        area += (end_x - prev_x) * prev_y

    return area

# assumes integral granularity for data
def get_umbrella_curve(data, delta):
    umbrella_curve = []

    prev_val = 0
    for i in range(0, int(data[-1][0])):

        start = i
        end = i + delta
        val = -1

        for j in range(0, len(data)):
            if data[j][0] >= start and data[j][0] <= end:
                val = max(val, data[j][1])

        if val == -1:
            val = prev_val

        umbrella_curve.append([start, val])
        prev_val = val

    return umbrella_curve

def add_setup_time_effect(data, delta):

    new_data = []

    index = 0
    prev_max_y = 0
    max_y = -1
    max_index = -1
    start = 0
    end = delta

    print 'window', start, end
    print 'index', index
    
    while (index < len(data)):

        x = data[index][0]
        y = data[index][1]

        if (x < start):
            index += 1
            print 'index', index
            continue

        elif (x >= start and x <= end):
            if (y > max_y):
                max_index = index
                max_y = y
            index += 1
            print 'index', index
            continue

        elif (x > start and x > end):
            if (max_y == -1):
                new_data.append(start, prev_max_y)
                new_data.append(x - delta, prev_max_y)
                start = x - delta
                end = x
                print 'window', start, end
                max_y = -1
                #index remains same
                print 'index', index
            else:
                new_data.append([start, max_y])
                new_data.append([end, max_y])
                start = data[max_index][0]
                end = start + delta
                print 'window', start, end
                prev_max_y = max_y
                max_y = -1
                index = max_index # + 1?
                print 'index', index
            continue

    return new_data

def write_addresses_to_file(addresses, filepath):
    fp = open(filepath, 'w')
    for address in addresses:
        fp.write(address[0] + ":" + address[1] + "\n")
    fp.close()

def moving_average(points, window_size, step_size):
    points_avg = []
    window = []
    window_end = 0

    for [x, y] in points:
        while (x >= window_end):
            if (len(window) == 0):
                points_avg.append([window_end, 0])
            else:
                points_avg.append([window_end, sum(w[1] for w in window)/float(len(window))])
            window_end += step_size

            if (len(window) > 0):
                for index in range(0, len(window)):
                    if (window[index][0] >= window_end - window_size):
                        break
                window = window[index:]

        window.append([x, y])

    return points_avg

def arrivals_us_to_reqs_per_sec_slow( arrivals_us, window_size_us, \
                                      step_size_us ):
    reqs_per_sec = []
    window = []
    window_end_us = 0

    for time_us in arrivals_us:

        while (time_us >= window_end_us):
            reqs_per_sec.append([ us2sec(window_end_us), \
                                  pus2psec(len(window)/float(window_size_us)) ])
            window_end_us += step_size_us
            if (len(window) > 0):
                for index in range(0, len(window)):
                    if (window[index] >= window_end_us - window_size_us):
                        break
                window = window[index:]

        window.append(time_us)

    return reqs_per_sec

def arrivals_us_to_reqs_per_sec(arrivals_us, window_size_us):
    max_arrival_us = max(arrivals_us)
    num_windows = math.ceil(max_arrival_us / window_size_us)
    req_rates = []
    for index in range(0, int(num_windows)):
        req_rates.append([(index + 1) * window_size_us, 0])
    for arrival_us in arrivals_us:
        index = math.floor(arrival_us / window_size_us)
        req_rates[int(index)][1] += 1
    for i in range(0, len(req_rates)):
        req_rates[i][1] /= float(window_size_us)
    for i in range(0, len(req_rates)):
        req_rates[i][0] = us2sec(req_rates[i][0])
        req_rates[i][1] = pus2psec(req_rates[i][1])
    return req_rates

def rand_wait_time_pdf( arrival_rate, service_time, num_servers, wait_time, \
                        delay_fe2be, delay_be2fe, delay_bet_retries ):
    delta = delay_bet_retries
    d_1 = delay_fe2be
    d_2 = delay_be2fe

    if ((wait_time - d_1) % (d_1 + d_2 + delta) == 0):
        num_retries = (wait_time - d_1) / (d_1 + d_2 + delta)
        p_b = float(service_time * arrival_rate) / num_servers
        return math.pow(p_b, num_retries) * (1 - p_b)
    
    return 0

def rand_wait_time_ppf( arrival_rate, service_time, num_servers, percentile, \
                        delay_fe2be, delay_be2fe, delay_bet_retries ):
    p_b = float(service_time * arrival_rate) / num_servers
    pc = percentile / 100.0
    delta = delay_bet_retries
    d_1 = delay_fe2be
    d_2 = delay_be2fe

    wt = ((math.log(1 - pc) / math.log(p_b)) - 1)
    wt *= (d_1 + d_2 + delta)
    wt += d_1

    #wt = d_1
    #wt += (d_1 + d_2 + delta) * ((math.log(1 - pc) / math.log(p_b)) - 1)

    if (wt < 0):
        wt = 0

    return wt

def pod_wait_time_ppf( arrival_rate, service_time, num_servers, percentile, \
                       delay_fe2be, delay_be2fe, delay_bet_retries, pod_size ):
    p_b1 = float(service_time * arrival_rate) / num_servers
    p_b1 *= 8.0
    p_b1 += 1.0
    p_b1 = math.sqrt(p_b1) - 1.0
    p_b1 /= 2.0
    p_b = math.pow(p_b1, pod_size)
    pc = percentile / 100.0
    delta = delay_bet_retries
    d_1 = delay_fe2be
    d_2 = delay_be2fe
    wt = d_1
    wt += (d_1 + d_2 + delta) * ((math.log(1 - pc) / math.log(p_b)) - 1)
    if (wt < 0):
        wt = 0
    return wt

def rand_resp_time_cdf( arrival_rate, service_time, num_servers, resp_time, \
                        delay_fe2be, delay_be2fe, delay_bet_retries, st_params ):

    p_busy = float(service_time * arrival_rate) / num_servers
    p_idle = 1.0 - p_busy

    r_max = math.floor( (resp_time - delay_fe2be) / \
                        (delay_fe2be + delay_be2fe + delay_bet_retries) )

    cdf = 0

    for r in range(0, int(r_max) + 1):

        wait_time = r
        wait_time *= (delay_fe2be + delay_be2fe + delay_bet_retries)
        wait_time += delay_fe2be

        assert (wait_time <= resp_time)

        prob_wt = math.pow(p_busy, r) * p_idle
        x = resp_time - wait_time

        if (x < 0):
            break

        prob_st = scipy.stats.lognorm.cdf(x, st_params[0], st_params[1], st_params[2])

        cdf += (prob_wt * prob_st)

    return cdf

def rand_resp_time_ppf_slow( arrival_rate, service_time, num_servers, percentile, \
                             delay_fe2be, delay_be2fe, delay_bet_retries, st_params ):

    rt_us = rand_wait_time_ppf( arrival_rate, service_time, num_servers, \
                                percentile, delay_fe2be, delay_be2fe, \
                                delay_bet_retries )
    cdf = 0

    while (cdf < (percentile / 100.0)):

        cdf = rand_resp_time_cdf ( arrival_rate, service_time, num_servers, \
                                   rt_us, delay_fe2be, delay_be2fe, \
                                   delay_bet_retries, st_params )

        rt_us += 1000

    return rt_us - 1000

def rand_resp_time_ppf( arrival_rate, service_time, num_servers, percentile, \
                        delay_fe2be, delay_be2fe, delay_bet_retries, st_params ):

    rt_us = rand_wait_time_ppf( arrival_rate, service_time, num_servers, \
                                percentile, delay_fe2be, delay_be2fe, \
                                delay_bet_retries )

    low = 1
    high = service_time * 10

    while(low <= high):

        mid = (low + high) / 2

        cdf = rand_resp_time_cdf ( arrival_rate, service_time, num_servers, \
                                   mid, delay_fe2be, delay_be2fe, \
                                   delay_bet_retries, st_params )

        if (cdf < (percentile / 100.0)):
            low = mid + 1
        elif (cdf > (percentile / 100.0)):
            high = mid - 1
        else:
            return mid
    
    return high

def arrivals_ms_to_reqs_per_sec_slow( arrivals_ms, window_size_ms, \
                                      step_size_ms ):
    reqs_per_sec = []
    window = []
    window_end_ms = 0

    for time_ms in arrivals_ms:

        while (time_ms >= window_end_ms):

            if (len(window) == 0):
                window_end_ms = (time_ms - (time_ms % step_size_ms)) + step_size_ms
                break;

            window_end_ms += step_size_ms
            window[:] = [ x for x in window if (x >= window_end_ms - window_size_ms) ]

        window.append(time_ms)
        rate = pms2psec(len(window)/float(window_size_ms))
        reqs_per_sec.append([ms2sec(window_end_ms), rate])

    return reqs_per_sec

def extract_lognorm_params(filename):
    data_ms = numpy.loadtxt(filename)
    data_us = [ (1000 * x) for x in data_ms ]
    return scipy.stats.lognorm.fit(data_us)

def make_first_col_relative_1(data):
    if (len(data) == 0):
        return data
    first = data[0]
    processed_data = [ (x - first) for x in data ]
    return processed_data

def make_first_col_relative_2(data):
    if (len(data) == 0):
        return data
    first = data[0][0]
    processed_data = [ [(x - first), y] for [x, y] in data ]
    return processed_data
