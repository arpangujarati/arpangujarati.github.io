#!/usr/bin/python

import os, sys

FILEPATH = os.path.dirname(os.path.realpath(__file__))
sys.path.append(FILEPATH + "/..")

PATH = os.path.dirname(os.path.dirname(FILEPATH))

import subprocess, argparse, glob, copy
import math, time, numpy, pprint
import traceback, logging
import uuid
import dateutil.parser

import scipy
import scipy.stats 

from utils.misc import *

EMERG, FATAL, ALERT, CRIT, ERROR  = 0, 0, 100, 200, 300
WARN, NOTICE, INFO, DEBUG, NOTSET = 400, 500, 600, 700, 800
POISSON_STEP, UNIFORM_STEP = "poisson-step", "uniform-step"
CONST, EXPON, LOGNORM = "const", "expon", "lognorm"
WG, BS, CL, BR, FE, BE = "wg", "bs", "cl", "br", "fe", "be"

DEFAULT_WINDOW_SIZE_MS = 100 * 1000 # 100 seconds
DEFAULT_STEP_SIZE_MS = 10 * 1000 # 10 seconds

NEW_PRODUCTION = "new-production"

class AzmlArgs(object):

    def __init__(self):
        self.debug_level = NOTSET

    def __str__(self):
        attrs = []
        for key in self.__dict__:
            attrs.append("{key}='{value}'".format(
                key=key, value=self.__dict__[key] ))
        return ', '.join(attrs)

    def __repr__(self):
        return self.__str__()

class Azml(object):
    def __init__(self, args):
        print "Initializing Azml..."

        self.epoch_time = int(time.time())
        self.expid = time.strftime('%Y%m%d_%H%M%S', time.localtime(self.epoch_time))
        self.expid += '_' + str(uuid.uuid1())

        self.debug_level = args.debug_level
        self.sys_or_sim = args.sys_or_sim
        self.lb_type = args.lb_type

        self.init_dir_paths(args)
        self.create_nfs_log_dir(args)
        self.assign_hosts_to_servers(args)

    def init_dir_paths(self, args):
        self.nfs_log_dir = PATH + "/logs/"
        self.plots_dir   = PATH + "/plots/"
        self.trace_dir   = PATH + "/traces/0/"
        self.data_dir    = PATH + "/data/"

        self.config_dir = PATH + "/config/"
        self.hosts = numpy.loadtxt(self.config_dir + "/hosts.txt", dtype=str)

        if (self.sys_or_sim == "sys"):
            self.local_log_dir = "/local/azml-logs/%s/" % self.expid
            self.local_exe_dir = "/local/azml-exes/"

    def create_nfs_log_dir(self, args):
        cmd = 'rm -rf ' + self.nfs_log_dir + '; mkdir ' + self.nfs_log_dir
        assert(subprocess.call(cmd, shell=True) == 0)

    def assign_hosts_to_servers(self, args):
        self.server_counts_str = "numservers_%s-%s-%s-%s" % \
            (1, 1, args.num_fes, args.num_bes)

        self.active_hosts = []
        fe_servers_per_host = 8.0
        be_servers_per_host = 8.0

        num_client_hosts   = 1
        num_broker_hosts   = 1
        num_frontend_hosts = math.ceil( args.num_fes / \
                                        fe_servers_per_host );
        num_backend_hosts  = math.ceil( args.num_bes / \
                                        be_servers_per_host );

        total_hosts_required = num_client_hosts + num_broker_hosts + \
                               num_frontend_hosts + num_backend_hosts
        assert (total_hosts_required <= len(self.hosts))

        self.client_addresses   = []
        self.broker_addresses   = []
        self.frontend_addresses = []
        self.backend_addresses  = []

        self.client_addresses.append([self.hosts[0], str(8080)])
        self.broker_addresses.append([self.hosts[1], str(8080)])
        self.active_hosts.append(self.hosts[0])
        self.active_hosts.append(self.hosts[1])
        hosts_assigned = 2

        base_port = 8080
        last_port = int(8080 + fe_servers_per_host - 1)
        for i in range(0, args.num_fes):
            host = self.hosts[hosts_assigned]
            port = str(int(base_port + (i % fe_servers_per_host)))
            self.frontend_addresses.append([host, port])
            if (port == str(last_port) or i == args.num_fes - 1):
                self.active_hosts.append(self.hosts[hosts_assigned])
                hosts_assigned += 1

        last_port = int(8080 + be_servers_per_host - 1)
        for i in range(0, args.num_bes):
            host = self.hosts[hosts_assigned]
            port = str(int(base_port + (i % be_servers_per_host)))
            self.backend_addresses.append([host, port])
            if (port == str(last_port) or i == args.num_bes - 1):
                self.active_hosts.append(self.hosts[hosts_assigned])
                hosts_assigned += 1

        assert (hosts_assigned == total_hosts_required)

        self.client_addresses_file   = self.config_dir + "client.txt"
        self.broker_addresses_file   = self.config_dir + "broker.txt"
        self.frontend_addresses_file = self.config_dir + "frontend.txt"
        self.backend_addresses_file  = self.config_dir + "backend.txt"

        write_addresses_to_file( self.client_addresses, \
                                 self.client_addresses_file )
        write_addresses_to_file( self.broker_addresses, \
                                 self.broker_addresses_file )
        write_addresses_to_file( self.frontend_addresses, \
                                 self.frontend_addresses_file )
        write_addresses_to_file( self.backend_addresses, \
                                 self.backend_addresses_file )

        cores_per_host = 32
        self.num_broker_threads   = "32"
        self.num_client_threads   = "16"
        self.num_frontend_threads = str(int(cores_per_host/fe_servers_per_host))
        self.num_backend_threads  = str(int(cores_per_host/be_servers_per_host))

        self.config_host = self.client_addresses[0][0]

    def set_sla_params(self, args):
        self.sla_pc = args.sla_pc
        self.sla_rt_ms = args.sla_rt_ms
        self.sla_params_str = "sla=%sms-%spc" % (self.sla_rt_ms, self.sla_pc)

    def set_wkld_params(self, args):
        if (args.workload_type == POISSON_STEP):
            self.set_syn_workload_params(args)
        elif(args.workload_type == NEW_PRODUCTION):
            self.set_new_prod_workload_params(args)
        else:
            assert (False)

    def set_syn_workload_params(self, args):
        self.workload_type = args.workload_type
        self.num_reqs = args.num_reqs
        self.exe_time_mean_ms = args.exe_time_mean_ms
        self.setup_time_mean_ms = args.setup_time_mean_ms
        self.reqs_per_sec = args.reqs_per_sec
        self.step_seq = args.step_seq
        self.workload_param_str = "workload=%s-%s-%srps-%sms-%sms-%s" % \
            ( args.workload_type, args.num_reqs, args.reqs_per_sec, \
              args.exe_time_mean_ms, args.setup_time_mean_ms, args.step_seq )

        self.num_reqs_expected = \
            Azml.get_num_reqs_expected(args.num_reqs, args.step_seq)

    def set_new_prod_workload_params(self, args):
        self.workload_type = args.workload_type
        self.num_reqs_expected = args.num_reqs
        self.exe_time_mean_ms = args.exe_time_mean_ms
        self.setup_time_mean_ms = args.setup_time_mean_ms
        self.workload_param_str = "workload=prod-%s" % args.trace_id
        print "num_reqs_expected", self.num_reqs_expected

    def output_config_params(self, args):
        print "Unique ID...", self.expid
        print "Workload parameters...", self.workload_param_str
        print "Server parameters...", self.server_counts_str
        print "SLA parameters...", self.sla_params_str

    def cleanup_before_exit(self):
        print "Cleaning up before exiting..."
        #raw_input("Press Enter to continue...")
        #if hasattr(self, "tracefile"):
        #    subprocess.call("rm " + self.tracefile, shell=True)
        subprocess.call("rm " + self.client_addresses_file, shell=True)
        subprocess.call("rm " + self.broker_addresses_file, shell=True)
        subprocess.call("rm " + self.frontend_addresses_file, shell=True)
        subprocess.call("rm " + self.backend_addresses_file, shell=True)
        #subprocess.call("rm " + PATH + "/config/setup_times.txt", shell=True)
        #input("Press Enter to continue...")

    def get_nfs_log_files(self, server_type):
        return self.nfs_log_dir + server_type + "*.log"

    def get_nfs_log_file(self, server_type, hostname = None, port = None):
        if hostname == None and port == None:
            return "%s%s.log" % (self.nfs_log_dir, server_type)
        else:
            return "%s%s_%s_%s.log" % ( self.nfs_log_dir, server_type, \
                                        hostname, port )

    def get_nfs_out_file(self, server_type, hostname = None, port = None):
        if hostname == None and port == None:
            return "%s%s.out" % (self.nfs_log_dir, server_type)
        else:
            return "%s%s_%s_%s.out" % ( self.nfs_log_dir, server_type, \
                                        hostname, port )

    def exe_cmd_1(self, input_files, output_file, keyword):
        cmd = "cat " + input_files + " | grep \"" + keyword + "\" | " + \
              "cut -d \" \" -f 6- | sort -n > " + output_file
        subprocess.call(cmd, shell=True);

    def is_sla_satisfied_helper(self, args, log_files):
        print "Checking if SLA satisfied..."
        subprocess.call("mkdir -p " + PATH + "/data", shell=True)
        subprocess.call("rm -f " + PATH + "/data/*", shell=True)
        datafile = PATH + "/data/rt.data"
        self.exe_cmd_1(log_files, datafile, "STATS_RESPONSE_TIME")
        rts = [ us2ms(y) for [x, y] in numpy.loadtxt(datafile, ndmin=2) ]
        percentile_rt = numpy.percentile(rts, self.sla_pc)
        self.sla_satisfied = (percentile_rt <= self.sla_rt_ms)
        print_bold( "INTERMEDIATE-STATS #BEs=%d %dth-percentile-rt=%dms rt-sla=%dms" % \
            (args.num_bes, self.sla_pc, percentile_rt, self.sla_rt_ms) )

    def compute_wt_distr_helper(self, args, log_files):
        print "Computing the waiting time distribution..."
        subprocess.call("mkdir -p " + PATH + "/data", shell=True)
        subprocess.call("rm -f " + PATH + "/data/*", shell=True)
        datafile = PATH + "/data/wt_distr.data"
        self.exe_cmd_1(log_files, datafile, "STATS_WAITING_TIME")
        wts = [ us2ms(y) for [x, y] in numpy.loadtxt(datafile, ndmin=2) ]
        self.wt_distr = []
        for i in range(1, 100):
            self.wt_distr.append([i, numpy.percentile(wts, i)])

    def compute_percentile_wt_helper(self, args, log_files):
        print "Computing the percentile waiting time..."
        subprocess.call("mkdir -p " + PATH + "/data", shell=True)
        subprocess.call("rm -f " + PATH + "/data/*", shell=True)
        datafile = PATH + "/data/wt.data"
        self.exe_cmd_1(log_files, datafile, "STATS_WAITING_TIME")
        wts = [ us2ms(y) for [x, y] in numpy.loadtxt(datafile, ndmin=2) ]
        #self.percentile_wt_ms = numpy.percentile(wts, args.sla_pc)
        self.perc_wt_ms = numpy.percentile(wts, 99)

    def compute_percentile_rt_helper(self, args, log_files):
        print "Computing the percentile response time..."
        subprocess.call("mkdir -p " + PATH + "/data", shell=True)
        subprocess.call("rm -f " + PATH + "/data/*", shell=True)
        datafile = PATH + "/data/rt.data"
        self.exe_cmd_1(log_files, datafile, "STATS_RESPONSE_TIME")
        rts = [ us2ms(y) for [x, y] in numpy.loadtxt(datafile, ndmin=2) ]
        #self.percentile_rt_ms = numpy.percentile(rts, args.sla_pc)
        self.perc_rt_ms = numpy.percentile(rts, 99)

    def compute_generated_request_rates_helper(self, args, log_files):
        print "Computing generated request rates..."
        subprocess.call("mkdir -p " + PATH + "/data", shell=True)
        subprocess.call("rm -f " + PATH + "/data/*", shell=True)
        datafile = PATH + "/data/rr_generated.data"
        self.exe_cmd_1(log_files, datafile, "STATS_NEW_REQUEST")
        arrivals_ms = [us2ms(x) for x in numpy.loadtxt(datafile, ndmin=1)]
        arrivals_ms = make_first_col_relative_1(arrivals_ms)
        self.generated_request_rates = arrivals_ms_to_reqs_per_sec_slow( \
            arrivals_ms, DEFAULT_WINDOW_SIZE_MS, DEFAULT_STEP_SIZE_MS )  

    def compute_estimated_request_rates_helper(self, args, log_files):
        print "Computing estimated request rates..."
        subprocess.call("mkdir -p " + PATH + "/data", shell=True)
        subprocess.call("rm -f " + PATH + "/data/*", shell=True)
        datafile = PATH + "/data/rr_estimated.data"
        self.exe_cmd_1(log_files, datafile, "STATS_ESTIMATED_RATE")
        request_rates = [ [us2sec(x), pus2psec(y)] for [x, y] \
                          in numpy.loadtxt(datafile, ndmin=2) ]
        self.estimated_request_rates = make_first_col_relative_2(request_rates)
        #self.estimated_request_rates = request_rates

    def compute_predicted_request_rates_helper(self, args, log_files):
        print "Computing predicted request rates..."
        subprocess.call("mkdir -p " + PATH + "/data", shell=True)
        subprocess.call("rm -f " + PATH + "/data/*", shell=True)
        datafile = PATH + "/data/rr_predicted.data"
        self.exe_cmd_1(log_files, datafile, "STATS_PREDICTED_RATE")
        request_rates = [ [us2sec(x), pus2psec(y)] for [x, y] \
                          in numpy.loadtxt(datafile, ndmin=2) ]
        self.predicted_request_rates = make_first_col_relative_2(request_rates)
        #self.predicted_request_rates = request_rates

    def __str__(self):
        val = self.expid
        val += "_" + self.workload_param_str
        val += "_" + self.server_counts_str
        val += "_" + self.sla_params_str
        return val

    @staticmethod
    def get_num_reqs_expected(num_reqs, step_seq):
        num_reqs_expected = 0
        for multiplier in [ float(x) for x in step_seq.split('-') ]:
            num_reqs *= multiplier
            num_reqs_expected += num_reqs
        return num_reqs_expected

    @staticmethod
    def qt_analysis_min_bes( scv, max_bes, sla_pc, rpus, exe_time_mean_us, \
                             sla_rt_ms ):
        cmd = PATH + "/analysis/azml_qt_analysis min-bes " + str(scv) + " " + \
              str(max_bes) + " " + str(sla_pc) + " " + str(rpus) + " " + \
              str(exe_time_mean_us) + " " + str(ms2us(sla_rt_ms))
        output = subprocess.check_output(cmd, shell=True)
        return output

    @staticmethod
    def qt_analysis_wt(scv, num_bes, sla_pc, rpus, exe_time_mean_us):
        cmd = PATH + "/analysis/azml_qt_analysis wt " + str(scv) + " " + \
              str(num_bes) + " " + str(sla_pc) + " " + str(rpus) + " " + \
              str(exe_time_mean_us)
        output = subprocess.check_output(cmd, shell=True)
        return output

    @staticmethod
    def setup_config_dir(num_fe_servers, num_be_servers):
        config_dir = PATH + "/config/"
        hosts = numpy.loadtxt(config_dir + "/hosts.txt", dtype=str)

        server_counts_str = "numservers_%s-%s-%s-%s" % \
            (1, 1, num_fe_servers, num_be_servers)

        active_hosts = []
        fe_servers_per_host = 8.0
        be_servers_per_host = 8.0

        num_client_hosts   = 1
        num_broker_hosts   = 1
        num_frontend_hosts = math.ceil(num_fe_servers / fe_servers_per_host);
        num_backend_hosts  = math.ceil(num_be_servers / be_servers_per_host);

        total_hosts_required = num_client_hosts + num_broker_hosts + \
                               num_frontend_hosts + num_backend_hosts
        assert (total_hosts_required <= len(hosts))

        client_addresses   = []
        broker_addresses   = []
        frontend_addresses = []
        backend_addresses  = []

        client_addresses.append([hosts[0], str(8080)])
        broker_addresses.append([hosts[1], str(8080)])
        active_hosts.append(hosts[0])
        active_hosts.append(hosts[1])
        hosts_assigned = 2

        base_port = 8080
        last_port = int(8080 + fe_servers_per_host - 1)
        for i in range(0, num_fe_servers):
            host = hosts[hosts_assigned]
            port = str(int(base_port + (i % fe_servers_per_host)))
            frontend_addresses.append([host, port])
            if (port == str(last_port) or i == num_fe_servers - 1):
                active_hosts.append(hosts[hosts_assigned])
                hosts_assigned += 1

        last_port = int(8080 + be_servers_per_host - 1)
        for i in range(0, num_be_servers):
            host = hosts[hosts_assigned]
            port = str(int(base_port + (i % be_servers_per_host)))
            backend_addresses.append([host, port])
            if (port == str(last_port) or i == num_be_servers - 1):
                active_hosts.append(hosts[hosts_assigned])
                hosts_assigned += 1

        assert (hosts_assigned == total_hosts_required)

        client_addresses_file   = config_dir + "client.txt"
        broker_addresses_file   = config_dir + "broker.txt"
        frontend_addresses_file = config_dir + "frontend.txt"
        backend_addresses_file  = config_dir + "backend.txt"

        write_addresses_to_file(client_addresses, client_addresses_file)
        write_addresses_to_file(broker_addresses, broker_addresses_file)
        write_addresses_to_file(frontend_addresses, frontend_addresses_file)
        write_addresses_to_file(backend_addresses, backend_addresses_file)

        cores_per_host = 32
        num_broker_threads   = "32"
        num_client_threads   = "16"
        num_frontend_threads = str(int(cores_per_host/fe_servers_per_host))
        num_backend_threads  = str(int(cores_per_host/be_servers_per_host))

    @staticmethod
    def get_sla_params(args):
        return "sla=%sms-%spc" % (args.sla_rt_ms, args.sla_pc)

    @staticmethod
    def get_wkld_params(args):

        if (args.workload_type == POISSON_STEP):
            return "workload=%s-%s-%srps-%sms-%sms-%s" % \
                   ( args.workload_type, args.num_reqs, args.reqs_per_sec, \
                     args.exe_time_mean_ms, args.setup_time_mean_ms, \
                     args.step_seq )

        elif (args.workload_type == NEW_PRODUCTION):
            return "workload=prod-%s" % args.trace_id

        else:
            assert (False)

class AzmlSys(Azml):

    def __init__(self, args):
        print "Initializing AzmlSys(Azml)..."
        Azml.__init__(self, args)
        self.make_local_dirs(args)
        self.init_local_exe_paths(args)

    def make_local_dirs(self, args):
        for host in self.hosts:
            ssh_cmd = "ssh %s \"mkdir -p %s; mkdir -p %s\"" % \
                (host, self.local_exe_dir, self.local_log_dir)
            subprocess.call(ssh_cmd, shell=True)

    def init_local_exe_paths(self, args):
        prefix = self.local_exe_dir + "azml_sys_"
        self.generator_exe     = prefix + "b1_wg"
        self.client_exe        = prefix + "b1_cl"
        self.broker_exe        = prefix + "b1_br"
        self.frontend_exe      = prefix + args.version + "_fe"
        self.backend_exe       = prefix + args.version + "_be"

    def move_exes_from_nfs_to_local(self, args):

        sys_exes_nfs = [ PATH + "/generator/azml_sys_b1_wg", \
                         PATH + "/client/azml_sys_b1_cl", \
                         PATH + "/broker/azml_sys_b1_br", \
                         PATH + "/frontend/azml_sys_" + args.version + "_fe", \
                         PATH + "/backend/azml_sys_" + args.version + "_be" ]

        print "Removing old executables from " + self.local_exe_dir
        for host in self.hosts:
            ssh_cmd = "ssh " + host + " \"rm -rf " + self.local_exe_dir + "/* \""
            subprocess.call(ssh_cmd, shell=True)

        print "Copying executables from nfs to " + self.local_exe_dir
        for host in self.hosts:
            ssh_cmd = "ssh %s \"" % host
            for exe_nfs in sys_exes_nfs:
                ssh_cmd += "cp " + exe_nfs + " " + self.local_exe_dir + ". ; "
            ssh_cmd += "\""
            subprocess.call(ssh_cmd, shell=True)

    def start_servers(self):
        self.start_client_servers()
        self.start_broker_servers()
        self.start_frontend_servers()
        self.start_backend_servers()
        
    def start_client_servers(self):
        print "Starting client servers..."
        for [host, port] in self.client_addresses:
            cmd  = "%s " % self.client_exe
            cmd += "%s:%s " % (host, port)
            cmd += "%s %s " % (self.config_dir, self.num_client_threads)
            cmd += "%s %s " % ( self.debug_level, \
                                self.get_local_log_file(CL, host, port) )
            cmd += "%s " % self.epoch_time
            cmd += "%s " % self.num_reqs_expected
            cmd += ">& %s &" % self.get_local_out_file(CL, host, port)
            ssh_cmd = "ssh %s \"%s\"" % (host, cmd)
            assert (subprocess.call(ssh_cmd, shell=True) == 0)

    def start_broker_servers(self):
        print "Starting broker servers..."
        for [host, port] in self.broker_addresses:
            cmd  = "%s " % self.broker_exe
            cmd += "%s:%s " % (host, port)
            cmd += "%s %s " % (self.config_dir, self.num_broker_threads)
            cmd += "%s %s " % ( self.debug_level, \
                                self.get_local_log_file(BR, host, port) )
            cmd += "%s " % self.epoch_time
            cmd += ">& %s &" % self.get_local_out_file(BR, host, port)
            ssh_cmd = "ssh %s \"%s\"" % (host, cmd)
            assert (subprocess.call(ssh_cmd, shell=True) == 0)

    def start_frontend_servers(self):
        print "Starting frontend servers..."
        for [host, port] in self.frontend_addresses:
            cmd  = "%s " % self.frontend_exe
            cmd += "%s:%s " % (host, port)
            cmd += "%s %s " % (self.config_dir, self.num_frontend_threads)
            cmd += "%s %s " % ( self.debug_level, \
                                self.get_local_log_file(FE, host, port) )
            cmd += "%s " % self.epoch_time
            cmd += ">& %s &" % self.get_local_out_file(FE, host, port)
            ssh_cmd = "ssh %s \"%s\"" % (host, cmd)
            assert (subprocess.call(ssh_cmd, shell=True) == 0)

    def start_backend_servers(self):
        print "Starting backend servers..."
        for [host, port] in self.backend_addresses:
            cmd  = "%s " % self.backend_exe
            cmd += "%s:%s " % (host, port)
            cmd += "%s %s " % (self.config_dir, self.num_backend_threads)
            cmd += "%s %s " % ( self.debug_level, \
                                self.get_local_log_file(BE, host, port) )
            cmd += "%s " % self.epoch_time
            cmd += ">& %s &" % self.get_local_out_file(BE, host, port)
            ssh_cmd = "ssh %s \"%s\"" % (host, cmd)
            assert (subprocess.call(ssh_cmd, shell=True) == 0)

    def start_workload_generation(self):
        print "Starting workload generation... sys"
        print "Total number of requests expected...", self.num_reqs_expected
        cmd  = "%s " % self.generator_exe
        cmd += "%s %s " % (self.config_dir, self.debug_level)
        cmd += "%s %s " % (self.get_local_log_file(WG), self.epoch_time)
        #cmd += "%s " % (self.workload_type)
        #cmd += "%s %s " % (self.num_reqs_expected, ms2us(self.exe_time_mean_ms))
        #cmd += "%s " % ms2us(self.setup_time_mean_ms)
        #cmd += "%s %s " % (psec2pus(self.reqs_per_sec), self.step_seq)
        cmd += ">& %s &" % self.get_local_out_file(WG)
        ssh_cmd = "ssh %s \"%s\"" % (self.config_host, cmd)
        assert (subprocess.call(ssh_cmd, shell=True) == 0)

    def wait(self, sec=None):
        if (sec == None):
            print "Waiting for the experiments to finish..."
            raw_input("Press enter once the experiments have finished...")
        else:
            print "Waiting for " + str(sec) + " seconds..."
            time.sleep(sec)

    def stop_servers(self):
        print "Stopping all servers..."
        for host in self.hosts:
            cmd = "ssh %s \"pkill azml &\"" % host
            result = subprocess.call(cmd, shell=True)
            assert (result == 0)

    def is_sla_satisfied(self, args):
        self.is_sla_satisfied_helper(args, self.get_nfs_log_files(CL))

    def compute_percentile_wt(self, args):
        self.compute_percentile_wt_helper(args, self.get_nfs_log_files(CL))

    def compute_generated_request_rates(self, args):
        self.compute_generated_request_rates_helper(args, self.get_nfs_log_files(WG))

    def compute_estimated_request_rates(self, args):
        self.compute_estimated_request_rates_helper(args, self.get_nfs_log_files(FE))

    def compute_predicted_request_rates(self, args):
        self.compute_predicted_request_rates_helper(args, self.get_nfs_log_files(FE))

    def copy_logs_from_local_to_nfs(self):
        print "Copying results from %s to nfs..." % self.local_log_dir
        subprocess.call(("mkdir -p %s" % self.nfs_log_dir), shell=True)
        subprocess.call(("rm -f %s*" % self.nfs_log_dir), shell=True)

        if self.sys_or_sim == "sys":
            for host in self.active_hosts:
                cmd = "ssh %s \"cp -r %s* %s/.\"" % \
                    (host, self.local_log_dir, self.nfs_log_dir)
                subprocess.call(cmd, shell=True)
        else:
            self.sys_or_sim == "sim"
            cmd = "ssh %s \"cp -r %s* %s/.\"" % \
                (self.config_host, self.local_log_dir, self.nfs_log_dir)
            subprocess.call(cmd, shell=True)

    def get_local_log_file(self, server_type, hostname = None, port = None):
        if hostname == None and port == None:
            return "%s%s.log" % (self.local_log_dir, server_type)
        else:
            return "%s%s_%s_%s.log" % ( self.local_log_dir, server_type, \
                                        hostname, port )

    def get_local_out_file(self, server_type, hostname = None, port = None):
        if hostname == None and port == None:
            return "%s%s.out" % (self.local_log_dir, server_type)
        else:
            return "%s%s_%s_%s.out" % ( self.local_log_dir, server_type, \
                                        hostname, port )

class AzmlSim(Azml):

    def __init__(self, args):
        print "Initializing AzmlSim(Azml)..."
        Azml.__init__(self, args)
        self.init_nfs_exe_paths(args)

    def init_nfs_exe_paths(self, args):
        self.simulation_exe    = PATH + "/simulation/azml_sim"

    def run(self, args):
        [host, port] = self.client_addresses[0]
        cmd  = "%s " % self.simulation_exe
        cmd += "%s %s " % (self.config_dir, self.debug_level)
        cmd += "%s %s " % (self.get_nfs_log_file(BS), args.version)
        cmd += "%s " % self.lb_type
        print "Starting simulation...", cmd
        assert (subprocess.call(cmd, shell=True) == 0)

    def is_sla_satisfied(self, args):
        self.is_sla_satisfied_helper(args, self.get_nfs_log_files(BS))

    def compute_wt_distr(self, args):
        self.compute_wt_distr_helper(args, self.get_nfs_log_files(BS))

    def compute_percentile_wt(self, args):
        self.compute_percentile_wt_helper(args, self.get_nfs_log_files(BS))

    def compute_percentile_rt(self, args):
        self.compute_percentile_rt_helper(args, self.get_nfs_log_files(BS))

    def compute_generated_request_rates(self, args):
        self.compute_generated_request_rates_helper(args, self.get_nfs_log_files(BS))

    def compute_estimated_request_rates(self, args):
        self.compute_estimated_request_rates_helper(args, self.get_nfs_log_files(BS))

    def compute_predicted_request_rates(self, args):
        self.compute_predicted_request_rates_helper(args, self.get_nfs_log_files(BS))

    @staticmethod
    def gen_wkld( workload_type, step_seq, num_reqs, exe_time_mean_ms, \
                  setup_time_mean_ms, reqs_per_sec, log_file ):

        print "Starting workload generation for simulation..."
        print "Total number of requests expected...", \
              Azml.get_num_reqs_expected(num_reqs, step_seq)

        exe  = PATH + "/generator/azml_generator "
        args = PATH + "/config/ " + str(NOTSET) + " " + log_file + " sim " + \
               workload_type + " " + str(num_reqs) + " " + \
               str(ms2us(exe_time_mean_ms)) + " " + \
               str(ms2us(setup_time_mean_ms)) + " " + \
               str(psec2pus(reqs_per_sec)) + " " + step_seq

        assert (subprocess.call(exe + args, shell=True) == 0)

    @staticmethod
    def gen_wkld_py( arrival_rate, service_time_distr, service_time_params, \
                     num_reqs, trace_output_file, setup_times_file ):

        inter_arrival_times = scipy.stats.expon.rvs( scale=(1.0/arrival_rate), \
                                                     size=num_reqs )

        if (service_time_distr == CONST):
            assert (len(service_time_params) == 1)
            service_times = [service_time_params[0]] * num_reqs
        elif (service_time_distr == EXPON):
            assert (len(service_time_params) == 1)
            service_times = scipy.stats.expon.rvs( loc=0, \
                scale=service_time_params[0], size=num_reqs )
        elif (service_time_distr == LOGNORM):
            assert (len(service_time_params) == 3)
            service_times = scipy.stats.lognorm.rvs(service_time_params[0], \
                loc=service_time_params[1], scale=service_time_params[2], \
                size=num_reqs ) 
        else:
            assert (False)

        subprocess.call("rm -f " + trace_output_file, shell=True)
        fp = open(trace_output_file, 'w')

        arrival_time = 0
        service_id = 0
        request_id = 0

        assert (len(inter_arrival_times) == len(service_times))
        for i in range(len(service_times)):
            request_id += 1
            arrival_time += int(inter_arrival_times[i])
            service_time = int(service_times[i])
            if (service_time == 0):
                service_time = 1
            fp.write( str(arrival_time) + " " + str(service_id) + " " + \
                      str(request_id) + " " + str(service_time) + "\n" )
        fp.close()

        fp = open(setup_times_file, 'w')
        mean_exe_time = scipy.stats.lognorm.mean( service_time_params[0], \
            loc=service_time_params[1], scale=service_time_params[2] )
        fp.write('0 0 ' + str(int(mean_exe_time)) + '\n')
        fp.close()

    @staticmethod
    def gen_prod_wkld_py(filename, trace_output_file, setup_times_file):
        arrivals = numpy.loadtxt(filename, dtype=str, ndmin=2)

        subprocess.call("rm -f " + trace_output_file, shell=True)
        fp = open(trace_output_file, 'w')

        service_id = 0
        request_id = 0

        zero_time_str = arrivals[0][0] + " " + arrivals[0][1]
        zero_time = dateutil.parser.parse(zero_time_str)

        subprocess.call("rm -f " + trace_output_file, shell=True)
        fp = open(trace_output_file, 'w')

        service_times_us = []

        for arrival in arrivals:
            request_id += 1

            arrival_time = dateutil.parser.parse(arrival[0] + " " + arrival[1])
            diff = arrival_time - zero_time
            arrival_time_us = int(sec2us(diff.total_seconds()))

            service_time_us = int(ms2us(float(arrival[2])))
            service_times_us.append(service_time_us)

            fp.write( str(arrival_time_us) + " " + str(service_id) + " " + \
                      str(request_id) + " " + str(service_time_us) + "\n" )

        fp.close()

        fp = open(setup_times_file, 'w')
        mean_exe_time = numpy.mean(service_times_us)
        mean_setup_time = 0
        fp.write( '0 ' + str(int(mean_setup_time)) + ' ' + \
                   str(int(mean_exe_time)) + '\n')
        fp.close()

        return len(arrivals), mean_exe_time, mean_setup_time

    """
    @staticmethod
    def move_sim_exe_to_local(version):
        print "Copying simulation version:%s exe from nfs to local..." % version
        cmd = "cp " + PATH + "/simulation/azml_sim" + " " + "/local/azml-exes/."
        print cmd
        assert(subprocess.call(cmd, shell=True) == 0)
    """

"""
class ExpDoesSimWorkCorrectly(object):
    def __init__(self, args):
        pass

    def start(self, args):
        args.num_bes = (args.reqs_per_sec * args.exe_time_mean_ms) / 1000
        args.num_bes = min(100, args.num_bes)
        args.num_bes = max(1, args.num_bes)
        args.num_bes = 15

        sim = AzmlSim(args)

        sim.move_exes_from_nfs_to_local(args)
        sim.set_sla_params(args)
        sim.set_syn_workload_params(args)
        sim.output_config_params(args)

        if args.workload_generated == False:
            sim.generate_workload()

        sim.run()
        sim.is_sla_satisfied();
        sim.cleanup_before_exit()

        print_bold("#BEs=%d, SLA-compliance?=%r" % \
            (args.num_bes, sim.sla_satisfied))
"""

"""
class ExpMinBEsSatisfyingSLA(object):
    def __init__(self, args):
        self.exes_moved_once = False

    def start(self, org_args):
        max_num_be_servers = 1000

        if (org_args.sys_or_sim == "analysis"):
            return self.num_be_servers_qt_analysis(org_args, max_num_be_servers)

        args = copy.copy(org_args)
        args.num_bes = (args.reqs_per_sec * args.exe_time_mean_ms) / 1000
        args.num_bes = min(max_num_be_servers, args.num_bes)
        args.num_bes = max(1, args.num_bes)
        args.workload_generated = False

        result = self.is_sla_satisfied(args)
        print_bold("#BEs=%d, SLA-compliance?=%r" % (args.num_bes, result))
        prev_num_be_servers = args.num_bes
        
        if (result == False):
            while (result == False and prev_num_be_servers < max_num_be_servers):
                args = copy.copy(org_args)
                args.workload_generated = True
                args.num_bes = prev_num_be_servers + 1
                result = self.is_sla_satisfied(args)
                print_bold("#BEs=%d, SLA-compliance?=%r" % (args.num_bes, result))
                prev_num_be_servers = args.num_bes
            return args.num_bes

        if (result == True):
            while (result == True and prev_num_be_servers > 1):
                args = copy.copy(org_args)
                args.workload_generated = True
                args.num_bes = prev_num_be_servers - 1
                result = self.is_sla_satisfied(args)
                print_bold ("#BEs=%d, SLA-compliance?=%r" % (args.num_bes, result))
                prev_num_be_servers = args.num_bes
            return args.num_bes + 1

    def is_sla_satisfied(self, args):

        if (args.sys_or_sim == "sys"):
            return self.is_sla_satisfied_sys(args)

        if (args.sys_or_sim == "sim"):
            return self.is_sla_satisfied_sim(args)

        assert (False)

    def is_sla_satisfied_sys(self, args):

        exp = AzmlSys(args)
        exp.move_exes_from_nfs_to_local(args)
        exp.set_sla_params(args)
        exp.set_syn_workload_params(args)
        exp.output_config_params(args)

        exp.stop_servers()
        exp.start_servers()
        exp.generate_workload()
        exp.wait(args.wait_for_sec)
        exp.stop_servers()
        exp.copy_logs_from_local_to_nfs();

        exp.is_sla_satisfied();
        exp.cleanup_before_exit();

        return exp.sla_satisfied

    def is_sla_satisfied_sim(self, args):
        sim = AzmlSim(args)

        if not self.exes_moved_once:
            self.exes_moved_once = True
            sim.move_exes_from_nfs_to_local(args)

        sim.set_sla_params(args)
        sim.set_syn_workload_params(args)
        sim.output_config_params(args)

        if args.workload_generated == False:
            sim.generate_workload()

        sim.run()

        sim.is_sla_satisfied();
        sim.cleanup_before_exit()

        return sim.sla_satisfied
"""
