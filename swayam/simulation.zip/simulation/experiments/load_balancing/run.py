#!/usr/bin/python

import os
import sys
import subprocess
import argparse
import numpy
import pickle

from exp import *

PARENT_DIR = os.path.dirname(os.path.realpath(__file__))
sys.path.append(PARENT_DIR + "/..")

sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0)

generated = PARENT_DIR + '/generated'
estimated = PARENT_DIR + '/estimated'
predicted = PARENT_DIR + '/predicted'

#parser = argparse.ArgumentParser(description='Plot waiting time distributions')
#parser.add_argument( '--expid', action='store', dest='expid', default=1, \
#                     type=int, help='Experiment ID (2 or 3)' )
#args = parser.parse_args()

def run_exp(exp_args, expid):
    # Percentile waiting-times vs. #BEs for all LB policies
    if (expid == 2):
        exp_args = compute_perc_wts(exp_args)
        perc_wts_file = PARENT_DIR + '/perc_wts.data'
        fp = open(perc_wts_file, 'w')
        fp.write("\n".join(exp_args.perc_wts))
        fp.close()
        context = 'sim1-' + Azml.get_wkld_params(exp_args)
        process_data_for_perc_wts(context, perc_wts_file, 99)
    # Percentile waiting-and response-times vs. #BEs for all RAND LB policy
    elif (expid == 3):
        exp_args = compute_perc_rts(exp_args)
        perc_rts_file = PARENT_DIR + '/perc_rts.data'
        fp = open(perc_rts_file, 'w')
        fp.write("\n".join(exp_args.perc_rts))
        fp.close()
        context = 'sim2-' + Azml.get_wkld_params(exp_args)
        process_data_for_perc_wts(context, perc_rts_file, 99)
    else:
        assert (False)

if __name__ == "__main__":
    exp_args_a = setup_exp_args()
    exp_args_a = prep_for_poisson_step(exp_args_a)
    run_exp(exp_args_a, 2)
    exp_args_b = setup_exp_args()
    exp_args_b = prep_for_poisson_step(exp_args_b)
    run_exp(exp_args_b, 3)
