#!/usr/bin/python

import os, sys

PARENT_DIR = os.path.dirname(os.path.realpath(__file__))
sys.path.append(PARENT_DIR + "/..")

from utils.azml import *

def setup_exp_args():
    args = AzmlArgs()
    args.sys_or_sim = 'sim'
    args.version = 'b1'

    args.logfile = PATH + "/config/trace_generation.log"
    assert (subprocess.call("rm -f " + args.logfile, shell=True) == 0)
    assert (subprocess.call("mkdir -p " + PATH + "/config/", shell=True) == 0)
    args.tracefile = PATH + "/config/trace.txt"
    args.setupfile = PATH + "/config/setup_times.txt"

    args.d_1 = 250 # us
    args.d_2 = 250 # us
    args.delta = 5000 # us

    args.sla_pc = 99
    args.num_fes = 5
    args.max_bes = 100
    args.num_bes = 100

    #['qfe', 'qfep', 'qbe', 'jiq', 'rand', 'rr']
    args.lb_types = ['qt_mgn', 'qfep', 'jiq', 'rand']

    return args

def prep_for_poisson_step(args):
    args.workload_type = POISSON_STEP
    args.num_reqs = 10
    args.step_seq = '1'

    [p1, p2, p3] = [0.72, 80970, 27569] # lognorm, mean~117ms # 20.txt

    args.exe_time_distr = 'lognorm'
    args.exe_time_params_us = [p1, p2, p3]
    args.exe_time_mean_us = scipy.stats.lognorm.mean(s=p1, loc=p2, scale=p3)
    args.exe_time_var_us = scipy.stats.lognorm.var(s=p1, loc=p2, scale=p3)
    args.scv_coeff = scv_coeff(args.exe_time_mean_us, args.exe_time_var_us)
    args.exe_time_mean_ms = us2ms(args.exe_time_mean_us)
    args.sla_rt_ms = 10 * args.exe_time_mean_ms

    args.setup_time_mean_ms = 0
    args.setup_time_mean_us = ms2us(args.setup_time_mean_ms)

    args.rate_mul = 30
    args.reqs_per_sec = 250
    args.reqs_per_us = psec2pus(args.reqs_per_sec)

    AzmlSim.gen_wkld_py ( args.reqs_per_us, args.exe_time_distr, \
                          args.exe_time_params_us, args.num_reqs, \
                          args.tracefile, args.setupfile )
    return args

def compute_wt_distrs_helper(args):
    azml = AzmlSim(args)
    azml.set_sla_params(args)
    azml.set_wkld_params(args)
    azml.output_config_params(args)
    azml.run(args)
    azml.compute_wt_distr(args)
    azml.cleanup_before_exit()
    return azml.wt_distr

def compute_perc_wts(args):
    min_bes = (args.reqs_per_us * args.exe_time_mean_us) + 1
    min_bes = int(math.ceil(min_bes))
    output = "FINAL-STATS service-time=%.2fms" % us2ms(args.exe_time_mean_us)
    output += " rate=%.0frps #FEs=%d st-distr=%s" % \
              (args.reqs_per_sec, args.num_fes, args.exe_time_distr)

    args.perc_wts = []
    for lb_type in args.lb_types:
        args.perc_wts.append(output + " lbtype=" + lb_type)

    for num_bes in range(min_bes, args.max_bes, int(args.max_bes / 50)):
        args.num_bes = num_bes
        for i in range(0, len(args.lb_types)):
            args.lb_type = args.lb_types[i]
            assert (args.lb_types[i] != 'qfe')
            if (args.lb_type == 'qt_mgn'):
                wt_us = Azml.qt_analysis_wt( args.scv_coeff, num_bes, 99, \
                            args.reqs_per_us, args.exe_time_mean_us )
                assert (wt_us != 'inf')
                args.perc_wts[i] += " #BEs-%d=%.4f" % (num_bes, us2ms(float(wt_us)))
            else:
                azml_sim_obj = compute_perc_wts_helper(args)
                args.perc_wts[i] += " #BEs-%d=%.4f" % (num_bes, azml_sim_obj.perc_wt_ms)

    return args

def compute_perc_wts_helper(args):
    azml = AzmlSim(args)
    azml.set_sla_params(args)
    azml.set_wkld_params(args)
    azml.output_config_params(args)
    azml.run(args)
    azml.compute_percentile_wt(args)
    azml.cleanup_before_exit()
    return azml

def compute_perc_rts(args):
    min_bes = (args.reqs_per_us * args.exe_time_mean_us) + 1
    min_bes = int(math.ceil(min_bes))
    output = "FINAL-STATS service-time=%.2fms" % us2ms(args.exe_time_mean_us)
    output += " rate=%.0frps #FEs=%d st-distr=%s" % \
              (args.reqs_per_sec, args.num_fes, args.exe_time_distr)

    args.perc_rts = []

    lb_types = []
    lb_types.append("wt-rand-analysis")
    lb_types.append("rt-rand-convolution")
    lb_types.append("wt-rand-sim")
    lb_types.append("rt-rand-sim")

    for lb_type in lb_types:
        args.perc_rts.append(output + " lbtype=" + lb_type)

    args.lb_type = 'rand'
    for num_bes in range(min_bes, args.max_bes, int(args.max_bes / 50)):
        args.num_bes = num_bes
        wt_us = rand_wait_time_ppf( args.reqs_per_us, args.exe_time_mean_us, \
                                      num_bes, 99, args.d_1, args.d_2, args.delta )
        args.perc_rts[0] += " #BEs-%d=%.4f" % (num_bes, us2ms(float(wt_us)))
        rt_us = rand_resp_time_ppf( args.reqs_per_us, args.exe_time_mean_us, \
                                      num_bes, 99, args.d_1, args.d_2, args.delta, \
                                      args.exe_time_params_us )
        args.perc_rts[1] += " #BEs-%d=%.4f" % (num_bes, us2ms(float(rt_us)))
        azml_sim_obj = compute_perc_rts_helper(args)
        args.perc_rts[2] += " #BEs-%d=%.4f" % (num_bes, azml_sim_obj.perc_wt_ms)
        args.perc_rts[3] += " #BEs-%d=%.4f" % (num_bes, azml_sim_obj.perc_rt_ms)

    return args

def compute_perc_rts_helper(args):
    azml = AzmlSim(args)
    azml.set_sla_params(args)
    azml.set_wkld_params(args)
    azml.output_config_params(args)
    azml.run(args)
    azml.compute_percentile_wt(args)
    azml.compute_percentile_rt(args)
    azml.cleanup_before_exit()
    return azml

def process_data_for_perc_wts(context,  perc_wts_file, perc):
    lines = numpy.loadtxt(perc_wts_file, dtype=str, ndmin=2, comments='&')

    num_bes_list = ['#BEs']
    num_bes_list_filled = False
    wait_times_dict = []
    title = ""

    for line in lines:
        title = '(' + line[1].split('=')[1] + \
                ', ' + line[2].split('=')[1] + ', ' + line[3] + ')'
        key = line[5].split('=')[1]
        wait_times_dict.append([key, []])

        for i in range(6, len(line)):
            num_bes = int(line[i].split('=')[0].split('-')[1])
            wait_time = line[i].split('=')[1]
            if (num_bes_list_filled == False):
                num_bes_list.append(str(num_bes))
            wait_times_dict[-1][1].append(wait_time)

        num_bes_list_filled = True

    data = [num_bes_list]

    for [key, value] in wait_times_dict:
        entry = [key]
        entry.extend(value)
        data.append(entry)

    final_data = numpy.transpose(data)

    datafile = PARENT_DIR + "/" + context + '-p' + str(perc) + '.data'
    numpy.savetxt(datafile, final_data[1:], fmt='%10s', delimiter=', ')
