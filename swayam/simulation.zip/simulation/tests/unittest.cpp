#include "../utils/regression.h"
#include "../utils/queuing_theory.h"
#include "../utils/polyfit.h"
#include "../utils/logging.h"
#include "../utils/model.h"

#include <iostream>
#include <vector>
#include <stdio.h>
#include <math.h>

#include <boost/algorithm/string/predicate.hpp>
#include <boost/math/distributions/lognormal.hpp>

using namespace std;

void test_polyfit_1()
{
    vector<double> X;
    vector<double> Y;

    X.push_back(1);
    Y.push_back(6);

    X.push_back(2);
    Y.push_back(5);

    X.push_back(3);
    Y.push_back(7);

    X.push_back(4);
    Y.push_back(10);

    vector<double> testX;
    testX.push_back(10);

    vector<double> coeff = polyfit(X, Y, 1);
    vector<double> testY = polyval(coeff, testX);

    assert(testY[0] >= 17.49 && testY[0] <= 17.51);
    cout << "test_polyfit() .. ok" << endl;
}

/* Example from 
 * http://docs.scipy.org/doc/numpy-1.10.0/reference/generated/numpy.polyfit.html */
void test_polyfit_2()
{
    vector<double> X;
    vector<double> Y;

    X.push_back(0.0);
    Y.push_back(0.0);

    X.push_back(1.0);
    Y.push_back(0.8);

    X.push_back(2.0);
    Y.push_back(0.9);

    X.push_back(3.0);
    Y.push_back(0.1);

    X.push_back(4.0);
    Y.push_back(-0.8);

    X.push_back(5.0);
    Y.push_back(-1.0);

    vector<double> testX;
    testX.push_back(0.5);
    testX.push_back(3.5);
    testX.push_back(10);

    vector<double> coeff = polyfit(X, Y, 3);
    vector<double> testY = polyval(coeff, testX);

    assert(testY[0] >= 0.614384920 && testY[0] <= 0.614385);
    assert(testY[1] >= -0.34732143 && testY[1] <= -0.34732142857143);
    assert(testY[2] >= 22.5793650 && testY[2] <= 22.57936508);
    cout << "test_polyfit() .. ok" << endl;
}

/*void test_baseline_sim()
{
    Category *logger;
    get_new_logger("test", 0, &logger);

    vector<AddType> be_adds;
    for (unsigned int i = 8080; i < 8088; i++)
    {
        AddType add;
        add.host = "pinky01";
        add.port = i;
        be_adds.push_back(add);
    }

    BaselineSimulator sim(logger, be_adds, 1000000, 100000);

    sim.add_arrival(ArrivalQRequest(0, 0, 1000000));
    sim.add_arrival(ArrivalQRequest(1, 10, 1000000));
    sim.add_arrival(ArrivalQRequest(2, 20, 1000000));
    sim.add_arrival(ArrivalQRequest(3, 30, 1000000));

    sim.run();

    cout << "test_baseline_sim() ... ok" << endl;
}*/

void test_regression_example_from_wiki2()
{
    vector<double> X;
    vector<double> Y;

    X.push_back(1);
    Y.push_back(6);

    X.push_back(2);
    Y.push_back(5);

    X.push_back(3);
    Y.push_back(7);

    X.push_back(4);
    Y.push_back(10);

    assert(fit_line_and_predict2(X, Y, 10) == 17.5);

    vector<double> testX;
    testX.push_back(10);
    
    vector<double> testY = fit_line_and_predict3(X, Y, testX);
    assert(testY[0] == 17.5);

    X.clear();
    Y.clear();
    testX.clear();
    testY.clear();

    X.push_back(1);
    X.push_back(2);
    X.push_back(3);
    X.push_back(4);

    Y.push_back(2);
    Y.push_back(4);
    Y.push_back(6);
    Y.push_back(8);

    testX.push_back(20);
    testX.push_back(21);

    testY = fit_line_and_predict3(X, Y, testX);

    assert(testY[0] == 40);
    assert(testY[1] == 42);

    cout << "test_regression_example_from_wiki2() ... ok" << endl;
}

void test_regression_decimal_points()
{
    vector<double> X;
    vector<double> Y;

    X.push_back(0.123);
    Y.push_back(0.246);

    X.push_back(0.223);
    Y.push_back(0.446);

    X.push_back(0.445);
    Y.push_back(0.890);

    assert(fit_line_and_predict2(X, Y, 13.234) == 26.468);
    cout << "test_regression_decimal_points() ... ok" << endl;
}

void test_erlang_c()
{
    double c = erlang_c(55, 0.2, 240);
    assert(c > 0.238 && c < 0.240); // c = ~0.239
    cout << "test_erlang_c() ... ok" << endl;
}

void test_percentile_waiting_time_mmn_1()
{
    double w_90 = percentile_wait_time_mmn(1, 4, 0.22, 90);
    assert(w_90 > 3.98 && w_90 < 4); // w_90 = ~3.99
    cout << "test_percentile_waiting_time_mmn_1() ... ok" << endl;
}

void test_percentile_waiting_time_mmn_2()
{
    double w_90 = percentile_wait_time_mmn(1, (1/48.0), 30, 90);
    assert(w_90 > 146.5 && w_90 < 146.7); // w_90 = ~146.6
    cout << "test_percentile_waiting_time_mmn_2() ... ok" << endl;
}

void test_prob_rt_leq_x()
{
    // Approximate answers obtained by feeding values into the online
    // calculator available here: http://www.supositorio.com/rcalc/rcalclite.htm

    double p_rt_leq_x;

    p_rt_leq_x = prob_rt_leq_x(1, 4, 0.20, 1);
    //cout << "prob_rt_leq_x(1, 4, 0.20, 1) = " << p_rt_leq_x << endl;
    assert(p_rt_leq_x > 0.6320 && p_rt_leq_x < 0.6322); // ~ 0.6321

    p_rt_leq_x = prob_rt_leq_x(1, 4, 0.20, 2);
    //cout << "prob_rt_leq_x(1, 4, 0.20, 2) = " << p_rt_leq_x << endl;
    assert(p_rt_leq_x > 0.8646 && p_rt_leq_x < 0.8648); // ~ 0.8647

    p_rt_leq_x = prob_rt_leq_x(1, 4, 0.20, 5.67);
    //cout << "prob_rt_leq_x(1, 4, 0.20, 5.67) = " << p_rt_leq_x << endl;
    assert(p_rt_leq_x > 0.9965 && p_rt_leq_x < 0.9967); // ~ 0.9966

    p_rt_leq_x = prob_rt_leq_x(10, 4, 2, 10);
    //cout << "prob_rt_leq_x(10, 4, 2, 10) = " << p_rt_leq_x << endl;
    assert(p_rt_leq_x > 0.9904 && p_rt_leq_x < 0.9906); // ~ 0.9905

    cout << "test_prob_rt_leq_x() ... ok" << endl;
}

/*void test_local_store_init()
{
    LocalStore local_store = LocalStore(10, 100);
    LocalStoreType& store = local_store.get_store();
    assert(store.size() == 10);
    for (unsigned int i = 0; i < 10; i++)
    {
        assert(store[i].first == 0);
        assert(store[i].second == 0);
    }
    cout << "test_local_store_init() ... ok" << endl;
}

void test_local_store_update_1()
{
    LocalStore local_store = LocalStore(10, 100);
    for (unsigned int i = 0; i < 1000; i++)
        local_store.update(i);
    LocalStoreType& store = local_store.get_store();
    for (unsigned int i = 0; i < 10; i++)
    {
        assert(store[i].first == 100 * i);
        assert(store[i].second == 100);
    }
    cout << "test_local_store_update_1() ... ok" << endl;
}

void test_local_store_update_2()
{
    LocalStore local_store = LocalStore(10, 100);
    for (unsigned int i = 0; i < 2000; i++)
        local_store.update(i);
    LocalStoreType& store = local_store.get_store();
    for (unsigned int i = 0; i < 10; i++)
    {
        assert(store[i].first == 1000 + (i * 100));
        assert(store[i].second == 100);
    }
    cout << "test_local_store_update_2() ... ok" << endl;
}

void test_local_store_update_3()
{
    LocalStore local_store = LocalStore(10, 100);
    for (unsigned int i = 0; i < 2500; i++)
        local_store.update(i);
    LocalStoreType& store = local_store.get_store();
    for (unsigned int i = 0; i < 5; i++)
    {
        assert(store[i].first == 2000 + (i * 100));
        assert(store[i].second == 100);
    }
    for (unsigned int i = 5; i < 10; i++)
    {
        assert(store[i].first == 1000 + (i * 100));
        assert(store[i].second == 100);
    }
    cout << "test_local_store_update_3() ... ok" << endl;
}

void test_local_store_update_4()
{
    LocalStore local_store = LocalStore(10, 100);
    local_store.update(124);
    local_store.update(435);
    local_store.update(2342);
    local_store.update(3244);
    local_store.update(3299);
    local_store.update(92344);
    LocalStoreType& store = local_store.get_store();
    assert(store[0].first == 0);
    assert(store[0].second == 0);
    assert(store[1].first == 100);
    assert(store[1].second == 1);
    assert(store[2].first == 3200);
    assert(store[2].second == 2);
    assert(store[3].first == 92300);
    assert(store[3].second == 1);
    assert(store[4].first == 400);
    assert(store[4].second == 1);
    assert(store[5].first == 0); 
    assert(store[5].second == 0);
    assert(store[6].first == 0);
    assert(store[6].second == 0);
    assert(store[7].first == 0);
    assert(store[7].second == 0);
    assert(store[8].first == 0);
    assert(store[8].second == 0);
    assert(store[9].first == 0);
    assert(store[9].second == 0);
    cout << "test_local_store_update_4() ... ok" << endl;
}

void test_global_store_update_1()
{
    GlobalStore global_store = GlobalStore(4, 10, 100, 3);

    LocalStoreType local_store;
    local_store.push_back(make_pair(0, 1));
    local_store.push_back(make_pair(100, 1));
    local_store.push_back(make_pair(200, 1));
    local_store.push_back(make_pair(300, 1));
    local_store.push_back(make_pair(400, 1));
    local_store.push_back(make_pair(500, 1));
    local_store.push_back(make_pair(600, 1));
    local_store.push_back(make_pair(700, 1));
    local_store.push_back(make_pair(800, 1));
    local_store.push_back(make_pair(900, 1));

    global_store.update("2", local_store);

    GlobalStoreType& store = global_store.get_store();
    assert(store["0"].empty());
    assert(store["1"].empty());
    assert(store["2"] == local_store);
    assert(store["3"].empty());

    cout << "test_global_store_update_1() ... ok" << endl;
}

void test_global_store_update_2()
{
    GlobalStore global_store = GlobalStore(4, 10, 100, 3);

    LocalStoreType local_store_a;
    local_store_a.push_back(make_pair(0, 1));
    local_store_a.push_back(make_pair(100, 1));
    local_store_a.push_back(make_pair(200, 1));
    local_store_a.push_back(make_pair(300, 1));
    local_store_a.push_back(make_pair(400, 1));
    local_store_a.push_back(make_pair(500, 1));
    local_store_a.push_back(make_pair(600, 1));
    local_store_a.push_back(make_pair(700, 1));
    local_store_a.push_back(make_pair(800, 1));
    local_store_a.push_back(make_pair(900, 1));

    LocalStoreType local_store_b;
    local_store_b.push_back(make_pair(0, 2));
    local_store_b.push_back(make_pair(100, 2));
    local_store_b.push_back(make_pair(200, 2));
    local_store_b.push_back(make_pair(300, 2));
    local_store_b.push_back(make_pair(400, 2));
    local_store_b.push_back(make_pair(500, 2));
    local_store_b.push_back(make_pair(600, 2));
    local_store_b.push_back(make_pair(700, 2));
    local_store_b.push_back(make_pair(800, 2));
    local_store_b.push_back(make_pair(900, 2));

    global_store.update("0", local_store_a);
    global_store.update("1", local_store_a);
    global_store.update("2", local_store_a);
    global_store.update("3", local_store_a);

    global_store.update("1", local_store_b);
    global_store.update("3", local_store_b);

    GlobalStoreType& store = global_store.get_store();
    assert(store["0"] == local_store_a);
    assert(store["1"] == local_store_b);
    assert(store["2"] == local_store_a);
    assert(store["3"] == local_store_b);

    cout << "test_global_store_update_2() ... ok" << endl;
}

void test_global_store_sanitize_local_stores()
{
    GlobalStore global_store = GlobalStore(4, 10, 100, 3);

    LocalStoreType local_store_a;
    local_store_a.push_back(make_pair(0, 1));
    local_store_a.push_back(make_pair(100, 1));
    local_store_a.push_back(make_pair(200, 1));
    local_store_a.push_back(make_pair(300, 1));
    local_store_a.push_back(make_pair(400, 1));
    local_store_a.push_back(make_pair(500, 1));
    local_store_a.push_back(make_pair(600, 1));
    local_store_a.push_back(make_pair(700, 1));
    local_store_a.push_back(make_pair(800, 1));
    local_store_a.push_back(make_pair(900, 1));

    LocalStoreType local_store_b;
    local_store_b.push_back(make_pair(0, 1));
    local_store_b.push_back(make_pair(100, 1));
    local_store_b.push_back(make_pair(200, 1));
    local_store_b.push_back(make_pair(300, 1));
    local_store_b.push_back(make_pair(400, 1));
    local_store_b.push_back(make_pair(500, 1));
    local_store_b.push_back(make_pair(600, 1));
    local_store_b.push_back(make_pair(1700, 1));
    local_store_b.push_back(make_pair(800, 1));
    local_store_b.push_back(make_pair(900, 1));

    LocalStoreType local_store_c;
    local_store_c.push_back(make_pair(1000, 1));
    local_store_c.push_back(make_pair(1100, 1));
    local_store_c.push_back(make_pair(1200, 1));
    local_store_c.push_back(make_pair(1300, 1));
    local_store_c.push_back(make_pair(1400, 1));
    local_store_c.push_back(make_pair(1500, 1));
    local_store_c.push_back(make_pair(1600, 1));
    local_store_c.push_back(make_pair(1700, 1));
    local_store_c.push_back(make_pair(1800, 1));
    local_store_c.push_back(make_pair(1900, 1));

    LocalStoreType local_store_d;
    local_store_d.push_back(make_pair(1000, 1));
    local_store_d.push_back(make_pair(2100, 1));
    local_store_d.push_back(make_pair(1200, 1));
    local_store_d.push_back(make_pair(2300, 1));
    local_store_d.push_back(make_pair(1400, 1));
    local_store_d.push_back(make_pair(2500, 1));
    local_store_d.push_back(make_pair(1600, 1));
    local_store_d.push_back(make_pair(2700, 1));
    local_store_d.push_back(make_pair(1800, 1));
    local_store_d.push_back(make_pair(2900, 1));

    global_store.update("0", local_store_a);
    global_store.update("1", local_store_b);
    global_store.update("2", local_store_c);
    global_store.update("3", local_store_d);

    global_store.sanitize_local_stores();
    GlobalStoreType store = global_store.get_store();

    LocalStoreType sanitized_local_store_a = local_store_a;

    LocalStoreType sanitized_local_store_b;
    sanitized_local_store_b.push_back(make_pair(1000, 0));
    sanitized_local_store_b.push_back(make_pair(1100, 0));
    sanitized_local_store_b.push_back(make_pair(1200, 0));
    sanitized_local_store_b.push_back(make_pair(1300, 0));
    sanitized_local_store_b.push_back(make_pair(1400, 0));
    sanitized_local_store_b.push_back(make_pair(1500, 0));
    sanitized_local_store_b.push_back(make_pair(1600, 0));
    sanitized_local_store_b.push_back(make_pair(1700, 1));
    sanitized_local_store_b.push_back(make_pair(800, 1));
    sanitized_local_store_b.push_back(make_pair(900, 1));

    LocalStoreType sanitized_local_store_c;
    sanitized_local_store_c.push_back(make_pair(1000, 1));
    sanitized_local_store_c.push_back(make_pair(1100, 1));
    sanitized_local_store_c.push_back(make_pair(1200, 1));
    sanitized_local_store_c.push_back(make_pair(1300, 1));
    sanitized_local_store_c.push_back(make_pair(1400, 1));
    sanitized_local_store_c.push_back(make_pair(1500, 1));
    sanitized_local_store_c.push_back(make_pair(1600, 1));
    sanitized_local_store_c.push_back(make_pair(1700, 1));
    sanitized_local_store_c.push_back(make_pair(1800, 1));
    sanitized_local_store_c.push_back(make_pair(1900, 1));

    LocalStoreType sanitized_local_store_d;
    sanitized_local_store_d.push_back(make_pair(2000, 0));
    sanitized_local_store_d.push_back(make_pair(2100, 1));
    sanitized_local_store_d.push_back(make_pair(2200, 0));
    sanitized_local_store_d.push_back(make_pair(2300, 1));
    sanitized_local_store_d.push_back(make_pair(2400, 0));
    sanitized_local_store_d.push_back(make_pair(2500, 1));
    sanitized_local_store_d.push_back(make_pair(2600, 0));
    sanitized_local_store_d.push_back(make_pair(2700, 1));
    sanitized_local_store_d.push_back(make_pair(2800, 0));
    sanitized_local_store_d.push_back(make_pair(2900, 1));

    assert(store["0"] == sanitized_local_store_a);
    assert(store["1"] == sanitized_local_store_b);
    assert(store["2"] == sanitized_local_store_c);
    assert(store["3"] == sanitized_local_store_d);

    cout << "test_global_store_sanitize_local_stores() ... ok" << endl;
}

void test_global_store_aggregate_store()
{
    GlobalStore global_store = GlobalStore(4, 10, 100, 3);

    LocalStoreType local_store_a;
    local_store_a.push_back(make_pair(0, 1));
    local_store_a.push_back(make_pair(100, 1));
    local_store_a.push_back(make_pair(200, 1));
    local_store_a.push_back(make_pair(300, 1));
    local_store_a.push_back(make_pair(400, 1));
    local_store_a.push_back(make_pair(500, 1));
    local_store_a.push_back(make_pair(600, 1));
    local_store_a.push_back(make_pair(700, 1));
    local_store_a.push_back(make_pair(800, 1));
    local_store_a.push_back(make_pair(900, 1));

    LocalStoreType local_store_b;
    local_store_b.push_back(make_pair(0, 1));
    local_store_b.push_back(make_pair(100, 1));
    local_store_b.push_back(make_pair(200, 1));
    local_store_b.push_back(make_pair(300, 1));
    local_store_b.push_back(make_pair(400, 1));
    local_store_b.push_back(make_pair(500, 1));
    local_store_b.push_back(make_pair(600, 1));
    local_store_b.push_back(make_pair(1700, 1));
    local_store_b.push_back(make_pair(800, 1));
    local_store_b.push_back(make_pair(900, 1));

    LocalStoreType local_store_c;
    local_store_c.push_back(make_pair(1000, 1));
    local_store_c.push_back(make_pair(1100, 1));
    local_store_c.push_back(make_pair(1200, 1));
    local_store_c.push_back(make_pair(1300, 1));
    local_store_c.push_back(make_pair(1400, 1));
    local_store_c.push_back(make_pair(1500, 1));
    local_store_c.push_back(make_pair(1600, 1));
    local_store_c.push_back(make_pair(1700, 1));
    local_store_c.push_back(make_pair(1800, 1));
    local_store_c.push_back(make_pair(1900, 1));

    LocalStoreType local_store_d;
    local_store_d.push_back(make_pair(1000, 1));
    local_store_d.push_back(make_pair(2100, 1));
    local_store_d.push_back(make_pair(1200, 1));
    local_store_d.push_back(make_pair(2300, 1));
    local_store_d.push_back(make_pair(1400, 1));
    local_store_d.push_back(make_pair(2500, 1));
    local_store_d.push_back(make_pair(1600, 1));
    local_store_d.push_back(make_pair(2700, 1));
    local_store_d.push_back(make_pair(1800, 1));
    local_store_d.push_back(make_pair(2900, 1));

    global_store.update("0", local_store_a);
    global_store.update("1", local_store_b);
    global_store.update("2", local_store_c);
    global_store.update("3", local_store_d);

    AggregateStoreType aggregate_store;
    
    global_store.sanitize_local_stores();
    aggregate_store = global_store.get_aggregate_store(1000000);

    assert (aggregate_store.empty());

    //global_store.sanitize_local_stores();
    aggregate_store = global_store.get_aggregate_store(4000);

    assert(aggregate_store.find(0) == aggregate_store.end());
    assert(aggregate_store.find(100) == aggregate_store.end());
    assert(aggregate_store.find(200) == aggregate_store.end());
    assert(aggregate_store.find(300) == aggregate_store.end());
    assert(aggregate_store.find(400) == aggregate_store.end());
    assert(aggregate_store.find(500) == aggregate_store.end());
    assert(aggregate_store.find(600) == aggregate_store.end());
    assert(aggregate_store.find(700) == aggregate_store.end());
    assert(aggregate_store.find(800) == aggregate_store.end());
    assert(aggregate_store.find(900) == aggregate_store.end());
    assert(aggregate_store[1000] == 1.5);
    assert(aggregate_store[1100] == 1.5);
    assert(aggregate_store[1200] == 1.5);
    assert(aggregate_store[1300] == 1.5);
    assert(aggregate_store[1400] == 1.5);
    assert(aggregate_store[1500] == 1.5);
    assert(aggregate_store[1600] == 1.5);
    assert(aggregate_store[1700] == 3);
    assert(aggregate_store[1800] == 3);
    assert(aggregate_store[1900] == 3);
    assert(aggregate_store[2000] == 0);
    assert(aggregate_store[2100] == 3);
    assert(aggregate_store[2200] == 0);
    assert(aggregate_store[2300] == 3);
    assert(aggregate_store[2400] == 0);
    assert(aggregate_store[2500] == 3);
    assert(aggregate_store[2600] == 0);
    assert(aggregate_store[2700] == 3);
    assert(aggregate_store[2800] == 0);
    assert(aggregate_store[2900] == 3);

    AggregateRatesType aggregate_rates;
    aggregate_rates = global_store.get_aggregate_rates(4000);
    assert(aggregate_rates.find(0) == aggregate_rates.end());
    assert(aggregate_rates.find(100) == aggregate_rates.end());
    assert(aggregate_rates.find(200) == aggregate_rates.end());
    assert(aggregate_rates.find(300) == aggregate_rates.end());
    assert(aggregate_rates.find(400) == aggregate_rates.end());
    assert(aggregate_rates.find(500) == aggregate_rates.end());
    assert(aggregate_rates.find(600) == aggregate_rates.end());
    assert(aggregate_rates.find(700) == aggregate_rates.end());
    assert(aggregate_rates.find(800) == aggregate_rates.end());
    assert(aggregate_rates.find(900) == aggregate_rates.end());
    assert(aggregate_rates[1000] == 0.015);
    assert(aggregate_rates[1100] == 0.015);
    assert(aggregate_rates[1200] == 0.015);
    assert(aggregate_rates[1300] == 0.015);
    assert(aggregate_rates[1400] == 0.015);
    assert(aggregate_rates[1500] == 0.015);
    assert(aggregate_rates[1600] == 0.015);
    assert(aggregate_rates[1700] == 0.03);
    assert(aggregate_rates[1800] == 0.03);
    assert(aggregate_rates[1900] == 0.03);
    assert(aggregate_rates[2000] == 0);
    assert(aggregate_rates[2100] == 0.03);
    assert(aggregate_rates[2200] == 0);
    assert(aggregate_rates[2300] == 0.03);
    assert(aggregate_rates[2400] == 0);
    assert(aggregate_rates[2500] == 0.03);
    assert(aggregate_rates[2600] == 0);
    assert(aggregate_rates[2700] == 0.03);
    assert(aggregate_rates[2800] == 0);
    assert(aggregate_rates[2900] == 0.03);

    cout << "test_global_store_aggregate_store() ... ok" << endl;
}*/

// rand_wait_time_ppf in python
void test_get_perc_wt()
{
    Category *logger;
    get_new_logger("test_get_perc_wt()", 800, &logger);
    TimeUs wt;
    ServiceInfoType info;

    info.exe_time_us = 100000;
    wt = get_perc_wt(logger, 0.00002, 50, 99.0, 1000, 1000, 5000, &info);
    assert(wt == 4014); // python code gives 4014.73590651

    // ====================

    info.exe_time_us = 134654;
    wt = get_perc_wt(logger, 0.000237, 83, 99.945, 1982, 56, 3999, &info);
    assert(wt == 43350); // python code gives 43350.2837543

    cout << "test_get_perc_wt() ... ok" << endl;
}

// rand_wait_resp_ppf in python
void test_get_perc_rt()
{
    Category *logger;
    get_new_logger("test_get_perc_rt()", 800, &logger);
    TimeUs rt;

    ServiceInfoType info;
    info.exe_time_us = 59462;
    info.logn_s_us = 0.32;
    info.logn_loc_us = 40970;
    info.logn_scale_us = 17569;

    rt = get_perc_rt(logger, 0.00033, 67, 99.23, 1111, 2222, 4444, &info);
    assert(rt == 93153); // python code gives 93153.620521

    // ================

    info.exe_time_us = 68962;
    info.logn_s_us = 0.11;
    info.logn_loc_us = 23232;
    info.logn_scale_us = 45454;

    rt = get_perc_rt(logger, 0.00045, 99, 4.55, 0, 12, 3434, &info);
    assert(rt == 62000); // python code gives 62000

    cout << "test_get_perc_rt() ... ok" << endl;
}

// rand_resp_time_cdf in python
void test_get_cdf_rt()
{
    Category *logger;
    get_new_logger("test_get_cdf_rt()", 800, &logger);
    double cdf;

    ServiceInfoType info;
    info.exe_time_us = 116697;
    info.logn_s_us = 0.72;
    info.logn_loc_us = 80970;
    info.logn_scale_us = 27569;
    
    cdf = get_cdf_rt(logger, 0.00002, 50, 125000, 1000, 1000, 5000, &info);

    // python code gives 0.72750023154
    assert(cdf >= 0.7275000 && cdf <= 0.7275003);

    // ====================

    info.exe_time_us = 59462;
    info.logn_s_us = 0.32;
    info.logn_loc_us = 40970;
    info.logn_scale_us = 17569;

    cdf = get_cdf_rt(logger, 0.00033, 67, 75000, 1111, 2222, 4444, &info);

    // python code gives 0.899400300694
    assert(cdf >= 0.8994003 && cdf <= 0.8994004);

    cout << "test_get_cdf_rt() ... ok" << endl;
}

void test_lognorm_cdf_boost_vs_scipy()
{
    Category *logger;
    get_new_logger("test_lognorm_cdf_boost_vs_scipy()", 800, &logger);
    double s, loc, scale, sigma, mu, x, cdf;
    TimeUs mean;

    s = 0.72;
    loc = 80970;
    scale = 27569;

    sigma = s;
    mu = log(scale);

    boost::math::lognormal_distribution<> distr1(mu, sigma);

    mean = boost::math::mean(distr1) + loc;
    assert (mean == 116696); // scipy.stats.lognorm gives 116696.472945

    x = 125000;
    cdf = boost::math::cdf(distr1, x - loc);

    // scipy.stats.lognorm gives 0.742234296838
    assert (cdf >= 0.742233 && cdf <= 0.742235);

    // ====================

    s = 0.56;
    loc = 345678;
    scale = 234567;

    sigma = s;
    mu = log(scale);

    boost::math::lognormal_distribution<> distr2(mu, sigma);

    mean = boost::math::mean(distr2) + loc;
    assert (mean == 620065); // scipy.stats.lognorm gives 620065.478182

    x = 654321;
    cdf = boost::math::cdf(distr2, x - loc);

    // scipy.stats.lognorm gives 0.687960854524
    assert (cdf >= 0.687960 && cdf <= 0.687961);

    cout << "test_lognorm_cdf_boost_vs_scipy() ... ok" << endl;
}

int main(int argc, char **argv)
{
    test_lognorm_cdf_boost_vs_scipy();

    test_get_perc_rt();
    test_get_cdf_rt();
    test_get_perc_wt();

    test_polyfit_1();
    test_polyfit_2();

    test_prob_rt_leq_x();

    test_regression_example_from_wiki2();
    test_regression_decimal_points();

    test_erlang_c();
    test_percentile_waiting_time_mmn_1();
    test_percentile_waiting_time_mmn_2();

    /*
    test_baseline_sim();
    test_local_store_init();
    test_local_store_update_1();
    test_local_store_update_2();
    test_local_store_update_3();
    test_local_store_update_4();
    test_global_store_update_1();
    test_global_store_update_2();
    test_global_store_sanitize_local_stores();
    test_global_store_aggregate_store();
    */

    return 0;
}
