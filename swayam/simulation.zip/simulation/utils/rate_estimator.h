#ifndef UTILS_RATE_ESTIMATOR_H
#define UTILS_RATE_ESTIMATOR_H

#include <vector>
#include <iterator>
#include <string>

#include <boost/circular_buffer.hpp>

#include "basics.h"
#include "model.h"
#include "logging.h"
#include "regression.h"
#include "file_io_sim.h"

// window size over which rate should always be calculated
#define ESTIMATOR_WINDOW_SIZE_US (100 * 1000 * 1000) // 100 seconds

// the window must always be shifted in units of one step size
#define ESTIMATOR_STEP_SIZE_US (10 * 1000 * 1000) // 10 seconds

//#define ESTIMATOR_WINDOW_SIZE_US (100 * 1000 * 1000) // 100 seconds
//#define ESTIMATOR_STEP_SIZE_US (10 * 1000 * 1000) // 10 seconds

// for prediction, we must keep a history of size larger than the window size
#define PREDICTOR_HISTORY_SIZE_US (300 * 1000 * 1000) // 300 seconds

//#define PREDICTOR_NUM_BUCKETS 10
//#define PREDICTOR_BUCKET_SIZE_US (10 * 1000 * 1000) // 10 seconds

// #define ESTIMATOR_PREDICTION_US (10 * 1000 * 1000) // 10 seconds

class RequestHistoryEntry
{
  public:
    TimeUs start; // inclusive
    TimeUs end; // exclusive
    unsigned int count;

    RequestHistoryEntry( TimeUs s, TimeUs e, unsigned int c )
                         : start(s), end(e), count(c) {}

    string str()
    {
        double start_sec = start / 1000000.0;
        double end_sec = end / 1000000.0;

        return "(" + to_string(start_sec) + ", " + to_string(end_sec) +
               ", " + to_string(count) + ")";
    }
};

typedef boost::circular_buffer<RequestHistoryEntry> RequestHistoryType;

class FERateEstimator
{
  private:
    Category *logger;

    vector<TimeUs> window;
    TimeUs window_size;
    TimeUs step_size;
    TimeUs window_end;

    string my_add;
    unsigned int my_id;
    unsigned int num_fes;

  public:
    FERateEstimator( Category *logger, TimeUs window_size, TimeUs step_size,
                     string my_add, vector<string>& fe_adds )
                    : logger(logger), window_size(window_size),
                      step_size(step_size), window_end(0), my_add(my_add),
                      num_fes(fe_adds.size())
    {
        INFO << "FERateEstimator: window_size = " << window_size;
        INFO << "FERateEstimator: step_size = " << step_size;
        INFO << "FERateEstimator: window_end = " << window_end;

        for (unsigned int i = 0; i < fe_adds.size(); i++)
        {
            if (my_add.compare(fe_adds[i]) == 0)
            {
                my_id = i;
                break;
            }
        }
    }

    void register_new_arrival(TimeUs now)
    {
        if (my_id != 0)
        {
            return;
        }

        //INFO << "FERateEstimator: now = " << now;

        while (now >= window_end)
        {
            if (window.empty())
            {
                window_end = (now - (now % step_size)) + step_size;
                break;
            }
            
            window_end += step_size;

            //INFO << "FERateEstimator: window_end = " << window_end;

            for ( vector<TimeUs>::iterator it = window.begin();
                  it != window.end(); )
            {
                if ((*it) < window_end - window_size)
                {
                    //INFO << "FERateEstimator: erasing entry "
                    //     << int(it - window.begin());
                    it = window.erase(it);
                }
                else
                {
                    it++;
                }
            }
        }

        window.push_back(now);

        //INFO << "FERateEstimator: len(window) = " << window.size();
        double rate = (window.size() / ((float)window_size)) * num_fes;

        INFO << "STATS_ESTIMATED_RATE " << window_end << " " << rate;
    }
};

class FERatePredictor
{
  private:
    Category *logger;
    RequestHistoryType history;

    TimeUs window_size;
    TimeUs step_size;
    TimeUs history_size;
    unsigned int num_entries;

    string my_add;
    unsigned int my_id;
    unsigned int num_fes;

    void print_history()
    {
        for (unsigned int i = 0; i < history.size(); i++)
        {
            INFO << "Entry " << i << ": " << history[i].str();
        }
    }

    void scrub_old_entries(TimeUs now)
    {
        TimeUs step_start = now - (now % step_size);

        TimeUs earliest_window_start;
        if (step_start >= step_size * (num_entries - 1))
        {
            earliest_window_start = step_start - (step_size * (num_entries - 1));
        }
        else
        {
            earliest_window_start = 0;
        }

        // scrub stale entries, useful when request arrives after a long time!
        for ( RequestHistoryType::iterator it = history.begin();
              it != history.end(); )
        {
            if (it->start < earliest_window_start)
            {
                it = history.erase(it);
            }
            else
            {
                it++;
            }
        }
    }

    void register_new_arrival_helper(TimeUs now)
    {
        //print_history();

        if (history.empty() || now >= history.back().end)
        {
            TimeUs start = now - (now % step_size);
            TimeUs end = start + step_size;
            RequestHistoryEntry e(start, end, 1);
            history.push_back(e);
        }
        else if (now >= history.back().start && now < history.back().end)
        {
            history.back().count++;
        }
        else
        {
            assert (false);
        }
    }

    double predict_rate_at(TimeUs predict_at)
    {
        if (history.size() * step_size <= window_size)
        {
            unsigned int total_count = 0;
            for (unsigned int i = 0; i < history.size(); i++)
            {
                total_count += history[i].count;
            }

            double rate = ((double)(total_count * num_fes)) / 
                          (history.back().end - history.front().start);

            //INFO << "STATS_PREDICTED_RATE " << predict_at << " " << rate;
            return rate;
        }

        vector<double> X;
        vector<double> Y;

        unsigned int steps_per_window = window_size / step_size;

        for ( unsigned int start_index = 0;
              start_index <= history.size() - steps_per_window;
              start_index++ )
        {
            unsigned int request_count = 0;
            for ( unsigned int i = start_index;
                  i < start_index + steps_per_window; i++ )
            {
                request_count += history[i].count;
            }

            double x = history[start_index + steps_per_window - 1].end;
            double y = ((request_count * num_fes) / ((double)window_size));

            X.push_back(x);
            Y.push_back(y);
        }

        TimeUs testX = predict_at;
        double testY = fit_line_and_predict2(X, Y, testX);
        if (testY < 0) { testY = 0; }

        //INFO << "STATS_PREDICTED_RATE " << testX << " " << testY;
        return testY;
    }

  public:
    FERatePredictor( Category *lgr, TimeUs w_size, TimeUs s_size, TimeUs h_size,
                     string my_add, vector<string>& fes )
                     : logger(lgr), window_size(w_size), step_size(s_size),
                       history_size(h_size), my_add(my_add), num_fes(fes.size())
    {
        INFO << "FERatePredictor: window_size = " << window_size;
        INFO << "FERatePredictor: step_size = " << step_size;
        INFO << "FERatePredictor: history_size = " << history_size;

        num_entries = history_size / step_size;
        INFO << "FERatePredictor: num_entries = " << num_entries;
        assert (num_entries > (window_size / step_size));

        history.set_capacity(num_entries);
        INFO << "FERatePredictor: capacity = " << history.capacity();

        for (unsigned int i = 0; i < fes.size(); i++)
        {
            if (my_add.compare(fes[i]) == 0)
            {
                my_id = i;
                INFO << "FERatePredictor: My ID = " << my_id;
                break;
            }
        }
    }

    void register_new_arrival_and_predict(TimeUs now)
    {
        scrub_old_entries(now);
        register_new_arrival_helper(now);

        /*// don't print info from all FEs
        // so that the graphs are clean
        if (my_id > 0) { return; }*/

        double rate = predict_rate_at(now + step_size);
        INFO << "STATS_PREDICTED_RATE " << (now + step_size) << " " << rate;
    }

    void register_new_arrival(TimeUs now)
    {
        scrub_old_entries(now);
        register_new_arrival_helper(now);
    }

    double get_predicted_rate(TimeUs now)
    {
        scrub_old_entries(now);
        return predict_rate_at(now + step_size);
    }

    /*void register_new_arrival_and_predict(TimeUs now)
    {
        // so that graphs are clean and
        // don't print info from all FEs
        if (my_id > 0) { return; }

        //INFO << "FERatePredictor: now(us) = " << now;
        //INFO << "FERatePredictor: now(sec) = " << (now / 1000000.0);

        //INFO << "FERatePredictor: history before scrubbing old entries";
        //print_history();

        TimeUs step_start = now - (now % step_size);
        //INFO << "FERatePredictor: step_start(sec) = " << (step_start / 1000000.0);

        TimeUs earliest_window_start;
        if (step_start >= step_size * (num_entries - 1))
        {
            earliest_window_start = step_start - (step_size * (num_entries - 1));
            //INFO << "FERatePredictor: earliest_window_start(sec) = "
            //     << (earliest_window_start / 1000000.0);
        }
        else
        {
            earliest_window_start = 0;
            //INFO << "FERatePredictor: earliest_window_start(sec) = 0";
        }

        // scrub stale entries, useful when request arrives after a long time!
        for ( RequestHistoryType::iterator it = history.begin();
              it != history.end(); )
        {
            if (it->start < earliest_window_start)
            {
                //INFO << "FERatePredictor: deleting " << it->str();
                it = history.erase(it);
            }
            else
            {
                it++;
            }
        }

        //INFO << "FERatePredictor: history after scrubbing old entries";
        //print_history();

        if (history.empty() || now >= history.back().end)
        {
            TimeUs start = now - (now % step_size);
            TimeUs end = start + step_size;
            RequestHistoryEntry e(start, end, 1);
            history.push_back(e);
        }
        else if (now >= history.back().start && now < history.back().end)
        {
            history.back().count++;
        }
        else
        {
            assert (false);
        }

        if (history.size() * step_size <= window_size)
        {
            //INFO << "FERatePredictor: Not enough data for regression";
            //INFO << "FERatePredictor: Estimate current rate";
            //INFO << "FERatePredictor: Approximate the estimated rate as the predicted rate";

            unsigned int total_count = 0;
            for (unsigned int i = 0; i < history.size(); i++)
            {
                total_count += history[i].count;
            }

            double rate = ((double)(total_count * num_fes)) / 
                          (history.back().end - history.front().start);

            INFO << "STATS_PREDICTED_RATE " << (now + step_size) << " " << rate;
            return;
        }

        vector<double> X;
        vector<double> Y;

        unsigned int steps_per_window = window_size / step_size;

        for ( unsigned int start_index = 0;
              start_index <= history.size() - steps_per_window;
              start_index++ )
        {
            unsigned int request_count = 0;
            for ( unsigned int i = start_index;
                  i < start_index + steps_per_window; i++ )
            {
                request_count += history[i].count;
            }

            double x = history[start_index + steps_per_window - 1].end;
            double y = ((request_count * num_fes) / ((double)window_size));

            X.push_back(x);
            Y.push_back(y);
        }

        TimeUs testX = now + step_size;
        double testY = fit_line_and_predict2(X, Y, testX);
        if (testY < 0) { testY = 0; }

        INFO << "STATS_PREDICTED_RATE " << testX << " " << testY;
    }*/
};

#endif
