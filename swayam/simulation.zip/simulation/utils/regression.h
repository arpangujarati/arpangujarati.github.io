#ifndef REGRESSION_H
#define REGRESSION_H

#include <vector>   // std::vector
#include <utility>  // std::pair, std::make_pair

double fit_line_and_predict(const std::vector<double>& Y, double x);

double fit_line_and_predict2( const std::vector<double>& X, 
                              const std::vector<double>& Y,
                              double x_new );

std::pair<double, double> fit_line(const std::vector<double>& Y);

std::pair<double, double> fit_line2( const std::vector<double>& X, 
                                     const std::vector<double>& Y );

std::vector<double> fit_line_and_predict3( const std::vector<double>& X,
                                           const std::vector<double>& Y,
                                           const std::vector<double>& testX );

#endif
