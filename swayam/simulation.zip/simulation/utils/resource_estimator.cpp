#include "resource_estimator.h"
#include "model.h"

unsigned int get_num_bes( Category *logger, unsigned int max_bes, double rate,
                          double perc, TimeUs max_rt, ServiceInfoType *st_info )
{
    assert (rate > 0);

    unsigned int min_bes = 1;

    while(max_bes > min_bes)
    {
        unsigned int desired_mid = (min_bes + max_bes) / 2;

        if ((st_info->exe_time_us * rate) >= desired_mid)
        {
            min_bes = desired_mid + 1;
            continue;
        }

        TimeUs perc_rt = get_perc_rt( logger, rate, desired_mid, perc,
                                      FE2BE_DELAY_US, BE2FE_DELAY_US,
                                      RETRY_DELAY_US, st_info );

        if (perc_rt <= max_rt)
        {
            max_bes = desired_mid;
            continue;
        }

        min_bes = desired_mid + 1;
    }

    return max_bes;
}

/*void recompute_desired_rt ( int&desired, int desired_max, double percentile,
                            double predicted, TimeUs exe_time_us,
                            TimeUs max_resp_time_us, TimeUs error_margin_us )
{
    if (predicted <= 0)
        return;

    int desired_min = 1;

    while(desired_max > desired_min)
    {
        int desired_mid = (desired_min + desired_max) / 2;

        if ((exe_time_us * predicted) >= desired_mid)
        {
            desired_min = desired_mid + 1;
            continue;
        }

        TimeUs resp_time_us = exe_time_us + percentile_wait_time_mdn(
            desired_mid, predicted, exe_time_us, percentile );

        cout << "percentile " << percentile;
        cout << "desired_min, _max " << desired_min << " " << desired_max << endl;
        cout << "resp_time_us " << resp_time_us << endl;
        cout << "max_resp_time_us " << max_resp_time_us << endl;

        if (error_margin_us + resp_time_us <= max_resp_time_us)
        {
            desired_max = desired_mid;
            continue;
        }

        desired_min = desired_mid + 1;
    }

    desired = desired_max;
}

void recompute_desired( Category *logger, int& desired, int desired_max,
                        double percentile, double predicted, TimeUs exe_time_us,
                        TimeUs max_wait_time_us, TimeUs error_margin_us )
{
    if (predicted <= 0)
        return;

    int desired_min = 1;

    while(desired_max > desired_min)
    {
        int desired_mid = (desired_min + desired_max) / 2;

        if ((exe_time_us * predicted) >= desired_mid)
        {
            INFO << "desired_min " << desired_min << " -> " << (desired_mid + 1);
            desired_min = desired_mid + 1;
            continue;
        }

        double wait_time_us_db = percentile_wait_time_mdn(
            desired_mid, predicted, exe_time_us, percentile );

        if (wait_time_us_db == std::numeric_limits<double>::infinity())
        {
            INFO << "encountered infinity " << desired_min << " -> "
                 << (desired_mid + 1);
            desired_min = desired_mid + 1;
            continue;
        }

        TimeUs wait_time_us = wait_time_us_db;

        INFO << "desired_mid " << desired_mid;
        INFO << "wait_time_us " << wait_time_us;

        if (error_margin_us + wait_time_us <= max_wait_time_us)
        {
            INFO << "desired_max " << desired_max << " -> " << desired_mid;
            desired_max = desired_mid;
            continue;
        }

        INFO << "desired_min " << desired_min << " -> " << (desired_mid + 1);
        desired_min = desired_mid + 1;
    }

    desired = desired_max;
}*/

