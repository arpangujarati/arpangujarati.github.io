#include "logging.h"
#include "basics.h"
                         
bool get_new_logger(string id, int prio, Category **logger_pp)
{
    try
    {
        Appender *app = new OstreamAppender("console", &std::cout);
        Layout *layout = new BasicLayout();
        app->setLayout(layout);
        Category& logger = Category::getInstance(id);
        logger.setAdditivity(false);
        logger.setAppender(app);
        logger.setPriority(prio);
        (*logger_pp) = &logger;
        return true;
    }
    catch(const exception& e)
    {
        cerr << "Error: Creation of logger \"" << id << "\" failed " 
             << "with exception " << e.what() << flush;
        return false;
    }
}

bool get_new_logger(string id, string file, int prio, Category **logger_pp)
{
    try
    {
        Appender *app = new FileAppender("FileAppender", file);
        Layout *layout = new BasicLayout();
        app->setLayout(layout);
        Category& logger = Category::getInstance(id);
        logger.setAdditivity(false);
        logger.setAppender(app);
        logger.setPriority(prio);
        (*logger_pp) = &logger;
        return true;
    }
    catch(const exception& e)
    {
        cerr << "Error: Creation of logger \"" << id << "\" failed " 
             << "with exception " << e.what() << flush;
        return false;
    }
}
