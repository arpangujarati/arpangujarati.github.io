#ifndef CHRONO_H
#define CHRONO_H

#include "basics.h"
#include "logging.h"

#include <chrono>   // chrono::steady_clock
#include <thread>   // this_thread::sleep-for

//#include <ctime>    // tm, time_t
//#include <time.h>   // time_t, struct tm, time, mktime

// we use the steady_clock by default;
// it has a precision of 0.000001 ms on my laptop and the pinky machines
typedef chrono::steady_clock::time_point TimePointType;

typedef chrono::system_clock::time_point TimePointTypeSys;
//typedef chrono::high_resolution_clock::time_point TimePointTypeHr;

typedef chrono::microseconds Chrono_us;
typedef chrono::milliseconds Chrono_ms;
typedef chrono::seconds Chrono_sec;

typedef chrono::duration<int> Duration_sec;
typedef chrono::duration<int, std::milli> Duration_ms;
typedef chrono::duration<int, std::micro> Duration_us;

#define CHRONO_NOW chrono::steady_clock::now()
#define CHRONO_SEED CHRONO_NOW.time_since_epoch().count()

//#define CHRONO_HRC_NOW chrono::high_resolution_clock::now()
//#define CHRONO_SEED CHRONO_HRC_NOW.time_since_epoch().count()

#define CHRONO_DURATION_MS chrono::duration_cast<Chrono_ms>
#define CHRONO_DURATION_US chrono::duration_cast<Chrono_us>
#define CHRONO_DURATION_SEC chrono::duration_cast<Chrono_sec>

TimePointTypeSys parse_time_point_from_string(string tp_str, Category *logger);

TimeUs get_elapsed_time_us();
#define NOW_US (get_elapsed_time_us(exp_start_tp))

TimeUs get_elapsed_time_us(TimePointType start_time);

void spin_for_us(TimeUs duration_us, Category *logger);

#define SLEEP_FOR_US(x) (this_thread::sleep_for(Chrono_us(x)))

#endif
