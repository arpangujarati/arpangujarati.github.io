﻿/*

FitLine method below is adopted from Math.NET library that requires
to retain the following copyright:

Math.NET Numerics, part of the Math.NET Project
http://numerics.mathdotnet.com
http://github.com/mathnet/mathnet-numerics
http://mathnetnumerics.codeplex.com

Copyright (c) 2009-2013 Math.NET

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

*/

#include "regression.h"

#include <assert.h> // assert
#include <vector>   // std::vector
#include <utility>  // std::pair, std::make_pair

std::vector<double> fit_line_and_predict3( const std::vector<double>& X,
                                           const std::vector<double>& Y,
                                           const std::vector<double>& testX )
{
    assert (X.size() == Y.size());

    std::pair<double, double> line = fit_line2(X, Y);
    double intercept = line.first;
    double slope = line.second;

    std::vector<double> testY;
    for ( std::vector<double>::const_iterator it = testX.begin();
          it != testX.end(); ++it )
    {
        testY.push_back(intercept + ((*it) * slope));
    }

    return testY;
}

double fit_line_and_predict2( const std::vector<double>& X,
                              const std::vector<double>& Y,
                              double x_new )
{
    assert (X.size() == Y.size());

    std::pair<double, double> line = fit_line2(X, Y);
    double intercept = line.first;
    double slope = line.second;
    return intercept + (x_new * slope);
}

double fit_line_and_predict(const std::vector<double>& Y, double x)
{
    std::pair<double, double> line = fit_line(Y);

    double intercept = line.first;
    double slope = line.second;

    return intercept + (x * slope);
}

/// <summary>
/// Least-Squares fitting the points (x,y) to a line y : x -> a+b*x,
/// returning its best fitting parameters as (a, b) tuple,
/// where a is the intercept and b the slope.
/// The x coordinates are implicitly assumed to be 0, 1, 2, ..., y.Length-1
/// </summary>
/// <param name="y">Response (dependent)</param>
std::pair<double, double> fit_line(const std::vector<double>& Y)
{
    /* Given a set of points, i.e., an array of the x coordinates
     * and the y coordinates, respectively, the method returns the line
     * that best fits these points. The line is represented as a pair 
     * (y-intercept, slope). Thus, the line equation is: 
     * y = y-intercept + (x * slope). */

    assert (Y.size() > 1);

    // First Pass: Mean
    double mx = 0.0;
    double my = 0.0;
    for (unsigned int i = 0; i < Y.size(); i++)
    {
        mx += i;
        my += Y[i];
    }

    mx /= Y.size();
    my /= Y.size();

    // Second Pass: Covariance/Variance
    double covariance = 0.0;
    double variance = 0.0;
    for (unsigned int i = 0; i < Y.size(); i++)
    {
        double diff = i - mx;
        covariance += diff * (Y[i] - my);
        variance += diff * diff;
    }

    double b = covariance / variance;
    return std::make_pair(my - b * mx, b);
}

std::pair<double, double> fit_line2( const std::vector<double>& X,
                                     const std::vector<double>& Y )
{
    /* Given a set of points, i.e., an array of the x coordinates
     * and the y coordinates, respectively, the method returns the line
     * that best fits these points. The line is represented as a pair 
     * (y-intercept, slope). Thus, the line equation is: 
     * y = y-intercept + (x * slope). */

    assert (X.size() == Y.size());
    assert (Y.size() > 1);

    // First Pass: Mean
    double mx = 0.0;
    double my = 0.0;
    for (unsigned int i = 0; i < Y.size(); i++)
    {
        mx += X[i];
        my += Y[i];
    }

    mx /= Y.size();
    my /= Y.size();

    // Second Pass: Covariance/Variance
    double covariance = 0.0;
    double variance = 0.0;
    for (unsigned int i = 0; i < Y.size(); i++)
    {
        double diff = X[i] - mx;
        covariance += diff * (Y[i] - my);
        variance += diff * diff;
    }

    double b = covariance / variance;
    return std::make_pair(my - b * mx, b);
}
