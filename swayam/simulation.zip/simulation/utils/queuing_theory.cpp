#include "queuing_theory.h"

#include <limits>   // std::numeric_limits
#include <math.h>   // log, exp
#include <assert.h> // assert

double percentile_wait_time_mdn ( int num_servers,
                                  double mean_arrival_rate,
                                  double mean_service_time,
                                  double percentile )
{
    double mmn_wait_time = percentile_wait_time_mmn( num_servers,
                                                     mean_arrival_rate,
                                                     mean_service_time,
                                                     percentile );

    return 0.5 * mmn_wait_time;
    //return 1 * mmn_wait_time;
}

double percentile_wait_time_mmn ( int num_servers,
                                  double mean_arrival_rate,
                                  double mean_service_time,
                                  double percentile )
{
    /* For brevity, we let n = num_servers, lambda = mean_arrival_rate,
     * and mu = 1/mean_service_time. Also let the traffic intensity be
     * denoted as p = lambda / mu, and the Erlang-C value be denoted as
     * c(n, p). The percentile waiting time for M/M/n queuing model is:
     * W = [1/(mu*(n-p))] * ln[(100*C(n, p))/(100-percentile)].
     * Note that since factorial and erlang-c calculations are not
     * possible for larger values of n, if n > MAX_ALLOWED_NUM_SERVERS,
     * we approximate the computation. We reduce lam by a factor of 
     * n / MAX_ALLOWED_NUM_SERVERS, and use n = MAX_ALLOWED_NUM_SERVERS
     * instead. */

    int n = num_servers;
    double lam = mean_arrival_rate;
    double mu = 1 / mean_service_time;
    double p = lam / mu;

    if (p >= n)
    {
        return std::numeric_limits<double>::infinity();
    }

    double c = erlang_c(n, p);
    double log_arg = (100 * c) / (100 - percentile);

    if (log_arg < 1)
    {
        return 0;
    }

    return log(log_arg) / (mu * (n - p));
}

double erlang_c( int num_servers,
                 double mean_arrival_rate,
                 double mean_service_time )
{
    double traffic_intensity = mean_arrival_rate * mean_service_time;
    return erlang_c(num_servers, traffic_intensity);
}

double erlang_c(int num_servers, double traffic_intensity)
{
    /* For brevity, we let n = num_servers and p = traffic_intensity.
     * The Erlang-C formula is given as follows:
     * Numerator = (p^n / n!) * (n / n-p)
     * Denominator = [sum_(k from 0 to n-1) (p^k / k!)] + Numerator
     * Erlang-C(n, p) = Numerator / Denominator.
     * Note that Erlang-C(1, p) = p. */

    if (traffic_intensity >= num_servers)
    {
        return 1;
    }

    int n = num_servers;
    double p = traffic_intensity;

    if (n == 1)
    {
        return p;
    }
    
    double nr = power_by_factorial(p, n) * (n / (n - p));

    double dr = 0;
    for (int k = 0; k < n; k++)
    {
        dr += power_by_factorial(p, k);
    }

    dr += nr;

    return nr / dr;
}

double prob_rt_leq_x( int num_servers, double mean_arrival_rate,
                      double mean_service_time, double x )
{
    return 1 - prob_rt_gt_x(num_servers, mean_arrival_rate, mean_service_time, x);
}

double prob_rt_gt_x( int num_servers, double mean_arrival_rate,
                     double mean_service_time, double x )
{
    /* For brevity, we let n = num_servers, lambda = mean_arrival_rate,
     * and mu = 1/mean_service_time. Also let the traffic intensity be
     * denoted as p = lambda / mu, and the prob be deonted as p_rt_gt_x.
     * Let y = n - 1 - p, then
     * p_rt_gt_x = e^(-ux)[1 + (p^n/n!)(p_0/(1-a))((1-e^(-uxy))/y)].
     * If term1 = e^(-ux), term2 = (p^n/n!), term3 = (p_0/(1-a)),
     * term4 = ((1-e^(-uxy))/y), then:
     * p_rt_gt_x = term1 * [1 + term2 * term3 * term4]. */

    int n = num_servers;
    double lam = mean_arrival_rate;
    double mu = 1 / mean_service_time;
    double p = lam / mu;
    double a = p / n;

    double y = n - 1 - p;

    double term1 = exp((-1) * mu * x);
    double term2 = power_by_factorial(p, n);
    double term3 = p_0(n, p) / (1 - a);
    double term4 = (1 - exp((-1) * mu * x * y)) / y;

    return (term1 * (1 + (term2 * term3 * term4)));
}

double p_0(int num_servers, double traffic_intensity)
{
    /* For brevity, we let n = num_servers, p = traffic_intensity, and
     * a = utlization = p / n. p_0 is defined as follows.
     * p_0 = [sum_{k=0}^{n-1}(p^k/k!) + (p^n/n!)(1/(1-a))]^(-1).
     * We let term1 = sum_{k=0}^{n-1}(p^k/k!), term2 = (p^n/n!)(1/(1-a)),
     * and p_0 = [term1 + term2]^(-1). */

    int n = num_servers;
    double p = traffic_intensity;
    double a = p / n;

    double term1 = 0;
    for (int k = 0; k <= n - 1; k++)
       term1 += power_by_factorial(p, k);
    
    double term2 = power_by_factorial(p, n) / (1 - a);

    return (1 / (term1 + term2));
}

// Calculates p^n / n! avoiding overflows
double power_by_factorial(double p, int n)
{
    // The result of p^n/n! is not that big but nominator and denominator are huge
    // So use the following equation to avoid overflows:
    // p^n/n! = e^log(p^n / n!) = e^(log(p^n) - log(n!)) = e^(n*log(p) - log(n!))
    return exp(n * log(p) - log_factorial(n));
}

// Calculate log(n!) to avoid overflows in n! for big values of n.
// Based on property that log(a*b) = log(a) + log(b)
double log_factorial(int n)
{
    assert (n >= 0);

    if (n <= 1)
    {
        return 0;
    }

    return log(n) + log_factorial(n - 1);
}
