#ifndef LOGGING_H
#define LOGGING_H

#include "basics.h"

#include "log4cpp/Category.hh"
#include "log4cpp/FileAppender.hh"
#include "log4cpp/OstreamAppender.hh"
#include "log4cpp/BasicLayout.hh"

using namespace log4cpp;

#define DEBUG   logger->debugStream()
#define INFO    logger->infoStream()
#define ERROR   logger->errorStream()

bool get_new_logger(string id, int prio, Category **logger_pp);
bool get_new_logger(string id, string file, int prio, Category **logger_pp);

#endif
