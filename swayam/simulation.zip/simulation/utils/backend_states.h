#ifndef BACKEND_STATES_H
#define BACKEND_STATES_H

enum StateType {BUSY = 0, COLD = 1, WARM = 2};

string StateTypeStr(StateType type);

#endif
