#include "file_io_sim.h"

#include <fstream>  // ifstream

bool get_add_strs_from_file(string filename, vector<string>& adds)
{
    ifstream myfile (filename);

    if (!myfile.is_open())
    {
        cerr << "Error: Could not open file " << filename << "\n" << flush;
        return false;
    }
 
    string line;
    while (getline(myfile, line))
        adds.push_back(line);

    myfile.close();

    if (adds.empty())
    {
        cerr << "Error: No addresses in file " << filename << "\n" << flush;
        return false;
    }

    return true;
}

bool get_all_add_strs_from_file( string add_dir,
                                 vector<string>& cl_adds,
                                 vector<string>& br_adds,
                                 vector<string>& fe_adds,
                                 vector<string>& be_adds )
{
    return ( get_add_strs_from_file(add_dir + "client.txt", cl_adds) &&
             get_add_strs_from_file(add_dir + "broker.txt", br_adds) &&
             get_add_strs_from_file(add_dir + "frontend.txt", fe_adds) &&
             get_add_strs_from_file(add_dir + "backend.txt", be_adds) );
}

bool get_all_services_from_file( string config_dir,
                                 map<int, TimeUs>& setup_times,
                                 map<int, TimeUs>& exe_times )
{
    string filename = config_dir + "setup_times.txt";
    ifstream myfile (filename);

    if (!myfile.is_open())
    {
        cerr << "Error: Could not open file " << filename << "\n" << flush;
        return false;
    }

    string line;
    while (getline(myfile, line))
    {
        size_t pos = line.find(" ");
        int sid = stoi(line.substr(0, pos));
        line.erase(0, pos + 1);

        pos = line.find(" ");
        setup_times[sid] = stoull(line.substr(0, pos));
        line.erase(0, pos + 1);

        exe_times[sid] = stoull(line);
    }

    if (setup_times.empty())
    {
        cerr << "Error: No services detected in fi;e "
             << filename << "\n" << flush;
        myfile.close();
        return false;
    }

    myfile.close();
    return true;
}

bool get_services_from_file(string config_dir, ServicesInfoMap& services)
{
    string filename = config_dir + "setup_times.txt";
    ifstream myfile (filename);

    if (!myfile.is_open())
    {
        cerr << "Error: Could not open file " << filename << "\n" << flush;
        return false;
    }

    string line;
    while (getline(myfile, line))
    {
        ServiceInfoType *info = new ServiceInfoType();

        sscanf( line.c_str(), "%u %llu %llu %lf %lf %lf", &info->sid,
                &info->setup_time_us, &info->exe_time_us, &info->logn_s_us,
                &info->logn_loc_us, &info->logn_scale_us );

        services[info->sid] = info;
    }

    if (services.empty())
    {
        cerr << "Error: No services detected in file "
             << filename << "\n" << flush;
        myfile.close();
        return false;
    }

    myfile.close();
    return true;
}
