#ifndef UTILS_RESOURCE_ESTIMATOR_H
#define UTILS_RESOURCE_ESTIMATOR_H

#include "basics.h"
#include "logging.h"
#include "file_io_sim.h"

unsigned int get_num_bes( Category *logger, unsigned int max_bes, double rate,
                          double perc, TimeUs max_rt, ServiceInfoType *st_info );

/*void recompute_desired_rt( int& desired, int desired_max, double percentile,
                           double predicted, TimeUs exe_time_us,
                           TimeUs max_resp_time_us, TimeUs error_margin_us );

void recompute_desired( Category *logger, int& desired, int desired_max,
                        double percentile, double predicted, TimeUs exe_time_us,
                        TimeUs max_wait_time_us, TimeUs error_margin_us );*/

#endif
