#ifndef GLOBAL_STORE_H
#define GLOBAL_STORE_H

#include "localstore.h"
#include "misc.h"

#include "log4cpp/Category.hh"

//#include <algorithm>    // maxS
#include <string>       // string
#include <iostream>     // cout
#include <map>          // map
#include <vector>       // vector
#include <utility>      // pair, make_pair
#include <assert.h>     // assert

typedef map<int, pair<int, int>> InterStoreType;
typedef map<int, int> AggregateStoreType;
typedef vector<pair<int, double>> AggregateRatesType;

typedef map<string, LocalStoreType> GlobalStoreType;

class GlobalStore // version 3
{
  private:
    int num_bins;
    int bin_size;
    int window_size;
    int store_size;
    int staleness;
    GlobalStoreType store;
    Category *logger;

  public:
    GlobalStore() {}

    GlobalStore(int num_bins, int bin_size, int window_size, int staleness)
                : num_bins(num_bins), bin_size(bin_size),
                  window_size(window_size), staleness(staleness)
    {
        store_size = num_bins * bin_size;
    }

    ~GlobalStore() {}

    bool init( int num_bins, int bin_size,
               int window_size, int staleness,
               Category *logger )
    {
        this->num_bins = num_bins;
        this->bin_size = bin_size;
        this->window_size = window_size;
        this->store_size = num_bins * bin_size;
        this->staleness = staleness;
        this->logger = logger;
        return true;
    }

    GlobalStoreType& get_store()
    {
        return store;
    }

    void update(string add, LocalStoreType local_store)
    {
        store[add] = local_store;
    }

    void sanitize_local_stores()
    {
        for ( GlobalStoreType::iterator it = store.begin();
              it != store.end(); it++ )
        {
            LocalStoreType& local_store = it->second;

            if (local_store.size() == 0)
                continue;

            int time = 0;  // time corresponding to a bin
            int index = 0; // index of that bin

            for (unsigned int j = 0; j < local_store.size(); j++)
            {
                if (local_store[j].first > time)
                {
                    time = local_store[j].first;
                    index = j;
                }
            }

            for (int j = 0; j < num_bins; j++)
            {
                if (local_store[index].first < time)
                    local_store[index] = make_pair(time, 0);

                index = (index + num_bins - 1) % num_bins;

                if (time - bin_size > 0)
                    time = time - bin_size;
                else
                    time = 0;
            }
        }
    }

    AggregateStoreType get_aggregate_store(int time)
    {
        InterStoreType inter_store;
        int active_backends = 0;

        for ( GlobalStoreType::iterator itg = store.begin();
              itg != store.end(); itg++ )
        {
            LocalStoreType& local_store = itg->second;

            if (local_store.empty())
                continue;

            bool active_local_store = false;

            for ( LocalStoreType::iterator itl = local_store.begin();
                  itl != local_store.end(); itl++ )
            {
                int& bin_time = itl->first;
                int& bin_reqs = itl->second;
                
                if (time - bin_time > staleness * store_size)
                   continue;

                active_local_store = true;

                if (inter_store.find(bin_time) == inter_store.end())
                    inter_store[bin_time] = make_pair(0, 0);

                inter_store[bin_time].first += bin_reqs;
                inter_store[bin_time].second += 1;
            }

            if (active_local_store)
                active_backends++;
        }

        AggregateStoreType aggregate_store;

        for ( InterStoreType::iterator iti = inter_store.begin();
              iti != inter_store.end(); iti++ )
        {
            const int& key = iti->first; // time
            const pair<int, int>& val = iti->second; // (#Reqs, #BEs)

            // Approach 1, where we approximate missing bins
            aggregate_store[key] = (val.first / ((float)val.second)) *
                                   active_backends;

            // Approach 2, where we forget about missing bins
            //aggregate_store[key] = val.first;
        }

        /*
        // to erase starting effects
        int lowest_time_with_non_zero_val = -1;
        for ( AggregateStoreType::iterator ita = aggregate_store.begin();
              ita != aggregate_store.end(); ita++ )
        {
            if (ita->second > 0)
            {
                if ( lowest_time_with_non_zero_val == -1 ||
                     ita->first < lowest_time_with_non_zero_val )
                {
                    lowest_time_with_non_zero_val = ita->first;
                }
            }
        }

        for ( AggregateStoreType::iterator ita = aggregate_store.begin();
              ita != aggregate_store.end(); )
        {
            if (ita->first < lowest_time_with_non_zero_val)
            {
                aggregate_store.erase(ita++);
            }
            else
            {
                ++ita;
            }
        }*/

        return aggregate_store;
    }

    AggregateRatesType get_aggregate_rates(int time)
    {
        sanitize_local_stores();
        //dump_global_store(store, logger);
        AggregateStoreType agg_store = get_aggregate_store(time);
        //dump_aggregate_store(agg_store, logger);

        AggregateRatesType rates;

        int highest_time = 0;
        int lowest_time = 0;
        bool is_first_entry = true;

        for ( AggregateStoreType::iterator it = agg_store.begin();
              it != agg_store.end(); it++ )
        {
            if (is_first_entry)
            {
                is_first_entry = false;
                lowest_time = it->first;
            }

            if (it->first > highest_time)
                highest_time = it->first;
        }

        int window_start = lowest_time;
        while(window_start + window_size <= highest_time)
        {
            int window_end = window_start + window_size;
            rates.push_back(make_pair(window_end, 0));

            for ( AggregateStoreType::iterator it = agg_store.begin();
                  it != agg_store.end(); it++ )
            {
                if (it->first < window_start)
                    continue;

                if (it->first >= window_end)
                    continue;

                rates.back().second += it->second;
            }

            window_start += bin_size;
        }

        for ( AggregateRatesType::iterator it = rates.begin();
              it != rates.end(); it++ )
        {
            it->second /= ((float)window_size);
        }

        //dump_aggregate_rates(rates, logger);
        return rates;
    }

    static void dump_global_store( GlobalStoreType& store,
                                   Category *logger,
                                   string msg = "" )
    {
        for ( GlobalStoreType::iterator it = store.begin();
              it != store.end(); it++ )
        {
            string final_msg = "(in GlobalStore) @" + it->first;
            if (!msg.empty())
               final_msg += " " + msg;
            LocalStoreType& local_store = it->second;
            LocalStore::dump_local_store(local_store, logger, final_msg);
        }
    }

    static void dump_aggregate_rates( AggregateRatesType& rates,
                                      Category *logger,
                                      string msg = "" )
    {
        string logmsg = "AggregateRates";
        if (!msg.empty())
            logmsg += " " + msg;
        for ( AggregateRatesType::iterator it = rates.begin();
              it != rates.end(); it++ )
            logmsg += " (" + to_string(it->first) + ", " +
                      to_string(it->second) + ")";
        INFO << logmsg;
    }

    static void dump_aggregate_store( AggregateStoreType& agg_store,
                                      Category *logger,
                                      string msg = "" )
    {
        string logmsg = "AggregateStore";
        if (!msg.empty())
            logmsg += " " + msg;
        for ( AggregateStoreType::iterator it = agg_store.begin();
              it != agg_store.end(); it++ )
            logmsg += " (" + to_string(it->first) + ", " +
                      to_string(it->second) + ")";
        INFO << logmsg;
    }
};

/*
typedef map<string, LocalStoreType> GlobalStoreType;
typedef LocalStoreType AggregateStoreType;
typedef vector<pair<TimeUs, double>> AggregateRatesType;
class GlobalStore // version 2
{
  private:
    unsigned int window_size;
    unsigned int step_size;
    unsigned int history_size;
    GlobalStoreType store;
    Category *logger;

  public:
    GlobalStore() {}

    ~GlobalStore() {}

    bool init( unsigned int window_size,
               unsigned int history_size,
               Category *logger )
    {
        INFO << "Init GlobalStore with Moving Window Size " << window_size
             << " and History Size " << history_size;

        this->window_size = window_size;
        this->step_size = window_size / 10.0;
        this->history_size = history_size;
        this->logger = logger;

        return true;
    }

    GlobalStoreType& get_store()
    {
        return store;
    }

    void update(string add, LocalStoreType local_store)
    {
        store[add] = local_store;
    }

    AggregateStoreType get_aggregate_store()
    {
        AggregateStoreType aggregate_store;

        for ( GlobalStoreType::iterator it = store.begin();
              it != store.end(); it++ )
        {
            LocalStoreType& local_store = it->second;

            for ( LocalStoreType::iterator it = local_store.begin();
                  it != local_store.end(); it++ )
            {
                TimeUs & arrival = (*it);
                if (arrival != 0)
                {
                    aggregate_store.push_back(arrival);
                }
            }
        }

        return aggregate_store;
    }

    AggregateRatesType get_aggregate_rates(unsigned int time)
    {
        AggregateRatesType rates;
        AggregateStoreType agg_store = get_aggregate_store();

        TimeUs latest_arrival = 0;
        for ( AggregateStoreType::iterator it = agg_store.begin();
              it != agg_store.end(); it++ )
        {
            TimeUs & arrival = (*it);
            if (arrival > latest_arrival)
            {
                latest_arrival = arrival;
            }
        }

        TimeUs window_start;
        if (time > history_size)
        {
            window_start = time - history_size;
        }
        else
        {
            window_start = 0;
        }

        TimeUs last_window_start;
        if (latest_arrival > window_size)
        {
            last_window_start = latest_arrival - window_size;
        }
        else
        {
            last_window_start = latest_arrival;
        }

        while(window_start <= last_window_start)
        {
            TimeUs window_end = window_start + window_size;
            rates.push_back(make_pair(window_end, 0));

            for ( AggregateStoreType::iterator it = agg_store.begin();
                  it != agg_store.end(); it++ )
            {
                TimeUs & arrival = (*it);
                if (arrival < window_start)
                {
                    continue;
                }
                else if (arrival >= window_end)
                {
                    continue;
                }
                else
                {
                    rates.back().second += 1;
                }
            }

            window_start += step_size;
        }

        for ( AggregateRatesType::iterator it = rates.begin();
              it != rates.end(); it++ )
        {
            it->second /= ((float)window_size);
        }

        return rates;
    }

    static void dump_global_store( GlobalStoreType& store,
                                   Category *logger,
                                   string msg = "")
    {
        for ( GlobalStoreType::iterator it = store.begin();
              it != store.end(); it++ )
        {
            string final_msg = "(in GlobalStore) @" + it->first;
            if (!msg.empty())
               final_msg += " " + msg;
            LocalStoreType& local_store = it->second;
            LocalStore::dump_local_store(local_store, logger, final_msg);
        }
    }

    static void dump_aggregate_rates( AggregateRatesType& rates,
                                      Category *logger,
                                      string msg = "")
    {
        string logmsg = "AggregateRates";
        if (!msg.empty())
            logmsg += " " + msg;
        for ( AggregateRatesType::iterator it = rates.begin();
              it != rates.end(); it++ )
            logmsg += " (" + to_string(it->first) + ", " +
                      to_string(it->second) + ")";
        INFO << logmsg;
    }
};*/

/*
// key = timestamp, val = [#request, #BEs]
//typedef map<unsigned int, UIntPairType> InterStoreType;

// key = timestamp, val = #requests
// typedef map<unsigned int, double> AggregateStoreType;

// key = timestamp, val = request-rate
//typedef  map<unsigned int, double> AggregateRatesType;

class GlobalStore // version 1
{
  private:
    unsigned int num_quanta;
    unsigned int quantum_size;
    unsigned int window_size;
    unsigned int staleness;
    GlobalStoreType store;
    Category *logger;

  public:
    GlobalStore() {}

    GlobalStore( unsigned int num_nodes,
                 unsigned int num_quanta,
                 unsigned int quantum_size,
                 unsigned int staleness )
                 : num_quanta(num_quanta),
                   quantum_size(quantum_size),
                   staleness(staleness)
    {
        window_size = num_quanta * quantum_size;

        //for (unsigned int i = 0; i < num_nodes; i++)
        //{
        //    LocalStoreType empty_local_store;
        //    store.push_back(empty_local_store);
        //}
    }

    ~GlobalStore() {}

    bool init( unsigned int num_nodes,
               unsigned int num_quanta,
               unsigned int quantum_size,
               unsigned int staleness,
               Category *logger )
    {
        this->num_quanta = num_quanta;
        this->quantum_size = quantum_size;
        this->staleness = staleness;
        this->window_size = num_quanta * quantum_size;
        this->logger = logger;

        return true;
    }

    GlobalStoreType& get_store()
    {
        return store;
    }

    void update(string add, LocalStoreType local_store)
    {
        store[add] = local_store;
    }

    void sanitize_local_stores()
    {
        for ( GlobalStoreType::iterator it = store.begin();
              it != store.end(); it++ )
        {
            LocalStoreType& local_store = it->second;

            if (local_store.size() == 0)
                continue;

            unsigned int max_timestamp = 0;
            unsigned int index_max_timestamp = 0;

            for (unsigned int j = 0; j < local_store.size(); j++)
            {
                if (local_store[j].first > max_timestamp)
                {
                    max_timestamp = local_store[j].first;
                    index_max_timestamp = j;
                }
            }

            unsigned int curr_timestamp = max_timestamp;
            unsigned int curr_index = index_max_timestamp;
            
            assert (local_store[curr_index].first == curr_timestamp);

            for (unsigned int j = 0; j < num_quanta; j++)
            {
                if (local_store[curr_index].first < curr_timestamp)
                {
                    local_store[curr_index] = make_pair(curr_timestamp, 0);
                }
                else
                {
                    assert (local_store[curr_index].first == curr_timestamp);
                }

                curr_index = (curr_index - 1 + num_quanta) % num_quanta;

                // TODO get the max function working
                //curr_timestamp = max(0, curr_timestamp - quantum_size);
                if (curr_timestamp - quantum_size > 0)
                    curr_timestamp = curr_timestamp - quantum_size;
                else
                    curr_timestamp = 0;
            }
        }
    }

    AggregateStoreType get_aggregate_store(unsigned int time)
    {
        InterStoreType inter_store;
        unsigned int active_backends = 0;

        for ( GlobalStoreType::iterator it = store.begin();
              it != store.end(); it++ )
        {
            LocalStoreType& local_store = it->second;

            if (local_store.empty())
                continue;

            bool active_local_store = false;

            for (unsigned int j = 0; j < local_store.size(); j++)
            {
                LocalStoreEntry& local_store_entry = local_store[j];
                
                if ( time - local_store_entry.first > 
                     staleness * window_size )
                {
                   continue;
                }

                active_local_store = true;

                if ( inter_store.find(local_store_entry.first) ==
                     inter_store.end())
                {
                    inter_store[local_store_entry.first] =
                        make_pair(0, 0);
                }

                inter_store[local_store_entry.first].first +=
                    local_store_entry.second;
                inter_store[local_store_entry.first].second += 1;
            }

            if (active_local_store)
                active_backends++;
        }

        AggregateStoreType aggregate_store;

        for ( InterStoreType::iterator it = inter_store.begin();
              it != inter_store.end(); it++ )
        {
            const unsigned int& inter_store_key = it->first;
            const UIntPairType& inter_store_val = it->second;

            double normalized_num_requests =
                ( inter_store_val.first /
                  ( (float)inter_store_val.second ) )
                * active_backends;

            aggregate_store[inter_store_key] = normalized_num_requests;
        }

        return aggregate_store;
    }

    AggregateRatesType get_aggregate_rates(unsigned int time)
    {
        AggregateRatesType aggregate_rates;

        sanitize_local_stores();
        AggregateStoreType aggregate_store = get_aggregate_store(time);

        
        for ( AggregateStoreType::iterator it = aggregate_store.begin();
              it != aggregate_store.end(); it++ )
        {
            aggregate_rates[it->first] = it->second / quantum_size;
        }

        return aggregate_rates;
    }

    static void dump_global_store( GlobalStoreType& store,
                                   Category *logger,
                                   string msg = "")
    {
        for ( GlobalStoreType::iterator it = store.begin();
              it != store.end(); it++ )
        {
            string final_msg = "(in GlobalStore) @" + it->first;
            if (!msg.empty())
               final_msg += ":" + msg;
            LocalStoreType& local_store = it->second;
            LocalStore::dump_local_store(local_store, logger, final_msg);
        }
    }

    static void dump_aggregate_rates( AggregateRatesType& rates,
                                      Category *logger,
                                      string msg = "")
    {
        string logmsg = "AggregateRates";
        if (!msg.empty())
            logmsg += ":" + msg;
        for ( AggregateRatesType::iterator it = rates.begin();
              it != rates.end(); it++ )
            logmsg += "::" + to_string(it->first) + ":" +
                      to_string(it->second);
        DEBUG << logmsg;
    }
};*/

#endif
