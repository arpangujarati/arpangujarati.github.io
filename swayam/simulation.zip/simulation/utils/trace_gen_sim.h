#ifndef TRACE_GEN_SIM_H
#define TRACE_GEN_SIM_H

#include "trace_entry_type.h"

TraceType get_trace(Category *logger, string tracefile);

#endif
