#include "trace_gen.h"

#include <fstream>  // ifstream
#include <string>   // string

TraceType get_trace(Category *logger, string tracefile)
{
    TraceType trace;

    ifstream myfile;
    myfile.open(tracefile);
    if (!myfile.is_open())
    {
        ERROR << "Failed to open file \"" << tracefile << "\"";
        return trace;
    }

    string line;
    TimeUs prev_arrival_us = 0;
    TimeUs inter_arrival_us;

    while (getline(myfile, line))
    {
        int sid, uid;
        TimeUs arrival_us, exe_time_us;
        sscanf( line.c_str(), "%llu %d %d %llu",
                &arrival_us, &sid, &uid, &exe_time_us );

        assert (arrival_us >= prev_arrival_us);
        inter_arrival_us = arrival_us - prev_arrival_us;

        trace.push_back(TraceEntryType( sid, uid, arrival_us, inter_arrival_us,
                                        exe_time_us ));
        prev_arrival_us = arrival_us;
    }

    myfile.close();
    return trace;
}
