#ifndef LOGGER_H
#define LOGGER_H

#include <chrono>   // std::chrono::high_resolution_clock
#include <fstream>  // std::ofstream
#include <iostream> // std::cout
#include <ostream>  // std::flush
#include <string>   // std::string
#include <time.h>   // time
#include <stdlib.h> // malloc

#define BUFFER_SIZE 2 * 1024 * 1024 // in bytes

typedef std::chrono::microseconds Chrono_us;
typedef std::chrono::milliseconds Chrono_ms;

class Logger
{
  private:
    std::string id;
    std::ofstream logfile;
    char buffer[BUFFER_SIZE];
    unsigned int buffer_index = 0;

    /* 0: log no debug messages
     * 1: log debug messages with severity 1
     * 2: log debug messages with severity 2 or less
     * 3: log debug messages with severity 3 or less
     * and so on ... */
    unsigned int debug_level;

    std::chrono::high_resolution_clock::time_point start_time;

  public:
    Logger( std::string id,
            unsigned int debug_level,
            std::string filename )
           : id(id), debug_level(debug_level)
    {
        start_time = std::chrono::high_resolution_clock::now();
        logfile.open(filename);
    }

    ~Logger()
    {
        flush_all_logs();
        logfile.close();
    }

    void log2file(std::string msg, unsigned int severity, bool flush = false)
    {
        if (severity > debug_level)
            return; 
        
        auto elapsed = std::chrono::high_resolution_clock::now() - start_time;
        auto ms = std::chrono::duration_cast<Chrono_ms>(elapsed).count();
        logfile << ms << "::" << id << "::" << msg << "\n" << std::flush;

        /*msg = std::to_string(time(NULL)) + "::" + id + "::" + msg + "\n";

        if (buffer_index + msg.size() + 1 > BUFFER_SIZE)
        {
            buffer[buffer_index] = '\0';
            logfile << buffer << std::flush;
            buffer_index = 0;
        }

        msg.copy(buffer + buffer_index, msg.size());
        buffer_index += msg.size();*/

        if (flush)
        {
            //buffer[buffer_index] = '\0';
            logfile << buffer << std::flush;
            //buffer_index = 0;
        }
    }

    void log2stdo(std::string msg, unsigned int severity, bool flush = false)
    {
        if (severity > debug_level)
            return;

        //auto elapsed = std::chrono::high_resolution_clock::now() - start_time;
        //auto us = std::chrono::duration_cast<Chrono_us>(elapsed).count();
        std::cout << time(NULL) << "::" << id << "::" << msg << "\n";

        if (flush)
            std::cout << std::flush;
    }

    void log2stde(std::string msg, unsigned int severity, bool flush = false)
    {
        if (severity > debug_level)
            return;

        //auto elapsed = std::chrono::high_resolution_clock::now() - start_time;
        //auto us = std::chrono::duration_cast<Chrono_us>(elapsed).count();
        std::cerr << time(NULL) << "::" << id << "::" << msg << "\n";

        if (flush)
            std::cerr << std::flush;
    }


    void flush_all_logs()
    {
        buffer[buffer_index] = '\0';
        logfile << buffer << std::flush;
        buffer_index = 0;

        std::cout << std::flush;
        std::cerr << std::flush;
    }
};

#endif
