#include "load_balancer.h"

#include <assert.h> // assert

LBPolicyType get_policy_type_enum(string lb_type)
{
    if (lb_type.compare("rand") == 0)
    {
        return LBPolicyType::LB_RAND;
    }
    else if (lb_type.compare("rr") == 0)
    {
        return LBPolicyType::LB_RR;
    }
    else if (lb_type.compare("qfe") == 0)
    {
        return LBPolicyType::LB_QFE;
    }
    else if (lb_type.compare("qbe") == 0)
    {
        return LBPolicyType::LB_QBE;
    }
    else if (lb_type.compare("jiq") == 0)
    {
        return LBPolicyType::LB_JIQ;
    }
    else if (lb_type.compare("qfep") == 0)
    {
        return LBPolicyType::LB_QFEP;
    }
    else if (lb_type.compare("pod") == 0)
    {
        return LBPolicyType::LB_POD;
    }
    
    assert (false);
}

string get_policy_type_str(LBPolicyType lb_type)
{
    if (lb_type == LBPolicyType::LB_RAND)
    {
        return "rand";
    }
    else if (lb_type == LBPolicyType::LB_RR)
    {
        return "rr";
    }
    else if (lb_type == LBPolicyType::LB_QFE)
    {
        return "qfe";
    }
    else if (lb_type == LBPolicyType::LB_QBE)
    {
        return "qbe";
    }
    else if (lb_type == LBPolicyType::LB_JIQ)
    {
        return "jiq";
    }
    else if (lb_type == LBPolicyType::LB_QFEP)
    {
        return "qfep";
    }
    else if (lb_type == LBPolicyType::LB_POD)
    {
        return "qfep";
    }
    
    assert (false);
}
