#ifndef QUEUING_THEORY_H
#define QUEUING_THEORY_H

double percentile_wait_time_mdn( int num_servers,
                                 double mean_arrival_rate,
                                 double mean_service_time,
                                 double percentile );

double percentile_wait_time_mmn( int num_servers,
                                 double mean_arrival_rate,
                                 double mean_service_time,
                                 double percentile );

double erlang_c( int num_servers,
                 double mean_arrival_rate,
                 double mean_service_time );

double erlang_c( int num_servers,
                 double traffic_intensity );


double prob_rt_leq_x( int num_servers,
                      double mean_arrival_rate,
                      double mean_service_time,
                      double x );
double prob_rt_gt_x( int num_servers,
                     double mean_arrival_rate,
                     double mean_service_time,
                     double x );
double p_0(int num_servers, double traffic_intensity);

double power_by_factorial(double p, int n);
double log_factorial(int n);

#endif
