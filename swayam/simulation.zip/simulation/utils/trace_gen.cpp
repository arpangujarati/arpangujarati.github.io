#include "trace_gen.h"
#include "chrono.h"

#include <assert.h> // assert
#include <string.h> // strtok
#include <fstream>  // ifstream
#include <sstream>  // stringstream
#include <string>   // string
#include <random>   // exponential_distribution
#include <string>   // stod, stoi
#include <numeric>  // accumulate

TimeUs avg_exe_time_us = 0 * 1000;
unsigned int num_reqs = 1;
double reqs_per_us = 1 / 1000.0;
string trace_dir = "";
vector<float> multipliers;

TraceType get_dummy_trace(Category *logger)
{
    INFO << "Generating a dummy trace";

    TraceType trace;
    for (unsigned int i = 0; i < NUM_REQS_FOR_SYN_WG; i++)
    {
        trace.push_back(TraceEntryType(0, i, 0, 0));
    }

    return trace;
}

TraceType get_poisson_trace(Category *logger)
{
    return get_poisson_trace(logger, num_reqs, reqs_per_us);
}

TraceType get_poisson_trace(Category *logger, unsigned int num_reqs, double reqs_per_us)
{
    INFO << "Generating a poisson trace";
    INFO << "#Requests " << num_reqs;
    INFO << "Rate " << reqs_per_us << " requests/us";

    default_random_engine g1 (CHRONO_SEED);
    default_random_engine g2 (CHRONO_SEED);

    INFO << "Request rate = " << reqs_per_us << "rpus";
    exponential_distribution<double> d1(reqs_per_us);

    INFO << "Average execution time = " << avg_exe_time_us << "us";
    exponential_distribution<double> d2(1.0 / avg_exe_time_us);

    //INFO << "Average execution time = 128038.258925 us";
    //lognormal_distribution<double> d2(10.3604412144, 2.07443970373);

    TraceType trace;
    for (unsigned int i = 0; i < num_reqs; i++)
    {
        TimeUs inter_arrival_time_us = d1(g1);
        TimeUs exe_time_us = d2(g2);

        if (exe_time_us == 0)
            exe_time_us = 1;

        INFO << "generated inter-arrival time = " << inter_arrival_time_us << "us";
        INFO << "generated execution time = " << exe_time_us << "us";

        trace.push_back(TraceEntryType(inter_arrival_time_us, exe_time_us));
    }

    return trace;
}

TraceType get_uniform_trace(Category *logger)
{
    return get_uniform_trace(logger, num_reqs, reqs_per_us);
}

TraceType get_uniform_trace(Category *logger, unsigned int num_reqs, double reqs_per_us)
{
    INFO << "Generating a uniform trace";
    INFO << "#Requests " << num_reqs;
    INFO << "Rate " << reqs_per_us << " requests/us";

    TimeUs inter_arrival_time_us = 1.0 / reqs_per_us;

    //default_random_engine g (CHRONO_SEED);
    //poisson_distribution<int> d(avg_exe_time_us);

    TraceType trace;
    for (unsigned int i = 0; i < num_reqs; i++)
    {
        trace.push_back(TraceEntryType(inter_arrival_time_us, avg_exe_time_us));
    }

    return trace;
}

TraceType get_poisson_step_trace(Category *logger)
{
    INFO << "Generating a poisson-step trace";
    INFO << "#Requests (base step) " << num_reqs;
    INFO << "Rate (base step) " << reqs_per_us << " requests/us";

    TraceType step_trace;
    float multiplier = 1;
    for (unsigned int i = 0; i < multipliers.size(); i++)
    {
        multiplier *= multipliers[i];
        INFO << "multiplier " << multiplier;
        TraceType trace = get_poisson_trace( logger, num_reqs * multiplier,
                                             reqs_per_us * multiplier );
        step_trace.insert(step_trace.end(), trace.begin(), trace.end());
    }

    INFO << "First request inside get_poisson_step_trace: "
         << step_trace[0].str();
    return step_trace;
}

TraceType get_uniform_step_trace(Category *logger)
{
    INFO << "Generating a uniform-step trace";
    INFO << "#Requests (base step) " << num_reqs;
    INFO << "Rate (base step) " << reqs_per_us << " requests/us";

    TraceType step_trace;
    float multiplier = 1;
    for (unsigned int i = 0; i < multipliers.size(); i++)
    {
        multiplier *= multipliers[i];
        INFO << "multiplier " << multiplier;
        TraceType trace = get_uniform_trace( logger, num_reqs * multiplier,
                                             reqs_per_us * multiplier );
        step_trace.insert(step_trace.end(), trace.begin(), trace.end());
    }

    return step_trace;
}

TraceType get_production_trace(Category *logger, string setup_file)
{
    INFO << "Generating production trace";
    TraceType trace;
    string arrivals_txt = trace_dir + "/arrivals.txt";
    string servicetimes_txt = trace_dir + "/servicetimes.txt";

    ifstream myfile;

    myfile.open(servicetimes_txt);
    if (!myfile.is_open())
    {
        ERROR << "Failed to open file \"" << servicetimes_txt << "\"";
        return trace;
    }

    string line;

    if (getline(myfile, line))
    {
        avg_exe_time_us = stod(line) * 1000;
        INFO << "Mean service time is " << avg_exe_time_us << " us";
    }
    else
    {
        ERROR << "Failed to get mean service time from file \""
              << servicetimes_txt << "\"";
        return trace;
    }

    if (getline(myfile, line))
    {
        TimeUs time_us = (stod(line) * 1000) - avg_exe_time_us;
        INFO << "Mean setup time is " << time_us << " ms";
        write_setup_time_to_file(logger, 0, time_us, setup_file);
    }
    else
    {
        ERROR << "Failed to get mean setup time from file \""
              << servicetimes_txt << "\"";
        return trace;
    }

    myfile.close();

    myfile.open(arrivals_txt);
    if (!myfile.is_open())
    {
        ERROR << "Failed to open file \"" << arrivals_txt << "\"";
        return trace;
    }

    getline(myfile, line);
    TimePointTypeSys prev_tp = parse_time_point_from_string(line, logger);
    trace.push_back(TraceEntryType(0, avg_exe_time_us));

    while (getline(myfile, line))
    {
        TimePointTypeSys tp = parse_time_point_from_string(line, logger);
        TimeUs diff = CHRONO_DURATION_US(tp - prev_tp).count();
        trace.push_back(TraceEntryType(diff, avg_exe_time_us));
        prev_tp = tp;
    }

    myfile.close();

    return trace;
}

TraceType get_new_production_trace(Category *logger, string setup_file)
{
    INFO << "Generating new-production trace";
    TraceType trace;
    string arrivals_txt = trace_dir + "/arrivals.txt";
    string servicetimes_txt = trace_dir + "/servicetimes.txt";

    ifstream myfile;

    myfile.open(servicetimes_txt);
    if (!myfile.is_open())
    {
        ERROR << "Failed to open file \"" << servicetimes_txt << "\"";
        return trace;
    }

    string line;
    vector<TimeUs> service_times_us;

    while(getline(myfile, line))
    {
        service_times_us.push_back(stoull(line) * 1000);    
    }

    myfile.close();

    double sum_service_times = accumulate( service_times_us.begin(),
                                           service_times_us.end(), 0.0 );
    double mean_service_time_us = sum_service_times / service_times_us.size();
    double setup_time_us = mean_service_time_us * 10;
    write_setup_time_to_file(logger, 0, setup_time_us, setup_file);

    myfile.open(arrivals_txt);
    if (!myfile.is_open())
    {
        ERROR << "Failed to open file \"" << arrivals_txt << "\"";
        return trace;
    }

    getline(myfile, line);
    TimePointTypeSys prev_tp = parse_time_point_from_string(line, logger);
    trace.push_back(TraceEntryType(0, avg_exe_time_us));

    int index = 0; // for service times

    while (getline(myfile, line))
    {
        TimePointTypeSys tp = parse_time_point_from_string(line, logger);
        TimeUs diff = CHRONO_DURATION_US(tp - prev_tp).count();
        trace.push_back(TraceEntryType(diff, service_times_us[index++]));
        prev_tp = tp;
    }

    myfile.close();

    return trace;
}

void write_setup_time_to_file( Category *logger, int sid, TimeUs setup_time_us,
                               string filename )
{
    ofstream myfile;
    INFO << "Opening setup_file " << filename;
    myfile.open(filename);
    myfile << sid << " " << setup_time_us << " " << avg_exe_time_us << "\n";
    INFO << "Closing setup_file " << filename;
    myfile.close();
}

TraceType get_trace(Category *logger, string config_dir, int argc, char **argv)
{
    string wt_type = argv[0];
    TimeUs avg_setup_time_us;

    if (argc == 2)
    {
        trace_dir = argv[1];
    }

    if (argc == 5 or argc == 6)
    {
        num_reqs = stoi(argv[1]);
        avg_exe_time_us = stod(argv[2]);
        avg_setup_time_us = stod(argv[3]);
        reqs_per_us = stod(argv[4]);
    }

    if (argc == 6)
    {
        string step_seq = argv[5];
        std::string delimiter = "-";
        size_t pos = 0;
        string token;
        while ((pos = step_seq.find(delimiter)) != string::npos)
        {
            token = step_seq.substr(0, pos);
            multipliers.push_back(stod(token));
            step_seq.erase(0, pos + delimiter.length());
            INFO << step_seq;
        }
        multipliers.push_back(stod(step_seq));
    }
        
    string setup_file = config_dir + "setup_times.txt";

    if (wt_type.compare("production") == 0)
        return get_production_trace(logger, setup_file);

    if (wt_type.compare("new-production") == 0)
        return get_new_production_trace(logger, setup_file);

    write_setup_time_to_file(logger, 0, avg_setup_time_us, setup_file);

    if (wt_type.compare("dummy") == 0)
        return get_dummy_trace(logger);
    
    if (wt_type.compare("poisson") == 0)
        return get_poisson_trace(logger);

    if (wt_type.compare("uniform") == 0)
        return get_uniform_trace(logger);

    if (wt_type.compare("poisson-step") == 0)
        return get_poisson_step_trace(logger);

    if (wt_type.compare("uniform-step") == 0)
        return get_uniform_step_trace(logger);

    ERROR << "Workload Generator type " << wt_type << " not available";

    TraceType empty_trace;
    return empty_trace;
}

void write_to_file(Category *logger, TraceType& trace, string filename)
{
    INFO << "First request inside write_to_file: " << trace[0].str();

    ofstream myfile;
    myfile.open(filename);
    unsigned int msg_counter = 1;
    TimeUs arrival_us = 0;

    for (TraceType::iterator it = trace.begin(); it != trace.end(); ++it)
    {
        TraceEntryType& te = (*it);
        arrival_us += te.inter_arrival_time_us;
        myfile << arrival_us << " " << 0 << " " << (msg_counter++) << " "
               << te.exe_time_us << "\n";
    }

    myfile.close();
}
