#include "chrono.h"

TimePointTypeSys parse_time_point_from_string(string tp_str, Category *logger)
{
    const char *tp_c_str = tp_str.c_str();

    // the string is parsed as %Y-%m-%d %H:%M:%S
    // where seconds can be a float to cature ms or us
    // acccuracy as well

    tm time_tm; // time struct
    strptime(tp_c_str, "%Y-%m-%d %H:%M:%S", &time_tm);
    TimePointTypeSys tp = chrono::system_clock::from_time_t(mktime(&time_tm));

    int year, month, day, hour, min, usecs;
    float secs_float;

    sscanf( tp_c_str, "%d-%d-%d %d:%d:%f",
            &year, &month, &day, &hour, &min, &secs_float );

    usecs = (secs_float - ((int)secs_float)) * 1000000;
    Duration_us d(usecs);
    tp = tp + d;

    return tp;
}

TimeUs get_elapsed_time_us()
{
    TimePointType now = CHRONO_NOW;
    auto elapsed = now.time_since_epoch();
    return CHRONO_DURATION_US(elapsed).count();
}

TimeUs get_elapsed_time_us(TimePointType start_time)
{
    auto elapsed = CHRONO_NOW - start_time;
    return CHRONO_DURATION_US(elapsed).count();
}

void spin_for_us(TimeUs duration_us, Category *logger)
{
    TimePointType start_time = CHRONO_NOW;
    TimeUs elapsed_us = get_elapsed_time_us(start_time);

    while(elapsed_us < duration_us)
    {
        elapsed_us = get_elapsed_time_us(start_time);
    }
}
