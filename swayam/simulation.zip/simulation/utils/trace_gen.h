#ifndef TRACE_GENERATOR_H
#define TRACE_GENERATOR_H

#define NUM_REQS_FOR_SYN_WG 100

#include "basics.h"
#include "logging.h"
#include "trace_entry_type.h"

TraceType get_trace(Category *logger, string config_file, int argc, char **argv);

TraceType get_production_trace(Category *logger, string config_file);
TraceType get_new_production_trace(Category *logger, string config_file);

TraceType get_dummy_trace(Category *logger);
TraceType get_poisson_trace(Category *logger);
TraceType get_uniform_trace(Category *logger);
TraceType get_poisson_step_trace(Category *logger);
TraceType get_uniform_step_trace(Category *logger);

TraceType get_poisson_trace(Category *logger, unsigned int num_reqs, double reqs_per_us);
TraceType get_uniform_trace(Category *logger, unsigned int num_reqs, double reqs_per_us);

void write_setup_time_to_file( Category *logger, int sid, TimeUs setup_time_us,
                               string filename );

void write_to_file(Category *logger, TraceType& trace, string filename);

#endif
