#ifndef FILE_IO_SIM_H
#define FILE_IO_SIM_H

#include "basics.h"

#include <vector>
#include <map>

class ServiceInfoType
{
  public:
    unsigned int sid = 0;
    TimeUs setup_time_us;
    TimeUs exe_time_us;
    double logn_s_us;
    double logn_loc_us;
    double logn_scale_us;

    ServiceInfoType() : sid(0), setup_time_us(0) {}

    bool operator<( const ServiceInfoType& other) const
    {
        return sid < other.sid;   
    }
};

typedef map<unsigned int, ServiceInfoType *> ServicesInfoMap;

bool get_add_strs_from_file(string filename, vector<string>& adds);

bool get_all_add_strs_from_file( string add_dir,
                                 vector<string>& cl_adds, 
                                 vector<string>& br_adds, 
                                 vector<string>& fe_adds, 
                                 vector<string>& be_adds );

bool get_all_services_from_file( string config_dir,
                                 map<int, TimeUs>& setup_times,
                                 map<int, TimeUs>& exe_times );

bool get_services_from_file(string config_dir, ServicesInfoMap& services);

#endif
