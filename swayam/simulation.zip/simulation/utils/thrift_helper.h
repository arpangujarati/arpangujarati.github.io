#ifndef UTILS_THRIFT_HELPER_H
#define UTILS_THRIFT_HELPER_H

#include <fstream> // std::ifstream

#include "basics.h"
#include "thrift.h"
#include "logging.h"
#include "../gen-cpp/azml_types.h"

#define NAME(AddType) (AddType.host + "_" + to_string(AddType.port))
#define BR_NAME(AddType) ("br_" + AddType.host + "_" + to_string(AddType.port))
#define FE_NAME(AddType) ("fe_" + AddType.host + "_" + to_string(AddType.port))
#define BE_NAME(AddType) ("be_" + AddType.host + "_" + to_string(AddType.port))
#define CL_NAME(AddType) ("cl_" + AddType.host + "_" + to_string(AddType.port))
#define WG_NAME(AddType) ("wg_" + AddType.host + "_" + to_string(AddType.port))
#define BS_NAME(AddType) ("bs_" + AddType.host + "_" + to_string(AddType.port))

#define WG2CL_query_msg  MessageType::WG2CL_query 
#define CL2BR_query_msg  MessageType::CL2BR_query 
#define BR2FE_query_msg  MessageType::BR2FE_query 
#define BR2CL_result_msg MessageType::BR2CL_result
#define FE2BE_query_msg  MessageType::FE2BE_query 
#define FE2BR_result_msg MessageType::FE2BR_result
#define BE2FE_result_msg MessageType::BE2FE_result
#define BE2FE_busy_msg   MessageType::BE2FE_busy  
#define DUMMY_type_msg   MessageType::DUMMY_type  

string MessageTypeStr(MessageType::type t);

bool compare_AddType(const AddType& add1, const AddType& add2);

void convert_AddType_to_str(const AddType& add, string& str);
bool convert_str_to_AddType(string str, AddType& add);

bool get_adds_from_file(string filename, vector<AddType>& adds);
bool get_all_adds_from_file( string add_dir,
                             vector<AddType>& cl_adds,
                             vector<AddType>& br_adds,
                             vector<AddType>& fe_adds,
                             vector<AddType>& be_adds );

Message* get_new_msg(MessageType::type mtype, AddType sender);
Message* get_new_msg( const Message& old_msg, MessageType::type mtype,
                      AddType sender);

string msg2str(AddType my_add, TimeUs time, const Message& msg);
string msg2str(TimeUs time, const Message& msg);

template<typename ClientType>
void send_msg(Message* msg, AddType receiver, Category *logger)
{
    auto sock  = MAKE_SHARED<TSocket>(receiver.host, receiver.port);
    auto tport = MAKE_SHARED<TFramedTransport>(sock);
    auto proto = MAKE_SHARED<TBinaryProtocol>(tport);

    try
    {
        ClientType client(proto);
        tport->open();
        client.execute(*msg);
        tport->close();
    }
    catch (const exception& e)
    {
        INFO << msg->mtype << " Sending msg " << msg->rid
             << " failed with exception \"" << e.what() << "\"";
    }

    delete msg;
}

template<typename ClientType>
void send_msg(Message* msg, string receiver_str, Category *logger)
{
    AddType receiver;
    convert_str_to_AddType(receiver_str, receiver);

    auto sock  = MAKE_SHARED<TSocket>(receiver.host, receiver.port);
    auto tport = MAKE_SHARED<TFramedTransport>(sock);
    auto proto = MAKE_SHARED<TBinaryProtocol>(tport);

    try
    {
        ClientType client(proto);
        tport->open();
        client.execute(*msg);
        tport->close();
    }
    catch (const exception& e)
    {
        INFO << msg->mtype << " Sending msg " << msg->rid
             << " failed with exception \"" << e.what() << "\"";
    }

    delete msg;
}

#endif
