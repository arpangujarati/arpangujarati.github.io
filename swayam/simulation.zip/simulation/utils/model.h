#ifndef UTILS_MODEL_H
#define UTILS_MODEL_H

#include "basics.h"
#include "logging.h"
#include "file_io_sim.h"

double get_perc_wt( Category *logger, double rate, unsigned int num_bes,
                    double perc, TimeUs d1, TimeUs d2, TimeUs delta,
                    ServiceInfoType *service_info );

double get_cdf_rt( Category *logger, double rate, unsigned int num_bes,
                   TimeUs resp_time, TimeUs d1, TimeUs d2,
                   TimeUs delta, ServiceInfoType *service_info );

double get_perc_rt( Category *logger, double rate, unsigned int num_bes,
                    double perc, TimeUs d1, TimeUs d2, TimeUs delta,
                    ServiceInfoType *service_info );

#endif
