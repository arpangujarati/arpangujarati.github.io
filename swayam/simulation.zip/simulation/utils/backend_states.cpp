#include "basics.h"
#include "backend_states.h"

#include <assert.h>

string StateTypeStr(StateType type)
{
    switch (type)
    {
        case StateType::BUSY:
            return "BUSY";
        case StateType::COLD:
            return "COLD";
        case StateType::WARM:
            return "WARM";
        default:
            assert (false);
    }
}
