#ifndef CLOCK_H
#define CLOCK_H

#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

typedef high_resolution_clock MyClock;

template <typename C>
void print_clock_data();

void print_all_clock_data();

double get_curr_time_ns();
double get_duration_ns(double start_time);

#endif
