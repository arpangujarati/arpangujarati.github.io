#include "model.h"

#include <math.h> // log
#include <exception>
#include <boost/math/distributions/lognormal.hpp> // lognormal

double get_perc_wt( Category *logger, double rate, unsigned int num_bes,
                    double perc, TimeUs d1, TimeUs d2, TimeUs delta,
                    ServiceInfoType *st_info )
{
    double u = (st_info->exe_time_us * rate) / num_bes;
    double pc = perc / 100.0;

    if ((1 - pc) > u)
    {
        //INFO << "Returning 0 since pc = " << pc << ", u = " << u
        //     << ", and (1 - pc) > u";
        return 0;
    }

    double  wait_time_us = (log(1 - pc) / log(u)) - 1.0;
    wait_time_us *= (d1 + d2 + delta);
    wait_time_us += d1;

    return wait_time_us;
}

double get_cdf_rt( Category *logger, double rate, unsigned int num_bes,
                   TimeUs resp_time, TimeUs d1, TimeUs d2, TimeUs delta,
                   ServiceInfoType *st_info )
{
    double s = st_info->logn_s_us;
    double loc = st_info->logn_loc_us;
    double scale = st_info->logn_scale_us;

    double sigma = s;
    double mu = log(scale);

    boost::math::lognormal_distribution<> distr(mu, sigma);

    double prob_busy = (st_info->exe_time_us * rate) / num_bes;
    double prob_idle = 1 - prob_busy;

    unsigned int max_retries = (resp_time - d1) /
                               (d1 + d2 + delta);

    double cdf_val = 0;

    for ( unsigned int num_retries = 0; num_retries <= max_retries;
          num_retries++ )
    {
        //INFO << "num_retries " << num_retries;

        double wait_time = num_retries;
        wait_time *= d1 + d2 + delta;
        wait_time += d1;

        //assert (wait_time < resp_time);

        double prob_wait_time = pow(prob_busy, num_retries) * prob_idle;
        double x = resp_time - wait_time - loc;

        if (x < 0)
        {
            break;
        }
        
        double prob_service_time = boost::math::cdf(distr, x);

        cdf_val += prob_wait_time * prob_service_time;
    }

    return cdf_val;
}

double get_perc_rt( Category *logger, double rate, unsigned int num_bes,
                    double perc, TimeUs d1, TimeUs d2, TimeUs delta,
                    ServiceInfoType *st_info)
{
    TimeUs rt_us = get_perc_wt( logger, rate, num_bes, perc, d1, d2, delta,
                                st_info );
    double cdf = 0.0;
    double pc = perc / 100.0;

    while (cdf < pc)
    {
        cdf = get_cdf_rt ( logger, rate, num_bes, rt_us, d1, d2, delta,
                           st_info );
        rt_us += 1000;
    }

   rt_us -= 1000;
   return rt_us;
}
