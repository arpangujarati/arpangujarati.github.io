// TestLog4CPP.cpp : A small exerciser for log4cpp

#include    "log4cpp/Category.hh"
#include    "log4cpp/FileAppender.hh"
#include    "log4cpp/BasicLayout.hh"

int main(int argc, char* argv[])
{
    // Instantiate an appender object that will append to a log file.
    log4cpp::Appender* app = new log4cpp::FileAppender( "FileAppender",
                                                        "testlog4cpp.log" );

    // Instantiate a layout object. Two layouts come already available in
    // log4cpp unless you create your own. BasicLayout includes a time stamp,
    // and logs messages as follows: "datetime PRIORITY category_name : msg".
    log4cpp::Layout* layout = new log4cpp::BasicLayout();

    // Attach the layout object to the appender object.
    app->setLayout(layout);

    // Instantiate the category object. You may extract the root category, but
    // it is usually more practical to directly instantiate a child category.
    log4cpp::Category& main_cat = log4cpp::Category::getInstance("main_cat");

    // An Appender when added to a category becomes an additional output
    // destination unless Additivity is set to false. When it is false, the
    // appender replaces all previously existing appenders.
    main_cat.setAdditivity(false);

    // This appender becomes the only one because Additivity was set to false.
    main_cat.setAppender(app);

    // Set up the priority for the category. Since it is given INFO priority,
    // attempts to log DEBUG messages will fail.
    main_cat.setPriority(log4cpp::Priority::INFO);

    // Examples
    main_cat.info("This is some info");
    main_cat.debug("This debug message will fail to write");
    main_cat.alert("All hands abandon ship");

    // You can also log by using a log() method with a priority.
    main_cat.log(log4cpp::Priority::WARN, "This will be a logged warning");

    // You can also have programmatic control over the priority levels.
    log4cpp::Priority::PriorityLevel priority;
    bool this_is_critical = true;
    if(this_is_critical)
        priority = log4cpp::Priority::CRIT;
    else
        priority = log4cpp::Priority::DEBUG;

    // This would not be logged if priority == DEBUG, since that category
    // priority is set to INFO, and DEBUG < INFO < ... < FATAL.
    main_cat.log(priority,"Importance depends on context");
    
    // You may also log by using stream style operations.
    main_cat.critStream() << "This will show up as " << 1 << " critical message";
    main_cat.emergStream() << "This will show up as " << 1 << " emergency message";

    // Stream operations can be used directly with the main category object,
    // but must be preceded by the severity level, as shown below.
    main_cat << log4cpp::Priority::ERROR << "And this will be an error";

    // This will be skipped, guess why!?
    main_cat.debug("debug");

    // All of these will be logged.
    main_cat.info("info");
    main_cat.notice("notice");
    main_cat.warn("warn");
    main_cat.error("error");
    main_cat.crit("crit");
    main_cat.alert("alert");
    main_cat.emerg("emerg");

    // This will be skipped
    main_cat.debug("Shutting down");

    // clean up and flush all appenders
    log4cpp::Category::shutdown();

    return 0;
}
