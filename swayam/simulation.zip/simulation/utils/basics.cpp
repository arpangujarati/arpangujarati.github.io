#include "basics.h"
#include "logging.h"

void sig_handler(int x)
{
    extern Category *logger;

    if (logger == NULL)    
    {
        cerr << "Error: logger is NULL, server exiting\n" << flush;
    }
    else
    {
        INFO << "Server exiting\n";
    }

    Category::shutdown();

    exit(0);
}

TimeUs sec2us(TimeUs x)
{
    return x * 1000 * 1000;
}
