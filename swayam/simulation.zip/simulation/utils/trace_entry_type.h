#ifndef TRACE_ENTRY_TYPE_H
#define TRACE_ENTRY_TYPE_H

#include "basics.h"
#include <vector>

class TraceEntryType
{
  public:
    int sid;
    int uid;
    TimeUs arrival_us;
    TimeUs inter_arrival_time_us;
    TimeUs exe_time_us;

    /*TraceEntryType ( TimeUs inter_arrival_time_us, TimeUs exe_time_us )
                     : sid(-1), uid(-1), arrival_us(0),
                       inter_arrival_time_us(inter_arrival_time_us),
                       exe_time_us(exe_time_us) {}*/

    /*TraceEntryType ( int sid, int uid, TimeUs arrival_us, TimeUs exe_time_us )
                     : sid(sid), uid(uid), arrival_us(arrival_us),
                       inter_arrival_time_us(0), exe_time_us(exe_time_us) {}*/

    TraceEntryType ( int sid, int uid, TimeUs arrival_us,
                     TimeUs inter_arrival_time_us, TimeUs exe_time_us )
                     : sid(sid), uid(uid), arrival_us(arrival_us),
                       inter_arrival_time_us(inter_arrival_time_us),
                       exe_time_us(exe_time_us) {}
    string str()
    {
        return "(arrival_us=" + to_string(arrival_us) +
               ", inter_arrival_time_us=" + to_string(inter_arrival_time_us) +
               ", sid=" + to_string(sid) +
               ", uid= " + to_string(uid) +
               ", exe_time_us=" + to_string(exe_time_us) + ")";
    }
};

typedef vector<TraceEntryType> TraceType;

#endif
