#ifndef LOCAL_STORE_H
#define LOCAL_STORE_H

#include "misc.h"

#include "log4cpp/Category.hh"

#include <sstream>  // stringstream
#include <vector>   // vector
#include <utility>  // pair, make_pair
#include <assert.h> // assert

typedef pair<int, int> LocalStoreEntry;
typedef vector<LocalStoreEntry> LocalStoreType;

class LocalStore // Version 3
{
  private:
    int num_bins;
    int bin_size;
    int store_size;
    LocalStoreType store;
    Category *logger;

  public:
    LocalStore() {}

    /*LocalStore(int num_bins, int bin_size)
               : num_bins(num_bins), bin_size(bin_size) 
    {
        for (int i = 0; i < num_quanta; i++)
            store.push_back(make_pair(0, 0));
    }*/

    ~LocalStore() {}

    bool init(int num_bins, int bin_size, Category *logger)
    {
        this->logger = logger;
        this->num_bins = num_bins;
        this->bin_size = bin_size;
        this->store_size = num_bins * bin_size;
        for (int i = 0; i < num_bins; i++)
            store.push_back(make_pair(0, 0));
        return true;
    }

    LocalStoreType& get_store()
    {
        return store;
    }

    void update(int time)
    {
        int store_start = (time / store_size) * store_size;
        int bin_start = (time / bin_size) * bin_size;
        int index = (time - store_start) / bin_size;

        // TODO test this if block
        if (store[index].first > bin_start)
        {
            return;
        }

        if (store[index].first < bin_start)
        {
             //assert(store[index].first < bin_start);
             store[index] = make_pair(bin_start, 0);
        }

        store[index].second++;
    }

    static void dump_local_store( LocalStoreType& store,
                                  Category *logger,
                                  string msg = "" )
    {
        string logmsg = "LocalStore";
        if (!msg.empty())
            logmsg += " " + msg;
        for (unsigned int i = 0; i < store.size(); i++)
            logmsg += " (" + to_string(store[i].first) +
                      ", " + to_string(store[i].second) + ")";
        INFO << logmsg;
    }
};

/*
typedef vector<TimeUs> LocalStoreType;

class LocalStore // Version 2
{
  private:
    LocalStoreType store;
    int index;
    int capacity;
    Category *logger;

  public:
    LocalStore() {}

    bool init(unsigned int capacity, Category *logger)
    {
        INFO << "Init LocalStore with capacity " << capacity;

        this->capacity = capacity;
        this->logger = logger;
        for (unsigned int i = 0; i < capacity; i++)
            store.push_back(0);
        this->index = 0;

        return true;
    }

    void update(TimeUs time)
    {
        store[index] = time;
        index = (index + 1) % capacity;
    }

    LocalStoreType& get_store()
    {
        return store;
    }

    static void dump_local_store( LocalStoreType& store,
                                  Category *logger,
                                  string msg = "" )
    {
        string logmsg = "LocalStore";
        if (!msg.empty())
            logmsg += " " + msg;
        logmsg += ":";
        for (unsigned int i = 0; i < store.size(); i++)
            logmsg += " " + to_string(store[i]);
        INFO << logmsg;
    }
};*/

/*
typedef pair<unsigned int, unsigned int> LocalStoreEntry;
typedef vector<LocalStoreEntry> LocalStoreType;

class LocalStore // Version 1
{
  private:
    unsigned int quantum_size;
    unsigned int window_size;
    LocalStoreType store;
    Category *logger;

  public:
    LocalStore() {}

    LocalStore( unsigned int num_quanta,
                unsigned int quantum_size )
                : quantum_size(quantum_size),
                  window_size(num_quanta * quantum_size)
    {
        for (unsigned int i = 0; i < num_quanta; i++)
            store.push_back(make_pair(0, 0));
    }

    ~LocalStore() {}

    bool init( unsigned int num_quanta,
               unsigned int quantum_size,
               Category *logger )
    {
        this->logger = logger;
        this->quantum_size = quantum_size;
        this->window_size = num_quanta * quantum_size;
        for (unsigned int i = 0; i < num_quanta; i++)
            store.push_back(make_pair(0, 0));
        return true;
    }

    LocalStoreType& get_store()
    {
        return store;
    }

    void update(unsigned int time)
    {
        string dump_str = "before update, time = " + to_string(time);
        dump_local_store(store, logger, dump_str);
        unsigned int window_start_time = (time / window_size) * window_size;
        unsigned int quantum_start_time = (time / quantum_size) * quantum_size;
        unsigned int index = (time - window_start_time) / quantum_size;

        if (store[index].first != quantum_start_time)
        {
             assert(store[index].first < quantum_start_time);
             store[index] = make_pair(quantum_start_time, 0);
        }

        store[index].second++;
        dump_local_store(store, logger, "after update");
    }

    static void dump_local_store( LocalStoreType& store,
                                  Category *logger,
                                  string msg = "" )
    {
        string logmsg = "LocalStore";
        if (!msg.empty())
            logmsg += ":" + msg;
        for (unsigned int i = 0; i < store.size(); i++)
            logmsg += "::" + to_string(store[i].first) + ":" +
                      to_string(store[i].second);
        DEBUG << logmsg;
    }
};*/

#endif
