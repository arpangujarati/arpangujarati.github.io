#ifndef UTILS_BASELINE_SIM_H
#define UTILS_BASELINE_SIM_H

#include <queue>

#include "../utils/misc.h"

typedef unsigned long long TimeType;

class ArrivalQRequest
{
  private:
    int rid;
    TimeType arrival_time_us;
    TimeType exe_time_us;
    TimeType wait_deadline_us;

  public:
    ArrivalQRequest() {}

    ArrivalQRequest( int rid, TimeType arrival_time_us, TimeType exe_time_us )
                     : rid(rid), arrival_time_us(arrival_time_us),
                       exe_time_us(exe_time_us), wait_deadline_us(0) {}

    int get_rid() const { return rid; }
    TimeType get_arrival_time_us() const { return arrival_time_us; }
    TimeType get_exe_time_us() const { return exe_time_us; }
    TimeType get_wait_deadline_us() const { return wait_deadline_us; }
    void set_wait_deadline_us(TimeType d) { wait_deadline_us = d; }

    string str() const
    {
        return "Request (rid = " + to_string(rid) + ", " + 
               "arrival = " + to_string(arrival_time_us) +  "us, " +
               "exe = " + to_string(exe_time_us) + "us, " +
               "deadline = " + to_string(wait_deadline_us) + "us)";
    }

    bool operator<(const ArrivalQRequest& other) const
    {
        return arrival_time_us > other.arrival_time_us;
    }
};

class ReadyQRequest: public ArrivalQRequest
{
  public:
    ReadyQRequest() {}

    ReadyQRequest(const ArrivalQRequest &obj) : ArrivalQRequest(obj) {}

    bool operator<(const ReadyQRequest& other) const
    {
        return get_wait_deadline_us() > other.get_wait_deadline_us();
    }
};

class SimpleBackend
{
  private:
    AddType my_add;
    Category *logger;
    bool idle;
    TimeType curr_req_end_time_us;
    ReadyQRequest curr_req;
    TimeType setup_time_us;

  public:
    SimpleBackend( AddType my_add, Category *logger, TimeType curr_time_us,
                   TimeType setup_time_us )
                   : my_add(my_add), logger(logger), idle(true),
                     setup_time_us(setup_time_us)
    {
        if (curr_time_us >= setup_time_us)
        {
            INFO << "STATS_BE_STATE " << curr_time_us - setup_time_us
                 << " " << BE_NAME(my_add) << " BUSY";
        }
        else
        {
            INFO << "STATS_BE_STATE " << curr_time_us
                 << " " << BE_NAME(my_add) << " BUSY";
        }
        INFO << "STATS_BE_STATE " << curr_time_us
             << " " << BE_NAME(my_add) << " BUSY";
    }

    bool is_idle() { return idle; }

    void schedule(TimeType curr_time_us, ReadyQRequest r)
    {
        assert(idle == true);
        idle = false;
        curr_req = r;
        curr_req_end_time_us = r.get_exe_time_us() + curr_time_us;

        INFO << "STATS_WAITING_TIME " << curr_req.get_arrival_time_us()
             << " " << curr_time_us - curr_req.get_arrival_time_us();
    }

    void update(TimeType curr_time_us)
    {
        if (!idle && curr_time_us >= curr_req_end_time_us)
        {
            INFO << "STATS_RESPONSE_TIME " << curr_req.get_arrival_time_us()
                 << " " << curr_time_us - curr_req.get_arrival_time_us();
            idle = true;
        }
    }
};

class BaselineSimulator
{
  private:
    Category *logger;

    priority_queue<ArrivalQRequest> arrivalq;
    priority_queue<ReadyQRequest> readyq;
    priority_queue < TimeType, vector<TimeType>, greater<TimeType> >  pendingq;

    vector<AddType> be_adds;
    vector<SimpleBackend> backends;

    TimeType curr_time_us;
    TimeType setup_time_us;

    TimeType sla_max_wait_time_us;

    void schedule()
    {
        while (!arrivalq.empty())
        {
            if (arrivalq.top().get_arrival_time_us() > curr_time_us)
                break;

            readyq.push(ReadyQRequest(arrivalq.top()));
            arrivalq.pop();
        }

        for ( vector<SimpleBackend>::iterator it = backends.begin();
              it != backends.end(); )
        {
            SimpleBackend& be = (*it);
            be.update(curr_time_us);
            if (!be.is_idle())
            {
                ++it;
            }
            else if (be.is_idle() && !readyq.empty())
            {
                be.schedule(curr_time_us, readyq.top());
                pendingq.push(curr_time_us + readyq.top().get_exe_time_us());
                readyq.pop();
                ++it;
            }
            else if (be.is_idle() && readyq.empty())
            {
                ++it;
                //it = backends.erase(it);
                //INFO << "STATS_DESIRED " << curr_time_us << " " << backends.size();
            }
        }

        while( !readyq.empty() &&
               curr_time_us >= readyq.top().get_wait_deadline_us() )
        {
            SimpleBackend new_be( be_adds[backends.size()], logger,
                                  curr_time_us, setup_time_us );
            new_be.schedule(curr_time_us, readyq.top());
            INFO << "STATS_DESIRED " << curr_time_us
                 << " " << backends.size();
            backends.push_back(new_be);
            INFO << "STATS_DESIRED " << curr_time_us
                 << " " << backends.size();
            pendingq.push(curr_time_us + readyq.top().get_exe_time_us());
            readyq.pop();
        }
    }

  public:
    BaselineSimulator( Category *logger, vector<AddType> be_adds,
                       TimeType setup_time_us, TimeType sla_max_wait_time_us )
                       : logger(logger), be_adds(be_adds),
                         curr_time_us(0), setup_time_us(setup_time_us),
                         sla_max_wait_time_us(sla_max_wait_time_us)
    {
        INFO << "STATS_DESIRED " << curr_time_us
             << " " << backends.size();
        backends.push_back( SimpleBackend(be_adds[0], logger,
                            curr_time_us, setup_time_us ));
        INFO << "STATS_DESIRED " << curr_time_us
             << " " << backends.size();
    }

    void add_arrival(ArrivalQRequest r)
    {
        r.set_wait_deadline_us(r.get_arrival_time_us() + sla_max_wait_time_us);

        arrivalq.push(r);
        pendingq.push(r.get_arrival_time_us());
        pendingq.push(r.get_wait_deadline_us());
    }

    void run()
    {
        while (!pendingq.empty())
        {
            TimeType sched_at_us = pendingq.top();
            pendingq.pop();
            if (sched_at_us > curr_time_us)
                curr_time_us = sched_at_us;
            INFO << "Schedule at " << curr_time_us;
            schedule();
        }

        INFO << "STATS_DESIRED " << curr_time_us << " " << backends.size();
    }
};

#endif
