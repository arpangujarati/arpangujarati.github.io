#ifndef LOAD_BALANCER_H
#define LOAD_BALANCER_H

#include "basics.h"
#include "../simulation/sim.h"

#include <mutex>
#include <queue>
#include <algorithm>    // std::random_shuffle, std::shuffle
#include <utility>      // std::pair
#include <random>       // std::default_random_engine
#include <stdlib.h>     // srand, rand
#include <time.h>       // time

enum LBPolicyType { LB_RAND, LB_RR, LB_QFE, LB_QBE, LB_JIQ, LB_QFEP, LB_POD };

LBPolicyType get_policy_type_enum(string lb_type);
string get_policy_type_str(LBPolicyType lb_type);

typedef pair<unsigned int, unsigned int> UIntPairType;

class FELoadBalancer
{
  protected:
    Category *logger;
    LBPolicyType lb_type;
    vector<string> be_adds;
    queue<SimEvent> pending_events;
    queue<string> idle_bes;
    map<string, int> be_load;
    unsigned int be_index = 0;

    unsigned int pod_size = 2;
    map<unsigned int, UIntPairType> pod_status;

  public:
    FELoadBalancer( Category *lgr, LBPolicyType typ, string my_add,
                    vector<string>& fe_adds, vector<string>& be_adds )
                    : logger(lgr), lb_type(typ), be_adds(be_adds)
    {
        INFO << "Initializing FELoadbalancer of type "
             << get_policy_type_str(lb_type);

        srand (time(NULL));

        if (lb_type == LBPolicyType::LB_QFE)
        {
            for (unsigned int i = 0; i < be_adds.size(); i++)
            {
                idle_bes.push(be_adds[i]);
            }
        }

        else if ( lb_type == LBPolicyType::LB_QFEP ||
                  lb_type == LBPolicyType::LB_JIQ )
        {
            unsigned int my_id;

            for (unsigned int i = 0; i < fe_adds.size(); i++)
            {
                if (my_add.compare(fe_adds[i]) == 0)
                {
                    my_id = i;
                }
            }

            for (unsigned int i = 0; i < be_adds.size(); i++)
            {
                if ((i % fe_adds.size()) == my_id)
                {
                    idle_bes.push(be_adds[i]);
                }
            }
        }

        else if (lb_type == LBPolicyType::LB_QBE)
        {
            for (unsigned int i = 0; i < be_adds.size(); i++)
            {
                be_load[be_adds[i]] = 0;
            }
        }

        INFO << "POD size set to " << pod_size;
    }

    void set_pod_size(unsigned int size)
    {
        assert (pod_size <= be_adds.size());
        assert (pod_size > 0);
        pod_size = size;
        INFO << "POD size reset to " << pod_size;
    }

    // interfaces for vector be_adds

    string get_random_be()
    {
        return be_adds[rand() % be_adds.size()];
    }

    string get_rr_be()
    {
        string be_add = be_adds[be_index];
        be_index = (be_index + 1) % be_adds.size();
        return be_add;
    }

    // interfaces for queue pending_events

    bool is_event_pending()
    {
        return !pending_events.empty();
    }

    SimEvent get_pending_event()
    {
        assert (!pending_events.empty());
        SimEvent event = pending_events.front();
        pending_events.pop();
        return event;
    }

    void add_pending_event(const SimEvent& event)
    {
        pending_events.push(event);
    }

    // interfaces for queue idle_bes

    bool is_be_idle()
    {
        return !idle_bes.empty();
    }

    void add_idle_be(const string& be_add)
    {
        idle_bes.push(be_add);
    }

    string get_idle_be()
    {
        assert (!idle_bes.empty());
        string be_add = idle_bes.front();
        idle_bes.pop();
        return be_add;
    }

    // interfaces for map be_load

    string get_be_with_min_load()
    {
        int index = rand() % be_adds.size();

        for (unsigned int i = 0; i < be_adds.size(); i++)
        {
            if (be_load[be_adds[i]] < be_load[be_adds[index]])
            {
                index = i;
            }
        }

        inc_be_load(be_adds[index]);
        return be_adds[index];
    }

    void inc_be_load(string be_add)
    {
        be_load[be_add]++;
    }

    void dec_be_load(string be_add)
    {
        assert(be_load[be_add] > 0);
        be_load[be_add]--;
    }

    // interfaces for power-of-d or LB_POD

    vector<string> get_d_random_bes(const SimEvent& event)
    {
        vector<string> be_adds_copy = be_adds;
        unsigned seed = chrono::system_clock::now().time_since_epoch().count();
        //random_shuffle (be_adds_copy.begin(), be_adds_copy.end());
        shuffle (be_adds_copy.begin(), be_adds_copy.end(), default_random_engine(seed));
        be_adds_copy.erase(be_adds_copy.begin() + pod_size, be_adds_copy.end());

        map<unsigned int, UIntPairType>::iterator it =
            pod_status.find(event.rid);
        assert (it == pod_status.end());
        assert (be_adds_copy.size() == pod_size);

        pod_status[event.rid] = make_pair(0, 0);
        return be_adds_copy;
    }

    bool is_result_redundant(const SimEvent& event)
    {
        map<unsigned int, UIntPairType>::iterator it =
            pod_status.find(event.rid);

        assert (it != pod_status.end());
        assert (event.type == EventType::BE2FE_result);

        UIntPairType& value = it->second;
        value.second++;
        assert (value.first + value.second <= pod_size);
        bool retval = (value.second > 1);

        if (value.first + value.second == pod_size)
        {
            pod_status.erase(it);
        }

        return retval;
    }

    bool is_retry_required(const SimEvent& event)
    {
        map<unsigned int, UIntPairType>::iterator it =
            pod_status.find(event.rid);

        assert (it != pod_status.end());
        assert (event.type == EventType::BE2FE_busy);

        UIntPairType& value = it->second;
        value.first++;

        assert (value.first + value.second <= pod_size);

        if (value.first + value.second < pod_size)
        {
            return false;
        }
        else if ( value.first + value.second == pod_size &&
                  value.second > 0 )
        {
            pod_status.erase(it);
            return false;
        }
        else // ( value.first + value.second == pod_size &&
             //   value.second == 0 )
        {
            pod_status.erase(it);
            return true;
        }
    }
};

class FELoadBalancerRand
{
  protected:
    Category *logger;
    LBPolicyType lb_type;
    vector<string> be_adds;
    unsigned int active_bes;

  public:
    FELoadBalancerRand( Category *lgr, string my_add, vector<string>& be_adds,
                        unsigned int active_bes )
                        : logger(lgr), be_adds(be_adds), active_bes(active_bes)
    {
        INFO << "Initializing FELoadbalancer of type RAND";
        assert (active_bes <= be_adds.size());
    }

    void set_active_bes(unsigned int n)
    {
        assert (n <= be_adds.size());
        active_bes = n;
    }

    string get_random_be()
    {
        return be_adds[rand() % active_bes];
    }
};

class BELoadBalancer
{
  private:
    Category *logger;
    LBPolicyType lb_type;
    vector<string> fe_adds;
    queue<SimEvent> pending_events;

  public:
    BELoadBalancer(Category *lgr, LBPolicyType typ, vector<string>& adds)
                   : logger(lgr), lb_type(typ), fe_adds(adds)
    {
        INFO << "Initializing BELoadbalancer of type "
             << get_policy_type_str(this->lb_type);
    }

    bool is_event_pending()
    {
        return !pending_events.empty();
    }

    SimEvent get_pending_event()
    {
        assert (!pending_events.empty());
        SimEvent event = pending_events.front();
        pending_events.pop();
        return event;
    }

    void add_pending_event(const SimEvent& event)
    {
        pending_events.push(event);
    }

    string get_random_fe()
    {
        return fe_adds[rand() % fe_adds.size()];
    }
};

#endif
