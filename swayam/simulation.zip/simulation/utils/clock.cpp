#include "clock.h"
#include <chrono>
#include <iostream>
#include <iomanip>

template <typename C>
void print_clock_data()
{
    cout << "- precision: ";
    // if time unit is less or equal one millisecond
    typedef typename C::period P; // type of time unit
    if (ratio_less_equal<P,milli>::value)
    {
        // convert to and print as milliseconds
        typedef typename ratio_multiply<P,kilo>::type TT;
        cout << fixed << double(TT::num)/TT::den << " milliseconds" << endl;
    }
    else
    {
        // print as seconds
        cout << fixed << double(P::num)/P::den << " seconds" << endl;
    }
    cout << "- is_steady: " << boolalpha << C::is_steady << endl;
}

void print_all_clock_data()
{
    cout << "system_clock: " << endl;
    print_clock_data<system_clock>();
    cout << "\nhigh_resolution_clock: " << endl;
    print_clock_data<high_resolution_clock>();
    cout << "\nsteady_clock: " << endl;
    print_clock_data<steady_clock>();
}

double get_curr_time_ns()
{
    auto since_epoch = MyClock::now().time_since_epoch();
    auto nanos = duration_cast<nanoseconds>(since_epoch).count();
    return static_cast<double>(nanos); 
}

double get_duration_ns(double start_time)
{
    return get_curr_time_ns() - start_time;
}

int main()
{
    print_all_clock_data();
}
