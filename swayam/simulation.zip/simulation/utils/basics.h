#ifndef BASICS_H
#define BASICS_H

#include <iostream> // std
#include <signal.h> // SIGINT, SIGTERM

#define RETRY_DELAY_US 5000
#define FE2BE_DELAY_US 1000
#define BE2FE_DELAY_US 1000
#define INITIAL_NUM_WARM_BES 10
#define AUTO_SCALING_PERIOD_US 10 * 1000 * 1000

using namespace std;

typedef unsigned long long TimeUs;

void sig_handler(int x);
TimeUs sec2us(TimeUs x);

#endif
