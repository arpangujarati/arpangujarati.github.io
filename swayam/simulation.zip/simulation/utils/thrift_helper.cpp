#include "thrift_helper.h"

#include <cstring> // strtok

#include "basics.h"

string MessageTypeStr(MessageType::type t)
{
    switch(t)
    {
        case MessageType::WG2CL_query:
            return "WG2CL_query";
        case MessageType::CL2BR_query:
            return "CL2BR_query";
        case MessageType::BR2FE_query:
            return "BR2FE_query";
        case MessageType::BR2CL_result:
            return "BR2CL_result";
        case MessageType::FE2BE_query:
            return "FE2BE_query";
        case MessageType::FE2BR_result:
            return "FE2BR_result";
        case MessageType::BE2FE_result:
            return "BE2FE_result";
        case MessageType::BE2FE_busy:
            return "BE2FE_busy";
        default:
            return "INVALID_MSG_TYPE";
    }
}

bool compare_AddType(const AddType& add1, const AddType& add2)
{
    if (add1.host.compare(add2.host) && add1.port == add2.port)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void convert_AddType_to_str(const AddType& add, string& str)
{
    str = string(add.host) + string(":") + to_string(add.port);
}

bool convert_str_to_AddType(string str, AddType& add)
{
    try
    {
        char * writable = new char[str.size() + 1];
        copy(str.begin(), str.end(), writable);
        writable[str.size()] = '\0';
        add.host = strtok(writable, ":");
        add.port = stoi(strtok(NULL, ":"));
        delete[] writable;
        return true;
    }
    catch(const exception& e)
    {
        cerr << "Error: Conversion of \"" << str << "\" to AddType failed " 
             << "with exception " << e.what() << flush;
        return false;
    }
}

bool get_adds_from_file(string filename, vector<AddType>& adds)
{
    ifstream myfile (filename);

    if (!myfile.is_open())
    {
        cerr << "Error: Could not open file " << filename << "\n" << flush;
        return false;
    }
 
    string line;
    while (getline(myfile, line))
    {
        AddType add;
        if (!convert_str_to_AddType(line, add))
            return false;
        adds.push_back(add);
    }

    myfile.close();

    if (adds.empty())
    {
        cerr << "Error: No addresses in file " << filename << "\n" << flush;
        return false;
    }

    return true;
}

bool get_all_adds_from_file( string add_dir,
                             vector<AddType>& cl_adds,
                             vector<AddType>& br_adds,
                             vector<AddType>& fe_adds,
                             vector<AddType>& be_adds )
{
    return ( get_adds_from_file(add_dir + "client.txt",   cl_adds) &&
             get_adds_from_file(add_dir + "broker.txt",   br_adds) &&
             get_adds_from_file(add_dir + "frontend.txt", fe_adds) &&
             get_adds_from_file(add_dir + "backend.txt",  be_adds) );
}

Message* get_new_msg(MessageType::type mtype, AddType sender)
{
    Message *msg = new Message();
    msg->mtype = mtype;
    msg->sender = sender;
    return msg;
}

Message* get_new_msg( const Message& old_msg, MessageType::type mtype,
                      AddType sender )
{
    Message *msg = new Message(old_msg);
    assert (msg->stats.entry_time_us.compare(old_msg.stats.entry_time_us) == 0);
    assert (msg->stats.start_time_us.compare(old_msg.stats.start_time_us) == 0);
    assert (msg->stats.exit_time_us.compare(old_msg.stats.exit_time_us) == 0);
    msg->mtype = mtype;
    msg->sender = sender;
    return msg;
}

string msg2str(AddType my_add, TimeUs time, const Message& msg)
{
    string str = "[" + to_string(time) + " " + NAME(msg.sender) + " " +
                 MessageTypeStr(msg.mtype) + " " + to_string(msg.sid) + ":" +
                 to_string(msg.rid) + " " + NAME(my_add) + "]";
    return str;
}

string msg2str(TimeUs time, const Message& msg)
{
    string str = "[" + to_string(time) + " " + MessageTypeStr(msg.mtype) + " "
                 + to_string(msg.sid) + ":" + to_string(msg.rid) + " ]";

    return str;
}
